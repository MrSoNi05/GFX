package com.bgm.gfx;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.util.Log;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleObserver;
import androidx.lifecycle.OnLifecycleEvent;
import androidx.lifecycle.ProcessLifecycleOwner;
import com.github.megatronking.stringfog.xor.StringFogImpl;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.appopen.AppOpenAd;
import java.util.Date;

/* loaded from: classes7.dex */
public class AppOpenManager implements LifecycleObserver, Application.ActivityLifecycleCallbacks {
    private Activity currentActivity;
    private AppOpenAd.AppOpenAdLoadCallback loadCallback;
    private final MyApplication myApplication;
    private static final String LOG_TAG = StringFogImpl.decrypt("FCQ2YkgwOgtMVjQzI18=");
    private static final String AD_UNIT_ID = StringFogImpl.decrypt("NjVrTEgleTZYWnhscRQLYWByHgxkZHQUDmVlaRgMZmF3FA1gYXY=");
    private static boolean isShowingAd = false;
    private AppOpenAd appOpenAd = null;
    private long loadTime = 0;

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityCreated(Activity activity, Bundle bundle) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityPaused(Activity activity) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivitySaveInstanceState(Activity activity, Bundle bundle) {
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStopped(Activity activity) {
    }

    public AppOpenManager(MyApplication myApplication) {
        this.myApplication = myApplication;
        myApplication.registerActivityLifecycleCallbacks(this);
        ProcessLifecycleOwner.get().getLifecycle().addObserver(this);
    }

    @OnLifecycleEvent(Lifecycle.Event.ON_START)
    public void onStart() {
        showAdIfAvailable();
        Log.d(LOG_TAG, StringFogImpl.decrypt("OjoVWVknIA=="));
    }

    public void fetchAd() {
        if (isAdAvailable()) {
            return;
        }
        this.loadCallback = new AppOpenAd.AppOpenAdLoadCallback() { // from class: com.bgm.gfx.AppOpenManager.1
//            @Override // com.google.android.gms.ads.appopen.AppOpenAd.AppOpenAdLoadCallback
            public void onAppOpenAdFailedToLoad(LoadAdError loadAdError) {
            }

//            @Override // com.google.android.gms.ads.appopen.AppOpenAd.AppOpenAdLoadCallback
            public void onAppOpenAdLoaded(AppOpenAd appOpenAd) {
                AppOpenManager.this.appOpenAd = appOpenAd;
                AppOpenManager.this.loadTime = new Date().getTime();
            }
        };
        AppOpenAd.load(this.myApplication, AD_UNIT_ID, getAdRequest(), 1, this.loadCallback);
    }

    private AdRequest getAdRequest() {
        return new AdRequest.Builder().build();
    }

    private boolean wasLoadTimeLessThanNHoursAgo(long j) {
        return new Date().getTime() - this.loadTime < j * 3600000;
    }

    public boolean isAdAvailable() {
        return this.appOpenAd != null && wasLoadTimeLessThanNHoursAgo(4L);
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityStarted(Activity activity) {
        this.currentActivity = activity;
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityResumed(Activity activity) {
        this.currentActivity = activity;
    }

    @Override // android.app.Application.ActivityLifecycleCallbacks
    public void onActivityDestroyed(Activity activity) {
        this.currentActivity = null;
    }

    public void showAdIfAvailable() {
        if (!isShowingAd && isAdAvailable()) {
            Log.d(LOG_TAG, StringFogImpl.decrypt("Aj0qQRgmPClaGDQwaA=="));
            this.appOpenAd.show(this.currentActivity);
            return;
        }
        Log.d(LOG_TAG, StringFogImpl.decrypt("FjUoDVY6IGZeUDojZkxcew=="));
        fetchAd();
    }
}
