package com.bgm.gfx;

import android.app.Activity;
import android.os.Bundle;

/* loaded from: classes7.dex */
public class PlayActivity extends Activity {
    @Override // android.app.Activity
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        requestWindowFeature(1);
        setContentView(new GameView(this));
    }
}
