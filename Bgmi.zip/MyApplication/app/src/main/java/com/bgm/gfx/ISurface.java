package com.bgm.gfx;

import android.graphics.Canvas;

/* loaded from: classes7.dex */
public interface ISurface {
    void onDraw(Canvas canvas);

    void onInitialize();

    void onUpdate(long j);
}
