package com.bgm.gfx;

import android.app.AlertDialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.github.megatronking.stringfog.xor.StringFogImpl;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.firebase.FirebaseApp;
import de.hdodenhof.circleimageview.CircleImageView;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

/* loaded from: classes7.dex */
public class SelectGameActivity extends AppCompatActivity {
    private Intent ahskoqiwhvbaha;
    private Button button1;
    private Button button2;
    private Button button3;
    private Button button4;
    private Button button5;
    private Button button6;
    private Button button7;
    private Button button8;
    private CircleImageView circleimageview10;
    private CircleImageView circleimageview3;
    private CircleImageView circleimageview4;
    private CircleImageView circleimageview5;
    private CircleImageView circleimageview6;
    private CircleImageView circleimageview7;
    private CircleImageView circleimageview8;
    private CircleImageView circleimageview9;
    private AlertDialog.Builder d;
    private LinearLayout game;
    private LinearLayout linear11;
    private LinearLayout linear15;
    private LinearLayout linear16;
    private LinearLayout linear17;
    private LinearLayout linear18;
    private LinearLayout linear19;
    private LinearLayout linear20;
    private LinearLayout linear22;
    private LinearLayout linear23;
    private LinearLayout linear24;
    private LinearLayout linear25;
    private LinearLayout linear27;
    private LinearLayout linear28;
    private LinearLayout linear29;
    private LinearLayout linear30;
    private LinearLayout linear31;
    private InterstitialAd mInterstitialAd;
    private RewardedAd mRewardedAd;
    private ProgressDialog prog;
    private TimerTask t;
    private TextView textview11;
    private TextView textview14;
    private TextView textview15;
    private TextView textview3;
    private TextView textview4;
    private TextView textview5;
    private TextView textview8;
    private TextView textview9;
    private ScrollView vscroll2;
    private Timer _timer = new Timer();
    private String fontName = "";
    private String typeace = "";
    private boolean ADDS = false;
    private boolean NEXT = false;
    private Intent page = new Intent();
    private Intent link = new Intent();

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.select_game);
        initialize(bundle);
//        FirebaseApp.initializeApp(String.valueOf(this));
        initializeLogic();
    }

    private void initialize(Bundle bundle) {
        this.vscroll2 = (ScrollView) findViewById(R.id.vscroll2);
        this.linear11 = (LinearLayout) findViewById(R.id.linear11);
        this.game = (LinearLayout) findViewById(R.id.game);
        this.linear28 = (LinearLayout) findViewById(R.id.linear28);
        this.linear30 = (LinearLayout) findViewById(R.id.linear30);
        this.linear15 = (LinearLayout) findViewById(R.id.linear15);
        this.linear24 = (LinearLayout) findViewById(R.id.linear24);
        this.linear17 = (LinearLayout) findViewById(R.id.linear17);
        this.linear18 = (LinearLayout) findViewById(R.id.linear18);
        this.linear22 = (LinearLayout) findViewById(R.id.linear22);
        this.linear27 = (LinearLayout) findViewById(R.id.linear27);
        this.button6 = (Button) findViewById(R.id.button6);
        this.circleimageview8 = (CircleImageView) findViewById(R.id.circleimageview8);
        this.textview11 = (TextView) findViewById(R.id.textview11);
        this.linear29 = (LinearLayout) findViewById(R.id.linear29);
        this.button7 = (Button) findViewById(R.id.button7);
        this.circleimageview9 = (CircleImageView) findViewById(R.id.circleimageview9);
        this.textview14 = (TextView) findViewById(R.id.textview14);
        this.linear31 = (LinearLayout) findViewById(R.id.linear31);
        this.button8 = (Button) findViewById(R.id.button8);
        this.circleimageview10 = (CircleImageView) findViewById(R.id.circleimageview10);
        this.textview15 = (TextView) findViewById(R.id.textview15);
        this.linear16 = (LinearLayout) findViewById(R.id.linear16);
        this.button1 = (Button) findViewById(R.id.button1);
        this.circleimageview3 = (CircleImageView) findViewById(R.id.circleimageview3);
        this.textview3 = (TextView) findViewById(R.id.textview3);
        this.linear25 = (LinearLayout) findViewById(R.id.linear25);
        this.button5 = (Button) findViewById(R.id.button5);
        this.circleimageview7 = (CircleImageView) findViewById(R.id.circleimageview7);
        this.textview9 = (TextView) findViewById(R.id.textview9);
        this.linear19 = (LinearLayout) findViewById(R.id.linear19);
        this.button2 = (Button) findViewById(R.id.button2);
        this.circleimageview4 = (CircleImageView) findViewById(R.id.circleimageview4);
        this.textview4 = (TextView) findViewById(R.id.textview4);
        this.linear20 = (LinearLayout) findViewById(R.id.linear20);
        this.button3 = (Button) findViewById(R.id.button3);
        this.circleimageview5 = (CircleImageView) findViewById(R.id.circleimageview5);
        this.textview5 = (TextView) findViewById(R.id.textview5);
        this.linear23 = (LinearLayout) findViewById(R.id.linear23);
        this.button4 = (Button) findViewById(R.id.button4);
        this.circleimageview6 = (CircleImageView) findViewById(R.id.circleimageview6);
        this.textview8 = (TextView) findViewById(R.id.textview8);
        this.d = new AlertDialog.Builder(this);
        this.button6.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.SelectGameActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (SelectGameActivity.this.NEXT) {
                    SelectGameActivity.this.page.setClass(SelectGameActivity.this.getApplicationContext(), GameActivity.class);
                    SelectGameActivity selectGameActivity = SelectGameActivity.this;
                    selectGameActivity.startActivity(selectGameActivity.page);
                    SelectGameActivity.this.NEXT = false;
                    return;
                }
                SelectGameActivity.this.d.create().show();
            }
        });
        this.button7.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.SelectGameActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (SelectGameActivity.this.NEXT) {
                    SelectGameActivity.this.page.setClass(SelectGameActivity.this.getApplicationContext(), HomeActivity.class);
                    SelectGameActivity selectGameActivity = SelectGameActivity.this;
                    selectGameActivity.startActivity(selectGameActivity.page);
                    SelectGameActivity.this.NEXT = false;
                    return;
                }
                SelectGameActivity.this.d.create().show();
            }
        });
        this.button8.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.SelectGameActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (SelectGameActivity.this.NEXT) {
                    SelectGameActivity.this.page.setClass(SelectGameActivity.this.getApplicationContext(), ColourGameActivity.class);
                    SelectGameActivity selectGameActivity = SelectGameActivity.this;
                    selectGameActivity.startActivity(selectGameActivity.page);
                    SelectGameActivity.this.NEXT = false;
                    return;
                }
                SelectGameActivity.this.d.create().show();
            }
        });
        this.button1.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.SelectGameActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (SelectGameActivity.this.NEXT) {
                    SelectGameActivity.this.page.setClass(SelectGameActivity.this.getApplicationContext(), HvaiActivity.class);
                    SelectGameActivity selectGameActivity = SelectGameActivity.this;
                    selectGameActivity.startActivity(selectGameActivity.page);
                    SelectGameActivity.this.NEXT = false;
                    return;
                }
                SelectGameActivity.this.d.create().show();
            }
        });
        this.button5.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.SelectGameActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (SelectGameActivity.this.NEXT) {
                    SelectGameActivity.this.page.setClass(SelectGameActivity.this.getApplicationContext(), BmainActivity.class);
                    SelectGameActivity selectGameActivity = SelectGameActivity.this;
                    selectGameActivity.startActivity(selectGameActivity.page);
                    SelectGameActivity.this.NEXT = false;
                    return;
                }
                SelectGameActivity.this.d.create().show();
            }
        });
        this.button2.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.SelectGameActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (SelectGameActivity.this.NEXT) {
                    SelectGameActivity.this.page.setClass(SelectGameActivity.this.getApplicationContext(), BricksActivity.class);
                    SelectGameActivity selectGameActivity = SelectGameActivity.this;
                    selectGameActivity.startActivity(selectGameActivity.page);
                    SelectGameActivity.this.NEXT = false;
                    return;
                }
                SelectGameActivity.this.d.create().show();
            }
        });
        this.button3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.SelectGameActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SelectGameActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                SelectGameActivity.this.link.setData(Uri.parse(StringFogImpl.decrypt("PSAyXQJ6ezZBWSxmfxoWNCArSF80OSMDWzo5aQ==")));
                SelectGameActivity selectGameActivity = SelectGameActivity.this;
                selectGameActivity.startActivity(selectGameActivity.link);
            }
        });
        this.button4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.SelectGameActivity.8
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SelectGameActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                SelectGameActivity.this.link.setData(Uri.parse(StringFogImpl.decrypt("PSAyXQJ6ezZBWSxmfxoWNCArSEkgPTwDWzo5aQ==")));
                SelectGameActivity selectGameActivity = SelectGameActivity.this;
                selectGameActivity.startActivity(selectGameActivity.link);
            }
        });
    }

    private void initializeLogic() {
        _changeActivityFont(StringFogImpl.decrypt("MzsoTEohOw=="));
        _NavStatusBarColor(StringFogImpl.decrypt("dhIAG3tjZwBr"), StringFogImpl.decrypt("dhIAG3tjZwBr"));
        _rippleRoundStroke(this.button1, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djd/Sw00Ng=="), 100.0d, 4.0d, StringFogImpl.decrypt("dmR2a35lZA=="));
        _rippleRoundStroke(this.button2, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djd/Sw00Ng=="), 100.0d, 4.0d, StringFogImpl.decrypt("dmR2a35lZA=="));
        _rippleRoundStroke(this.button3, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djd/Sw00Ng=="), 100.0d, 4.0d, StringFogImpl.decrypt("dmR2a35lZA=="));
        _rippleRoundStroke(this.button4, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djd/Sw00Ng=="), 100.0d, 4.0d, StringFogImpl.decrypt("dmR2a35lZA=="));
        _rippleRoundStroke(this.button5, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djd/Sw00Ng=="), 100.0d, 4.0d, StringFogImpl.decrypt("dmR2a35lZA=="));
        _rippleRoundStroke(this.button6, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djd/Sw00Ng=="), 100.0d, 4.0d, StringFogImpl.decrypt("dmR2a35lZA=="));
        _rippleRoundStroke(this.button7, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djd/Sw00Ng=="), 100.0d, 4.0d, StringFogImpl.decrypt("dmR2a35lZA=="));
        _rippleRoundStroke(this.button8, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djd/Sw00Ng=="), 100.0d, 4.0d, StringFogImpl.decrypt("dmR2a35lZA=="));
        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ==")), Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ=="))});
        gradientDrawable.setCornerRadii(new float[]{0.0f, 0.0f, 101.0f, 101.0f, 0.0f, 0.0f, 101.0f, 101.0f});
        gradientDrawable.setStroke(4, Color.parseColor(StringFogImpl.decrypt("dmR2a34TEg==")));
        this.linear15.setElevation(21.0f);
        this.linear15.setBackground(gradientDrawable);
        GradientDrawable gradientDrawable2 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ==")), Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ=="))});
        gradientDrawable2.setCornerRadii(new float[]{0.0f, 0.0f, 100.0f, 100.0f, 0.0f, 0.0f, 100.0f, 100.0f});
        gradientDrawable2.setStroke(4, Color.parseColor(StringFogImpl.decrypt("dmR2a34TEg==")));
        this.linear17.setElevation(21.0f);
        this.linear17.setBackground(gradientDrawable2);
        GradientDrawable gradientDrawable3 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ==")), Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ=="))});
        gradientDrawable3.setCornerRadii(new float[]{0.0f, 0.0f, 100.0f, 100.0f, 0.0f, 0.0f, 100.0f, 100.0f});
        gradientDrawable3.setStroke(4, Color.parseColor(StringFogImpl.decrypt("dmR2a34TEg==")));
        this.linear18.setElevation(21.0f);
        this.linear18.setBackground(gradientDrawable3);
        GradientDrawable gradientDrawable4 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ==")), Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ=="))});
        gradientDrawable4.setCornerRadii(new float[]{0.0f, 0.0f, 100.0f, 100.0f, 0.0f, 0.0f, 100.0f, 100.0f});
        gradientDrawable4.setStroke(4, Color.parseColor(StringFogImpl.decrypt("dmR2a34TEg==")));
        this.linear22.setElevation(21.0f);
        this.linear22.setBackground(gradientDrawable4);
        GradientDrawable gradientDrawable5 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ==")), Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ=="))});
        gradientDrawable5.setCornerRadii(new float[]{0.0f, 0.0f, 100.0f, 100.0f, 0.0f, 0.0f, 100.0f, 100.0f});
        gradientDrawable5.setStroke(4, Color.parseColor(StringFogImpl.decrypt("dmR2a34TEg==")));
        this.linear24.setElevation(21.0f);
        this.linear24.setBackground(gradientDrawable5);
        GradientDrawable gradientDrawable6 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ==")), Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ=="))});
        gradientDrawable6.setCornerRadii(new float[]{0.0f, 0.0f, 100.0f, 100.0f, 0.0f, 0.0f, 100.0f, 100.0f});
        gradientDrawable6.setStroke(4, Color.parseColor(StringFogImpl.decrypt("dmR2a34TEg==")));
        this.game.setElevation(21.0f);
        this.game.setBackground(gradientDrawable5);
        GradientDrawable gradientDrawable7 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ==")), Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ=="))});
        gradientDrawable7.setCornerRadii(new float[]{0.0f, 0.0f, 100.0f, 100.0f, 0.0f, 0.0f, 100.0f, 100.0f});
        gradientDrawable7.setStroke(4, Color.parseColor(StringFogImpl.decrypt("dmR2a34TEg==")));
        this.linear28.setElevation(21.0f);
        this.linear28.setBackground(gradientDrawable7);
        GradientDrawable gradientDrawable8 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ==")), Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ=="))});
        gradientDrawable8.setCornerRadii(new float[]{0.0f, 0.0f, 100.0f, 100.0f, 0.0f, 0.0f, 100.0f, 100.0f});
        gradientDrawable8.setStroke(4, Color.parseColor(StringFogImpl.decrypt("dmR2a34TEg==")));
        this.linear30.setElevation(21.0f);
        this.linear30.setBackground(gradientDrawable8);
        Animation loadAnimation = AnimationUtils.loadAnimation(getApplicationContext(), 17432578);
        loadAnimation.setDuration(500L);
        this.game.startAnimation(loadAnimation);
        Animation loadAnimation2 = AnimationUtils.loadAnimation(getApplicationContext(), 17432578);
        loadAnimation2.setDuration(800L);
        this.linear17.startAnimation(loadAnimation2);
        Animation loadAnimation3 = AnimationUtils.loadAnimation(getApplicationContext(), 17432578);
        loadAnimation3.setDuration(900L);
        this.linear15.startAnimation(loadAnimation3);
        Animation loadAnimation4 = AnimationUtils.loadAnimation(getApplicationContext(), 17432578);
        loadAnimation4.setDuration(900L);
        this.linear28.startAnimation(loadAnimation4);
        Animation loadAnimation5 = AnimationUtils.loadAnimation(getApplicationContext(), 17432578);
        loadAnimation5.setDuration(1000L);
        this.linear24.startAnimation(loadAnimation5);
        Animation loadAnimation6 = AnimationUtils.loadAnimation(getApplicationContext(), 17432578);
        loadAnimation6.setDuration(1400L);
        this.linear22.startAnimation(loadAnimation6);
        Animation loadAnimation7 = AnimationUtils.loadAnimation(getApplicationContext(), 17432578);
        loadAnimation7.setDuration(900L);
        this.linear30.startAnimation(loadAnimation7);
        MobileAds.initialize(this, new OnInitializationCompleteListener() { // from class: com.bgm.gfx.SelectGameActivity.9
            @Override // com.google.android.gms.ads.initialization.OnInitializationCompleteListener
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        _InterstitialAd();
        TimerTask timerTask = new TimerTask() { // from class: com.bgm.gfx.SelectGameActivity.10
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                SelectGameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.SelectGameActivity.10.1
                    @Override // java.lang.Runnable
                    public void run() {
                        if (SelectGameActivity.this.ADDS) {
                            SelectGameActivity.this.t.cancel();
                            if (SelectGameActivity.this.mInterstitialAd != null) {
                                SelectGameActivity.this.mInterstitialAd.show(SelectGameActivity.this);
                            }
                        }
                    }
                });
            }
        };
        this.t = timerTask;
        this._timer.scheduleAtFixedRate(timerTask, 100L, 500L);
        this.d.setTitle(StringFogImpl.decrypt("BRgDbGsQdBNjdBoXDQ=="));
        this.d.setMessage(StringFogImpl.decrypt("ATtmWFY5OyVGGCE8L14YMzEnWU0nMWZUVyB0KEhdMXQyQhgiNTJOUHU1IgM="));
        this.d.setPositiveButton(StringFogImpl.decrypt("ABoKYnse"), new DialogInterface.OnClickListener() { // from class: com.bgm.gfx.SelectGameActivity.11
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                SelectGameActivity.this._reward();
            }
        });
        this.d.setNegativeButton(StringFogImpl.decrypt("GxsSDXYaAw=="), new DialogInterface.OnClickListener() { // from class: com.bgm.gfx.SelectGameActivity.12
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        this.NEXT = false;
    }

    public void _rippleRoundStroke(View view, String str, String str2, double d, double d2, String str3) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(Color.parseColor(str));
        gradientDrawable.setCornerRadius((float) d);
        gradientDrawable.setStroke((int) d2, Color.parseColor(StringFogImpl.decrypt("dg==") + str3.replace(StringFogImpl.decrypt("dg=="), "")));
        view.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{Color.parseColor(str2)}), gradientDrawable, null));
    }

    public void _changeActivityFont(String str) {
        this.fontName = StringFogImpl.decrypt("MzsoWUt6").concat(str.concat(StringFogImpl.decrypt("eyAySw==")));
        overrideFonts(this, getWindow().getDecorView());
    }

    private void overrideFonts(Context context, View view) {
        try {
            Typeface createFromAsset = Typeface.createFromAsset(getAssets(), this.fontName);
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                for (int i = 0; i < viewGroup.getChildCount(); i++) {
                    overrideFonts(context, viewGroup.getChildAt(i));
                }
            } else if (view instanceof TextView) {
                ((TextView) view).setTypeface(createFromAsset);
            } else if (view instanceof EditText) {
                ((EditText) view).setTypeface(createFromAsset);
            } else if (view instanceof Button) {
                ((Button) view).setTypeface(createFromAsset);
            }
        } catch (Exception unused) {
            SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp1GClMXDw6IQ1+Ojoy"));
        }
    }

    public void _NavStatusBarColor(String str, String str2) {
        if (Build.VERSION.SDK_INT > 21) {
            Window window = getWindow();
            window.clearFlags(67108864);
            window.addFlags(Integer.MIN_VALUE);
            window.setStatusBarColor(Color.parseColor(StringFogImpl.decrypt("dg==") + str.replace(StringFogImpl.decrypt("dg=="), "")));
            window.setNavigationBarColor(Color.parseColor(StringFogImpl.decrypt("dg==") + str2.replace(StringFogImpl.decrypt("dg=="), "")));
        }
    }

    public void _InterstitialAd() {
        final AlertDialog create = new AlertDialog.Builder(this).create();
        View inflate = getLayoutInflater().inflate(R.layout.lod, (ViewGroup) null);
        create.setView(inflate);
        TextView textView = (TextView) inflate.findViewById(R.id.t1);
        _rippleRoundStroke((LinearLayout) inflate.findViewById(R.id.linear1), StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dhIAa34TEg=="), 15.0d, 0.0d, StringFogImpl.decrypt("dhIAa34TEg=="));
        textView.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6JDRCXCA3MnJLNDo1clUwMC9YVXsgMks=")), 0);
        textView.setText(StringFogImpl.decrypt("BTgjTEswdDFMUSF6aAM="));
        create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        create.setCancelable(false);
        create.show();
        InterstitialAd.load(this, getApplicationContext().getResources().getString(R.string.interstitaluidOnly), new AdRequest.Builder().build(), new InterstitialAdLoadCallback() { // from class: com.bgm.gfx.SelectGameActivity.13
            @Override // com.google.android.gms.ads.AdLoadCallback
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                SelectGameActivity.this.ADDS = true;
                create.dismiss();
                SelectGameActivity.this.mInterstitialAd = interstitialAd;
                SelectGameActivity.this.mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() { // from class: com.bgm.gfx.SelectGameActivity.13.1
                    @Override // com.google.android.gms.ads.FullScreenContentCallback
                    public void onAdDismissedFullScreenContent() {
                    }

                    @Override // com.google.android.gms.ads.FullScreenContentCallback
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                    }

                    @Override // com.google.android.gms.ads.FullScreenContentCallback
                    public void onAdShowedFullScreenContent() {
                        SelectGameActivity.this.mInterstitialAd = null;
                    }
                });
            }

            @Override // com.google.android.gms.ads.AdLoadCallback
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                create.dismiss();
                SelectGameActivity.this.mInterstitialAd = null;
            }
        });
    }

    public void _reward() {
        _loadingMenu(true, StringFogImpl.decrypt("BRgDbGsQdBFscQE="));
        RewardedAd.load(this, getApplicationContext().getResources().getString(R.string.rewardedOnly), new AdRequest.Builder().build(), new RewardedAdLoadCallback() { // from class: com.bgm.gfx.SelectGameActivity.14
            @Override // com.google.android.gms.ads.AdLoadCallback
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                SelectGameActivity.this._loadingMenu(false, "");
                SelectGameActivity.this.NEXT = true;
                SelectGameActivity.this.mRewardedAd = null;
            }

            @Override // com.google.android.gms.ads.AdLoadCallback
            public void onAdLoaded(@NonNull RewardedAd rewardedAd) {
                SelectGameActivity.this.mRewardedAd = rewardedAd;
                SelectGameActivity.this._loadingMenu(false, "");
                if (SelectGameActivity.this.mRewardedAd == null) {
                    if (SelectGameActivity.this.mInterstitialAd != null) {
                        SelectGameActivity.this.mInterstitialAd.show(SelectGameActivity.this);
                    }
                } else {
                    SelectGameActivity selectGameActivity = SelectGameActivity.this;
                    selectGameActivity.mRewardedAd.show(selectGameActivity, new OnUserEarnedRewardListener() { // from class: com.bgm.gfx.SelectGameActivity.14.1
                        @Override // com.google.android.gms.ads.OnUserEarnedRewardListener
                        public void onUserEarnedReward(@NonNull RewardItem rewardItem) {
                            rewardItem.getAmount();
                            rewardItem.getType();
                        }
                    });
                }
                SelectGameActivity.this.mRewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() { // from class: com.bgm.gfx.SelectGameActivity.14.2
                    @Override // com.google.android.gms.ads.FullScreenContentCallback
                    public void onAdShowedFullScreenContent() {
                        SelectGameActivity.this.NEXT = true;
                    }

                    @Override // com.google.android.gms.ads.FullScreenContentCallback
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        SelectGameActivity.this.NEXT = true;
                    }

                    @Override // com.google.android.gms.ads.FullScreenContentCallback
                    public void onAdDismissedFullScreenContent() {
                        SelectGameActivity.this.mRewardedAd = null;
                    }
                });
            }
        });
    }

    public void _loadingMenu(boolean z, String str) {
        if (z) {
            if (this.prog == null) {
                ProgressDialog progressDialog = new ProgressDialog(this);
                this.prog = progressDialog;
                progressDialog.setMax(100);
                this.prog.setIndeterminate(true);
                this.prog.setCancelable(false);
                this.prog.setCanceledOnTouchOutside(false);
            }
            this.prog.setMessage(str);
            this.prog.show();
            return;
        }
        ProgressDialog progressDialog2 = this.prog;
        if (progressDialog2 != null) {
            progressDialog2.dismiss();
        }
    }

    @Deprecated
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, 0).show();
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    @Deprecated
    public int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList<Double> arrayList = new ArrayList<>();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf(checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int i) {
        return TypedValue.applyDimension(1, i, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
