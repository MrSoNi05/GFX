package com.bgm.gfx;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Build;
import android.os.Bundle;
import android.os.ParcelFileDescriptor;
import android.provider.DocumentsContract;
import android.provider.Settings;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.BounceInterpolator;
import android.webkit.URLUtil;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.RelativeLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.SpinnerAdapter;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import androidx.documentfile.provider.DocumentFile;
import androidx.drawerlayout.widget.DrawerLayout;
import com.bgm.gfx.RequestNetwork;
import com.bumptech.glide.Glide;
import com.example.iosprogressbarforandroid.IOSProgressHUD;
import com.github.megatronking.stringfog.xor.StringFogImpl;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.OnUserEarnedRewardListener;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.ads.rewarded.RewardItem;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.google.android.material.appbar.AppBarLayout;
//import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.rejowan.cutetoast.CuteToast;
import com.thecode.aestheticdialogs.AestheticDialog;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Objects;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;


public class BgmActivity extends AppCompatActivity {
    public static String fpsValue = "";
    public static TimerTask t5a;
    private LinearLayout A10;
    private LinearLayout A11;
    private LinearLayout A12;
    private LinearLayout A13;
    private LinearLayout A14;
    private LinearLayout A15;
    private LinearLayout A16;
    private LinearLayout A17;
    private LinearLayout A18;
    private LinearLayout A19;
    private LinearLayout A20;
    private LinearLayout A21;
    private LinearLayout A22;
    private LinearLayout A23;
    private LinearLayout A24;
    private LinearLayout A25;
    private LinearLayout A26;
    private LinearLayout A27;
    private LinearLayout A28;
    private LinearLayout A29;
    private LinearLayout A30;
    private LinearLayout A31;
    private LinearLayout A32;
    private LinearLayout A33;
    private LinearLayout A34;
    private LinearLayout A35;
    private LinearLayout A36;
    private LinearLayout A37;
    private LinearLayout A38;
    private LinearLayout A39;
    private LinearLayout A9;
    private LinearLayout ADN;
    private AlertDialog.Builder D;
    private RequestNetwork DL;
    private SharedPreferences DOWNLOAD;
    private LinearLayout Fps_bg;
    private LinearLayout Graphic_bg_2;
    private IOSProgressHUD HUD;
    private RelativeLayout MixedLayout;
    private int NEW_FOLDER_REQUEST_CODE;
    private DocumentFile New;
    private DocumentFile New2;
    private Switch OptimizationGame_switch;
    private LinearLayout OptomizeGame_Bg;
    private TextView OverAllRamUse_Title;
    private TimerTask PAK_APPLYY;
    private LinearLayout RESET1;
    private LinearLayout RESET2;
    private LinearLayout RESET3;
    private LinearLayout RESET4;
    private LinearLayout RESET5;
    private LinearLayout Resolution_bg_2;
    private SharedPreferences UCSP;
    private SharedPreferences VER;
    private RequestNetwork.RequestListener _DL_request_listener;
    private AppBarLayout _app_bar;
    private CoordinatorLayout _coordinator;
    private DrawerLayout _drawer;
    private ImageView _drawer_about_img;
    private ImageView _drawer_aboutapp_img;
    private ImageView _drawer_close;
    private ImageView _drawer_exit_img;
    private LinearLayout _drawer_feed;
    private ImageView _drawer_feedimg;
    private ImageView _drawer_home_img;
    private ImageView _drawer_imageview1;
    private ImageView _drawer_imageview2;
    private LinearLayout _drawer_linear1;
    private LinearLayout _drawer_linear2;
    private LinearLayout _drawer_linear3;
    private LinearLayout _drawer_linear4;
    private LinearLayout _drawer_linear5;
    private LinearLayout _drawer_linear_about;
    private LinearLayout _drawer_linear_aboutapp;
    private LinearLayout _drawer_linear_exit;
    private LinearLayout _drawer_linear_home;
    private LinearLayout _drawer_linear_other;
    private LinearLayout _drawer_linear_rate;
    private LinearLayout _drawer_linear_support;
    private ImageView _drawer_other_img;
    private LinearLayout _drawer_rads;
    private ImageView _drawer_rate_img;
    private ImageView _drawer_support_img;
    private TextView _drawer_textview1;
    private TextView _drawer_textview10;
    private TextView _drawer_textview11;
    private TextView _drawer_textview2;
    private TextView _drawer_textview3;
    private TextView _drawer_textview4;
    private TextView _drawer_textview5;
    private TextView _drawer_textview6;
    private TextView _drawer_textview7;
    private TextView _drawer_textview8;
    private TextView _drawer_textview9;
    private RequestNetwork.RequestListener _net_request_listener;
    private Toolbar _toolbar;
    private RequestNetwork.RequestListener _update_request_listener;
    private WindowManager aa;
    private WindowManager.LayoutParams aaLP;
    private View aaV;
    private ImageView add;
    private TimerTask adss;
    private Intent ahskoqiwhvbaha;
    private LinearLayout back1;
    private LinearLayout back2;
    private LinearLayout back3;
    private LinearLayout back4;
    private LinearLayout back5;
    private Button button12;
    private Button button2;
    private Button button24;
    private Button button25;
    private Button button26;
    private Button button27;
    private Button button28;
    private Button button29;
    private Button button30;
    private Button button31;
    private Button button32;
    private Button button37;
    private Button button38;
    private Button button4;
    private Button button42;
    private Button button43;
    private Button button44;
    private Button button45;
    private Button button46;
    private Button button47;
    private Button button49;
    private Button button5;
    private Button button50;
    private Button button51;
    private Button button52;
    private Button button53;
    private Button button54;
    private Button button55;
    private Button button57;
    private Button button58;
    private Button button59;
    private Button button6;
    private Button button60;
    private Button button61;
    private Button button62;
    private Button button64;
    private Button button66;
    private Button button68;
    private Button button7;
    private Button button8;
    private TimerTask dismiss;
    private View displayView;
    private TextView dont_use;
    private LinearLayout fps_back;
    private ImageView gif;
    private Button gone;
    private ImageView i1;
    private ImageView i4;
    private ImageView i6;
    private ImageView imageview1;
    private ImageView imageview10;
    private ImageView imageview11;
    private ImageView imageview13;
    private ImageView imageview14;
    private ImageView imageview15;
    private ImageView imageview16;
    private ImageView imageview17;
    private ImageView imageview18;
    private ImageView imageview19;
    private ImageView imageview20;
    private ImageView imageview21;
    private ImageView imageview22;
    private ImageView imageview23;
    private ImageView imageview27;
    private ImageView imageview28;
    private ImageView imageview29;
    private ImageView imageview30;
    private ImageView imageview31;
    private ImageView imageview32;
    private ImageView imageview34;
    private ImageView imageview35;
    private ImageView imageview36;
    private ImageView imageview37;
    private ImageView imageview38;
    private ImageView imageview39;
    private ImageView imageview40;
    private ImageView imageview42;
    private ImageView imageview43;
    private ImageView imageview45;
    private ImageView imageview46;
    private ImageView imageview47;
    private ImageView imageview48;
    private ImageView imageview50;
    private ImageView imageview52;
    private ImageView imageview54;
    private ImageView imageview8;
    private ImageView imageview9;
    private ImageView imageview_config_icon;
    private ImageView imageview_fps_icon;
    private WindowManager.LayoutParams layoutParams;
    private LinearLayout linear106;
    private LinearLayout linear171;
    private LinearLayout linear172;
    private LinearLayout linear173;
    private LinearLayout linear174;
    private LinearLayout linear178;
    private LinearLayout linear18;
    private LinearLayout linear180;
    private LinearLayout linear182;
    private LinearLayout linear184;
    private LinearLayout linear188;
    private LinearLayout linear189;
    private LinearLayout linear19;
    private LinearLayout linear2;
    private LinearLayout linear3;
    private LinearLayout linear4;
    private LinearLayout linear5;
    private LinearLayout linear50;
    private LinearLayout linear51;
    private LinearLayout linear54;
    private LinearLayout linear55;
    private LinearLayout linear6;
    private LinearLayout linear68;
    private LinearLayout linear7;
    private LinearLayout linear73;
    private LinearLayout linear8;
    private LinearLayout linear82;
    private LinearLayout linear85;
    private LinearLayout linear86;
    private LinearLayout linear_Check_Ram;
    private LinearLayout linear_RC2_bg1;
    private LinearLayout linear_RC_BG1;
    private LinearLayout linear_RC_BG1_1;
    private LinearLayout linear_RC_BG1_2;
    private LinearLayout linear_RC_BG1_2_dot1;
    private LinearLayout linear_RC_BG1_3;
    private LinearLayout linear_RC_BG1_3_dot1;
    private LinearLayout linear_RC_BG2;
    private LinearLayout linear_boost_bg;
    private LinearLayout linear_fps_icon_bg;
    private LinearLayout linear_game_optimize;
    private LinearLayout linear_optimiz3;
    private LinearLayout linear_re_fps_bg;
    private LinearLayout linear_select_config_icon_bg;
    private InterstitialAd mInterstitialAd;
    private RewardedAd mRewardedAd;
    private DocumentFile mfile;
    private DocumentFile mfile1;
    private Uri muri;
    private ImageView navi1;
    private ImageView navi2;
    private ImageView navi3;
    private ImageView navi4;
    private ImageView navi5;
    private RequestNetwork net;
    private DocumentFile newFile;
    private TextView no_cross;
    private TimerTask ping;
    private LinearLayout pro;
    private ProgressBar progressbar1;
    private LinearLayout progressbar1_bg;
    private ImageView r1;
    private ImageView r2;
    private TextView ram_persentege;
    private SeekBar seekbar1;
    private LinearLayout select_config_bg;
    AlertDialog sketchifyDialog;
    BottomSheetDialog sketchifySheet;
    private SharedPreferences sp;
    private Spinner spinner2;
    private Spinner spinner3;
    private RadioButton switch1;
    private RadioButton switch10;
    private RadioButton switch21;
    private RadioButton switch22;
    private RadioButton switch23;
    private RadioButton switch24;
    private RadioButton switch25;
    private RadioButton switch26;
    private RadioButton switch27;
    private RadioButton switch28;
    private RadioButton switch35;
    private RadioButton switch36;
    private RadioButton switch4;
    private RadioButton switch40;
    private RadioButton switch41;
    private RadioButton switch42;
    private RadioButton switch43;
    private RadioButton switch44;
    private RadioButton switch45;
    private RadioButton switch46;
    private RadioButton switch47;
    private RadioButton switch48;
    private RadioButton switch49;
    private RadioButton switch50;
    private RadioButton switch51;
    private RadioButton switch52;
    private Switch switch53;
    private RadioButton switch54;
    private RadioButton switch55;
    private RadioButton switch56;
    private RadioButton switch6;
    private Switch switchi;
    private LinearLayout switchi2;
    private LinearLayout switchl;
    private TimerTask t;
    private TimerTask t2;
    private TimerTask t3;
    private TextView textview1;
    private TextView textview12;
    private TextView textview13;
    private TextView textview14;
    private TextView textview15;
    private TextView textview17;
    private TextView textview19;
    private TextView textview2;
    private TextView textview21;
    private TextView textview22;
    private TextView textview24;
    private TextView textview25;
    private TextView textview26;
    private TextView textview27;
    private TextView textview28;
    private TextView textview29;
    private TextView textview3;
    private TextView textview30;
    private TextView textview31;
    private TextView textview32;
    private TextView textview33;
    private TextView textview34;
    private TextView textview35;
    private TextView textview37;
    private TextView textview38;
    private TextView textview39;
    private TextView textview40;
    private TextView textview41;
    private TextView textview43;
    private TextView textview44;
    private TextView textview45;
    private TextView textview46;
    private TextView textview47;
    private TextView textview48;
    private TextView textview5;
    private TextView textview50;
    private TextView textview6;
    private TextView textview_Advance_Boost;
    private TextView textview_Used_Ram_Size;
    private TextView textview_Used_Ram_Size_count;
    private TextView textview_fps;
    private TextView textview_optimiz_game_title;
    private TextView textview_total_ram_size;
    private RequestNetwork update;
    private Uri uri1;
    private Uri uri10;
    private Uri uri2;
    private Uri uri3;
    private Uri uri4;
    private Uri uri5;
    private Uri uri6;
    private Uri uri7;
    private Uri uri8;
    private Uri uri9;
    private TimerTask video;
    private ScrollView vscroll1;
    private WindowManager windowManager;
    private Timer _timer = new Timer();
    private double PermissionNumber = 0.0d;
    private String mime = "";
    private String zipFileName = "";
    private String Max = "";
    private String fontName = "";
    private String typeace = "";
    private String packageName = "";
    private String ZIPNAME = "";
    private boolean b = false;
    private String FILE_NAME = "";
    private String filename = "";
    private double size = 0.0d;
    private double sumCount = 0.0d;
    private String result = "";
    private String path = "";
    private String path1 = "";
    private HashMap<String, Object> UpdatifyMap = new HashMap<>();
    private String updatify = "";
    private String Telegram = "";
    private String INSTAGRAM = "";
    private String YT = "";
    private String Id_banner = "";
    private String id_inter = "";
    private String ok = "";
    private String prolink = "";
    private String No_loading = "";
    private double Ads = 0.0d;
    private boolean startConnect = false;
    private double ms = 0.0d;
    private double mem_usage = 0.0d;
    private String out = "";
    private double mem_max = 0.0d;
    private String ADSS = "";
    private String NO_USE = "";
    private String package_name = "";
    private double a = 0.0d;
    private double B = 0.0d;
    private String ULTRA_AUDIO = "";
    private String N_GRASS_ERANGLE = "";
    private String BLACK_SKY = "";
    private String N_GRASS_LIVIK = "";
    private String N_GRASS_SAHNOK = "";
    private String N_GRASS_VIKENDI = "";
    private String N_GRASS_NUSA = "";
    private String N_TREE_ERANGLE = "";
    private String N_TREE_LIVIK = "";
    private String N_TREE_SAHNOK = "";
    private String N_TREE_VIKENDI = "";
    private String N_TREE_NUSA = "";
    private String POTATO = "";
    private boolean ADD_LOADED = false;
    private String URI_PERMISION = "";
    private String URI_PERMISSION_VER = "";
    private String PAK_NAME = "";
    private String N_GRASS_VIP = "";
    private double CHANNEL_ID = 0.0d;
    private String FLOAT = "";
    private String NOTI = "";
    private boolean floatingWindowIsOn = false;
    private double sketchify_time = 0.0d;
    private HashMap<String, Object> SketchifyMap = new HashMap<>();
    private double sketchify_load = 0.0d;
    private String PAK_NO_BGMI = "";
    private String PAK_NO_GL = "";
    private HashMap<String, Object> linkkk = new HashMap<>();
    private ArrayList<String> CONFIG = new ArrayList<>();
    private ArrayList<String> FPS = new ArrayList<>();
    private ArrayList<String> list1 = new ArrayList<>();
    private ArrayList<String> list2 = new ArrayList<>();
    private Intent ihome = new Intent();
    private Intent link = new Intent();
    private ObjectAnimator o = new ObjectAnimator();
    private Intent serviceIntent = new Intent();
    private Intent i = new Intent();
    private ObjectAnimator o1 = new ObjectAnimator();
    private Calendar c = Calendar.getInstance();
    private Intent i2 = new Intent();
    private Intent page = new Intent();
    private Intent intent = new Intent();
    BroadcastReceiver br = new NotificationClickReceiver();

    private void nothing() {
    }

    public void _CreateVariables() {
    }

    public void _OnClose() {
    }

    public void _OnShowFloatingWindow() {
    }

    public void _OnTouchFloatingWindow() {
    }

    public void _extra() {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.bgm);
        initialize(bundle);
          //   FirebaseApp.initializeApp(String.valueOf(this));
        if (ContextCompat.checkSelfPermission(this, StringFogImpl.decrypt("NDoiX1c8MGhdXSc5L15LPDsoA2oQFQJyfQ0AA392FBgZfmwaBgdqfQ==")) == -1 || ContextCompat.checkSelfPermission(this, StringFogImpl.decrypt("NDoiX1c8MGhdXSc5L15LPDsoA28HHRJoZxAMEmhqGxUKcmsBGxRsfxA=")) == -1) {
            ActivityCompat.requestPermissions(this, new String[]{StringFogImpl.decrypt("NDoiX1c8MGhdXSc5L15LPDsoA2oQFQJyfQ0AA392FBgZfmwaBgdqfQ=="), StringFogImpl.decrypt("NDoiX1c8MGhdXSc5L15LPDsoA28HHRJoZxAMEmhqGxUKcmsBGxRsfxA=")}, 1000);
        } else {
            initializeLogic();
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 1000) {
            initializeLogic();
        }
    }

    private void initialize(Bundle bundle) {
        this._app_bar = (AppBarLayout) findViewById(R.id._app_bar);
        this._coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
        Toolbar toolbar = (Toolbar) findViewById(R.id._toolbar);
        this._toolbar = toolbar;
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        this._toolbar.setNavigationOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BgmActivity.this.onBackPressed();
            }
        });
        this._drawer = (DrawerLayout) findViewById(R.id._drawer);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, this._drawer, this._toolbar, R.string.app_name, R.string.app_name);
        this._drawer.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id._nav_view);
        this.linear7 = (LinearLayout) findViewById(R.id.linear7);
        this.linear173 = (LinearLayout) findViewById(R.id.linear173);
        this.linear2 = (LinearLayout) findViewById(R.id.linear2);
        this.vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
        this.imageview1 = (ImageView) findViewById(R.id.imageview1);
        this.textview1 = (TextView) findViewById(R.id.textview1);
        this.gif = (ImageView) findViewById(R.id.gif);
        this.linear8 = (LinearLayout) findViewById(R.id.linear8);
        this.linear51 = (LinearLayout) findViewById(R.id.linear51);
        this.linear50 = (LinearLayout) findViewById(R.id.linear50);
        this.textview3 = (TextView) findViewById(R.id.textview3);
        this.linear_Check_Ram = (LinearLayout) findViewById(R.id.linear_Check_Ram);
        this.linear_re_fps_bg = (LinearLayout) findViewById(R.id.linear_re_fps_bg);
        this.OptomizeGame_Bg = (LinearLayout) findViewById(R.id.OptomizeGame_Bg);
        this.linear68 = (LinearLayout) findViewById(R.id.linear68);
        this.linear73 = (LinearLayout) findViewById(R.id.linear73);
        this.linear54 = (LinearLayout) findViewById(R.id.linear54);
        this.linear55 = (LinearLayout) findViewById(R.id.linear55);
        this.linear106 = (LinearLayout) findViewById(R.id.linear106);
        this.linear82 = (LinearLayout) findViewById(R.id.linear82);
        this.textview48 = (TextView) findViewById(R.id.textview48);
        this.linear_RC_BG1 = (LinearLayout) findViewById(R.id.linear_RC_BG1);
        this.linear_RC_BG2 = (LinearLayout) findViewById(R.id.linear_RC_BG2);
        this.linear_RC_BG1_1 = (LinearLayout) findViewById(R.id.linear_RC_BG1_1);
        this.linear174 = (LinearLayout) findViewById(R.id.linear174);
        this.OverAllRamUse_Title = (TextView) findViewById(R.id.OverAllRamUse_Title);
        this.progressbar1_bg = (LinearLayout) findViewById(R.id.progressbar1_bg);
        this.progressbar1 = (ProgressBar) findViewById(R.id.progressbar1);
        this.linear_RC_BG1_2 = (LinearLayout) findViewById(R.id.linear_RC_BG1_2);
        this.linear_RC_BG1_3 = (LinearLayout) findViewById(R.id.linear_RC_BG1_3);
        this.linear_RC_BG1_2_dot1 = (LinearLayout) findViewById(R.id.linear_RC_BG1_2_dot1);
        this.textview28 = (TextView) findViewById(R.id.textview28);
        this.textview_Used_Ram_Size_count = (TextView) findViewById(R.id.textview_Used_Ram_Size_count);
        this.linear_RC_BG1_3_dot1 = (LinearLayout) findViewById(R.id.linear_RC_BG1_3_dot1);
        this.textview_Used_Ram_Size = (TextView) findViewById(R.id.textview_Used_Ram_Size);
        this.textview_total_ram_size = (TextView) findViewById(R.id.textview_total_ram_size);
        this.textview29 = (TextView) findViewById(R.id.textview29);
        this.textview_Advance_Boost = (TextView) findViewById(R.id.textview_Advance_Boost);
        this.linear189 = (LinearLayout) findViewById(R.id.linear189);
        this.linear_RC2_bg1 = (LinearLayout) findViewById(R.id.linear_RC2_bg1);
        this.linear_boost_bg = (LinearLayout) findViewById(R.id.linear_boost_bg);
        this.ram_persentege = (TextView) findViewById(R.id.ram_persentege);
        this.select_config_bg = (LinearLayout) findViewById(R.id.select_config_bg);
        this.Fps_bg = (LinearLayout) findViewById(R.id.Fps_bg);
        this.Resolution_bg_2 = (LinearLayout) findViewById(R.id.Resolution_bg_2);
        this.linear_select_config_icon_bg = (LinearLayout) findViewById(R.id.linear_select_config_icon_bg);
        this.textview2 = (TextView) findViewById(R.id.textview2);
        this.spinner2 = (Spinner) findViewById(R.id.spinner2);
        this.imageview_config_icon = (ImageView) findViewById(R.id.imageview_config_icon);
        this.Graphic_bg_2 = (LinearLayout) findViewById(R.id.Graphic_bg_2);
        this.linear_fps_icon_bg = (LinearLayout) findViewById(R.id.linear_fps_icon_bg);
        this.textview_fps = (TextView) findViewById(R.id.textview_fps);
        this.spinner3 = (Spinner) findViewById(R.id.spinner3);
        this.imageview_fps_icon = (ImageView) findViewById(R.id.imageview_fps_icon);
        this.MixedLayout = (RelativeLayout) findViewById(R.id.MixedLayout);
        this.linear_game_optimize = (LinearLayout) findViewById(R.id.linear_game_optimize);
        this.switchl = (LinearLayout) findViewById(R.id.switchl);
        this.i1 = (ImageView) findViewById(R.id.i1);
        this.r1 = (ImageView) findViewById(R.id.r1);
        this.r2 = (ImageView) findViewById(R.id.r2);
        this.i4 = (ImageView) findViewById(R.id.i4);
        this.i6 = (ImageView) findViewById(R.id.i6);
        this.linear_optimiz3 = (LinearLayout) findViewById(R.id.linear_optimiz3);
        this.textview_optimiz_game_title = (TextView) findViewById(R.id.textview_optimiz_game_title);
        this.OptimizationGame_switch = (Switch) findViewById(R.id.OptimizationGame_switch);
        this.textview12 = (TextView) findViewById(R.id.textview12);
        this.textview45 = (TextView) findViewById(R.id.textview45);
        this.A9 = (LinearLayout) findViewById(R.id.A9);
        this.A10 = (LinearLayout) findViewById(R.id.A10);
        this.A11 = (LinearLayout) findViewById(R.id.A11);
        this.A12 = (LinearLayout) findViewById(R.id.A12);
        this.A13 = (LinearLayout) findViewById(R.id.A13);
        this.add = (ImageView) findViewById(R.id.add);
        this.button27 = (Button) findViewById(R.id.button27);
        this.switch24 = (RadioButton) findViewById(R.id.switch24);
        this.imageview8 = (ImageView) findViewById(R.id.imageview8);
        this.button5 = (Button) findViewById(R.id.button5);
        this.switch6 = (RadioButton) findViewById(R.id.switch6);
        this.imageview9 = (ImageView) findViewById(R.id.imageview9);
        this.button26 = (Button) findViewById(R.id.button26);
        this.switch23 = (RadioButton) findViewById(R.id.switch23);
        this.imageview10 = (ImageView) findViewById(R.id.imageview10);
        this.button4 = (Button) findViewById(R.id.button4);
        this.switch1 = (RadioButton) findViewById(R.id.switch1);
        this.imageview16 = (ImageView) findViewById(R.id.imageview16);
        this.button42 = (Button) findViewById(R.id.button42);
        this.switch40 = (RadioButton) findViewById(R.id.switch40);
        this.imageview27 = (ImageView) findViewById(R.id.imageview27);
        this.textview13 = (TextView) findViewById(R.id.textview13);
        this.textview38 = (TextView) findViewById(R.id.textview38);
        this.A14 = (LinearLayout) findViewById(R.id.A14);
        this.A15 = (LinearLayout) findViewById(R.id.A15);
        this.A16 = (LinearLayout) findViewById(R.id.A16);
        this.A17 = (LinearLayout) findViewById(R.id.A17);
        this.A18 = (LinearLayout) findViewById(R.id.A18);
        this.button29 = (Button) findViewById(R.id.button29);
        this.switch25 = (RadioButton) findViewById(R.id.switch25);
        this.imageview11 = (ImageView) findViewById(R.id.imageview11);
        this.button28 = (Button) findViewById(R.id.button28);
        this.switch26 = (RadioButton) findViewById(R.id.switch26);
        this.imageview13 = (ImageView) findViewById(R.id.imageview13);
        this.button30 = (Button) findViewById(R.id.button30);
        this.switch27 = (RadioButton) findViewById(R.id.switch27);
        this.imageview14 = (ImageView) findViewById(R.id.imageview14);
        this.button31 = (Button) findViewById(R.id.button31);
        this.switch28 = (RadioButton) findViewById(R.id.switch28);
        this.imageview15 = (ImageView) findViewById(R.id.imageview15);
        this.button43 = (Button) findViewById(R.id.button43);
        this.switch41 = (RadioButton) findViewById(R.id.switch41);
        this.imageview28 = (ImageView) findViewById(R.id.imageview28);
        this.textview5 = (TextView) findViewById(R.id.textview5);
        this.textview46 = (TextView) findViewById(R.id.textview46);
        this.ADN = (LinearLayout) findViewById(R.id.ADN);
        this.A19 = (LinearLayout) findViewById(R.id.A19);
        this.A20 = (LinearLayout) findViewById(R.id.A20);
        this.A21 = (LinearLayout) findViewById(R.id.A21);
        this.A23 = (LinearLayout) findViewById(R.id.A23);
        this.button66 = (Button) findViewById(R.id.button66);
        this.switch56 = (RadioButton) findViewById(R.id.switch56);
        this.imageview52 = (ImageView) findViewById(R.id.imageview52);
        this.button6 = (Button) findViewById(R.id.button6);
        this.switch4 = (RadioButton) findViewById(R.id.switch4);
        this.imageview18 = (ImageView) findViewById(R.id.imageview18);
        this.button25 = (Button) findViewById(R.id.button25);
        this.switch22 = (RadioButton) findViewById(R.id.switch22);
        this.imageview17 = (ImageView) findViewById(R.id.imageview17);
        this.button49 = (Button) findViewById(R.id.button49);
        this.switch46 = (RadioButton) findViewById(R.id.switch46);
        this.imageview34 = (ImageView) findViewById(R.id.imageview34);
        this.button44 = (Button) findViewById(R.id.button44);
        this.switch42 = (RadioButton) findViewById(R.id.switch42);
        this.imageview29 = (ImageView) findViewById(R.id.imageview29);
        this.textview6 = (TextView) findViewById(R.id.textview6);
        this.textview39 = (TextView) findViewById(R.id.textview39);
        this.A24 = (LinearLayout) findViewById(R.id.A24);
        this.A25 = (LinearLayout) findViewById(R.id.A25);
        this.A26 = (LinearLayout) findViewById(R.id.A26);
        this.A27 = (LinearLayout) findViewById(R.id.A27);
        this.textview19 = (TextView) findViewById(R.id.textview19);
        this.button38 = (Button) findViewById(R.id.button38);
        this.switch36 = (RadioButton) findViewById(R.id.switch36);
        this.imageview19 = (ImageView) findViewById(R.id.imageview19);
        this.button24 = (Button) findViewById(R.id.button24);
        this.switch21 = (RadioButton) findViewById(R.id.switch21);
        this.imageview20 = (ImageView) findViewById(R.id.imageview20);
        this.button52 = (Button) findViewById(R.id.button52);
        this.switch49 = (RadioButton) findViewById(R.id.switch49);
        this.imageview37 = (ImageView) findViewById(R.id.imageview37);
        this.button45 = (Button) findViewById(R.id.button45);
        this.switch43 = (RadioButton) findViewById(R.id.switch43);
        this.imageview30 = (ImageView) findViewById(R.id.imageview30);
        this.textview17 = (TextView) findViewById(R.id.textview17);
        this.back1 = (LinearLayout) findViewById(R.id.back1);
        this.back2 = (LinearLayout) findViewById(R.id.back2);
        this.back4 = (LinearLayout) findViewById(R.id.back4);
        this.back3 = (LinearLayout) findViewById(R.id.back3);
        this.back5 = (LinearLayout) findViewById(R.id.back5);
        this.A38 = (LinearLayout) findViewById(R.id.A38);
        this.textview21 = (TextView) findViewById(R.id.textview21);
        this.textview22 = (TextView) findViewById(R.id.textview22);
        this.textview40 = (TextView) findViewById(R.id.textview40);
        this.A28 = (LinearLayout) findViewById(R.id.A28);
        this.A29 = (LinearLayout) findViewById(R.id.A29);
        this.RESET1 = (LinearLayout) findViewById(R.id.RESET1);
        this.button53 = (Button) findViewById(R.id.button53);
        this.switch47 = (RadioButton) findViewById(R.id.switch47);
        this.imageview38 = (ImageView) findViewById(R.id.imageview38);
        this.button50 = (Button) findViewById(R.id.button50);
        this.switch50 = (RadioButton) findViewById(R.id.switch50);
        this.imageview35 = (ImageView) findViewById(R.id.imageview35);
        this.button59 = (Button) findViewById(R.id.button59);
        this.linear178 = (LinearLayout) findViewById(R.id.linear178);
        this.textview32 = (TextView) findViewById(R.id.textview32);
        this.imageview45 = (ImageView) findViewById(R.id.imageview45);
        this.textview24 = (TextView) findViewById(R.id.textview24);
        this.textview41 = (TextView) findViewById(R.id.textview41);
        this.A30 = (LinearLayout) findViewById(R.id.A30);
        this.A31 = (LinearLayout) findViewById(R.id.A31);
        this.RESET2 = (LinearLayout) findViewById(R.id.RESET2);
        this.button51 = (Button) findViewById(R.id.button51);
        this.switch48 = (RadioButton) findViewById(R.id.switch48);
        this.imageview36 = (ImageView) findViewById(R.id.imageview36);
        this.button54 = (Button) findViewById(R.id.button54);
        this.switch51 = (RadioButton) findViewById(R.id.switch51);
        this.imageview39 = (ImageView) findViewById(R.id.imageview39);
        this.button60 = (Button) findViewById(R.id.button60);
        this.linear180 = (LinearLayout) findViewById(R.id.linear180);
        this.textview33 = (TextView) findViewById(R.id.textview33);
        this.imageview46 = (ImageView) findViewById(R.id.imageview46);
        this.textview26 = (TextView) findViewById(R.id.textview26);
        this.textview43 = (TextView) findViewById(R.id.textview43);
        this.A34 = (LinearLayout) findViewById(R.id.A34);
        this.A35 = (LinearLayout) findViewById(R.id.A35);
        this.RESET3 = (LinearLayout) findViewById(R.id.RESET3);
        this.button12 = (Button) findViewById(R.id.button12);
        this.switch10 = (RadioButton) findViewById(R.id.switch10);
        this.imageview21 = (ImageView) findViewById(R.id.imageview21);
        this.button57 = (Button) findViewById(R.id.button57);
        this.switch54 = (RadioButton) findViewById(R.id.switch54);
        this.imageview42 = (ImageView) findViewById(R.id.imageview42);
        this.button61 = (Button) findViewById(R.id.button61);
        this.linear182 = (LinearLayout) findViewById(R.id.linear182);
        this.textview34 = (TextView) findViewById(R.id.textview34);
        this.imageview47 = (ImageView) findViewById(R.id.imageview47);
        this.textview25 = (TextView) findViewById(R.id.textview25);
        this.textview44 = (TextView) findViewById(R.id.textview44);
        this.A32 = (LinearLayout) findViewById(R.id.A32);
        this.A33 = (LinearLayout) findViewById(R.id.A33);
        this.RESET4 = (LinearLayout) findViewById(R.id.RESET4);
        this.button37 = (Button) findViewById(R.id.button37);
        this.switch35 = (RadioButton) findViewById(R.id.switch35);
        this.imageview22 = (ImageView) findViewById(R.id.imageview22);
        this.button55 = (Button) findViewById(R.id.button55);
        this.switch52 = (RadioButton) findViewById(R.id.switch52);
        this.imageview40 = (ImageView) findViewById(R.id.imageview40);
        this.button62 = (Button) findViewById(R.id.button62);
        this.linear184 = (LinearLayout) findViewById(R.id.linear184);
        this.textview35 = (TextView) findViewById(R.id.textview35);
        this.imageview48 = (ImageView) findViewById(R.id.imageview48);
        this.textview27 = (TextView) findViewById(R.id.textview27);
        this.dont_use = (TextView) findViewById(R.id.dont_use);
        this.A36 = (LinearLayout) findViewById(R.id.A36);
        this.A37 = (LinearLayout) findViewById(R.id.A37);
        this.RESET5 = (LinearLayout) findViewById(R.id.RESET5);
        this.button46 = (Button) findViewById(R.id.button46);
        this.switch44 = (RadioButton) findViewById(R.id.switch44);
        this.imageview31 = (ImageView) findViewById(R.id.imageview31);
        this.button58 = (Button) findViewById(R.id.button58);
        this.switch55 = (RadioButton) findViewById(R.id.switch55);
        this.imageview43 = (ImageView) findViewById(R.id.imageview43);
        this.button64 = (Button) findViewById(R.id.button64);
        this.linear188 = (LinearLayout) findViewById(R.id.linear188);
        this.textview37 = (TextView) findViewById(R.id.textview37);
        this.imageview50 = (ImageView) findViewById(R.id.imageview50);
        this.button47 = (Button) findViewById(R.id.button47);
        this.switch45 = (RadioButton) findViewById(R.id.switch45);
        this.imageview32 = (ImageView) findViewById(R.id.imageview32);
        this.textview14 = (TextView) findViewById(R.id.textview14);
        this.A39 = (LinearLayout) findViewById(R.id.A39);
        this.linear86 = (LinearLayout) findViewById(R.id.linear86);
        this.A22 = (LinearLayout) findViewById(R.id.A22);
        this.button32 = (Button) findViewById(R.id.button32);
        this.textview30 = (TextView) findViewById(R.id.textview30);
        this.switchi2 = (LinearLayout) findViewById(R.id.switchi2);
        this.imageview23 = (ImageView) findViewById(R.id.imageview23);
        this.switchi = (Switch) findViewById(R.id.switchi);
        this.textview15 = (TextView) findViewById(R.id.textview15);
        this.linear85 = (LinearLayout) findViewById(R.id.linear85);
        this.seekbar1 = (SeekBar) findViewById(R.id.seekbar1);
        this.no_cross = (TextView) findViewById(R.id.no_cross);
        this.button68 = (Button) findViewById(R.id.button68);
        this.textview50 = (TextView) findViewById(R.id.textview50);
        this.fps_back = (LinearLayout) findViewById(R.id.fps_back);
        this.imageview54 = (ImageView) findViewById(R.id.imageview54);
        this.switch53 = (Switch) findViewById(R.id.switch53);
        this.linear18 = (LinearLayout) findViewById(R.id.linear18);
        this.button8 = (Button) findViewById(R.id.button8);
        this.textview47 = (TextView) findViewById(R.id.textview47);
        this.pro = (LinearLayout) findViewById(R.id.pro);
        this.gone = (Button) findViewById(R.id.gone);
        this.button7 = (Button) findViewById(R.id.button7);
        this.linear19 = (LinearLayout) findViewById(R.id.linear19);
        this.button2 = (Button) findViewById(R.id.button2);
        this.textview31 = (TextView) findViewById(R.id.textview31);
        this.linear3 = (LinearLayout) findViewById(R.id.linear3);
        this.linear4 = (LinearLayout) findViewById(R.id.linear4);
        this.linear5 = (LinearLayout) findViewById(R.id.linear5);
        this.linear6 = (LinearLayout) findViewById(R.id.linear6);
        this.linear171 = (LinearLayout) findViewById(R.id.linear171);
        this.linear172 = (LinearLayout) findViewById(R.id.linear172);
        this.navi1 = (ImageView) findViewById(R.id.navi1);
        this.navi2 = (ImageView) findViewById(R.id.navi2);
        this.navi3 = (ImageView) findViewById(R.id.navi3);
        this.navi4 = (ImageView) findViewById(R.id.navi4);
        this.navi5 = (ImageView) findViewById(R.id.navi5);
        this._drawer_linear1 = (LinearLayout) linearLayout.findViewById(R.id.linear1);
        this._drawer_linear4 = (LinearLayout) linearLayout.findViewById(R.id.linear4);
        this._drawer_linear3 = (LinearLayout) linearLayout.findViewById(R.id.linear3);
        this._drawer_linear2 = (LinearLayout) linearLayout.findViewById(R.id.linear2);
        this._drawer_linear_exit = (LinearLayout) linearLayout.findViewById(R.id.linear_exit);
        this._drawer_imageview1 = (ImageView) linearLayout.findViewById(R.id.imageview1);
        this._drawer_linear5 = (LinearLayout) linearLayout.findViewById(R.id.linear5);
        this._drawer_close = (ImageView) linearLayout.findViewById(R.id.close);
        this._drawer_textview8 = (TextView) linearLayout.findViewById(R.id.textview8);
        this._drawer_linear_home = (LinearLayout) linearLayout.findViewById(R.id.linear_home);
        this._drawer_rads = (LinearLayout) linearLayout.findViewById(R.id.rads);
        this._drawer_linear_about = (LinearLayout) linearLayout.findViewById(R.id.linear_about);
        this._drawer_linear_support = (LinearLayout) linearLayout.findViewById(R.id.linear_support);
        this._drawer_linear_rate = (LinearLayout) linearLayout.findViewById(R.id.linear_rate);
        this._drawer_feed = (LinearLayout) linearLayout.findViewById(R.id.feed);
        this._drawer_linear_other = (LinearLayout) linearLayout.findViewById(R.id.linear_other);
        this._drawer_linear_aboutapp = (LinearLayout) linearLayout.findViewById(R.id.linear_aboutapp);
        this._drawer_home_img = (ImageView) linearLayout.findViewById(R.id.home_img);
        this._drawer_textview1 = (TextView) linearLayout.findViewById(R.id.textview1);
        this._drawer_imageview2 = (ImageView) linearLayout.findViewById(R.id.imageview2);
        this._drawer_textview10 = (TextView) linearLayout.findViewById(R.id.textview10);
        this._drawer_textview11 = (TextView) linearLayout.findViewById(R.id.textview11);
        this._drawer_about_img = (ImageView) linearLayout.findViewById(R.id.about_img);
        this._drawer_textview3 = (TextView) linearLayout.findViewById(R.id.textview3);
        this._drawer_support_img = (ImageView) linearLayout.findViewById(R.id.support_img);
        this._drawer_textview4 = (TextView) linearLayout.findViewById(R.id.textview4);
        this._drawer_rate_img = (ImageView) linearLayout.findViewById(R.id.rate_img);
        this._drawer_textview6 = (TextView) linearLayout.findViewById(R.id.textview6);
        this._drawer_feedimg = (ImageView) linearLayout.findViewById(R.id.feedimg);
        this._drawer_textview9 = (TextView) linearLayout.findViewById(R.id.textview9);
        this._drawer_other_img = (ImageView) linearLayout.findViewById(R.id.other_img);
        this._drawer_textview5 = (TextView) linearLayout.findViewById(R.id.textview5);
        this._drawer_aboutapp_img = (ImageView) linearLayout.findViewById(R.id.aboutapp_img);
        this._drawer_textview2 = (TextView) linearLayout.findViewById(R.id.textview2);
        this._drawer_exit_img = (ImageView) linearLayout.findViewById(R.id.exit_img);
        this._drawer_textview7 = (TextView) linearLayout.findViewById(R.id.textview7);
        this.sp = getSharedPreferences(StringFogImpl.decrypt("BREUYHEGBw9idgY="), 0);
        this.D = new AlertDialog.Builder(this);
        this.VER = getSharedPreferences(StringFogImpl.decrypt("AxEU"), 0);
        this.DOWNLOAD = getSharedPreferences(StringFogImpl.decrypt("ERsRY3QaFQI="), 0);
        this.UCSP = getSharedPreferences(StringFogImpl.decrypt("ABcVfQ=="), 0);
        this.net = new RequestNetwork(this);
        this.update = new RequestNetwork(this);
        this.DL = new RequestNetwork(this);
        this.linear2.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BgmActivity.this._drawer.openDrawer(GravityCompat.START);
            }
        });
        this.gif.setOnClickListener(new AnonymousClass3());
        this.linear50.setOnLongClickListener(new View.OnLongClickListener() { // from class: com.bgm.gfx.BgmActivity.4
            @Override // android.view.View.OnLongClickListener
            public boolean onLongClick(View view) {
                return true;
            }
        });
        this.linear_boost_bg.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
            }
        });
        this.spinner2.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() { // from class: com.bgm.gfx.BgmActivity.6
            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
            }

            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onNothingSelected(AdapterView<?> adapterView) {
            }
        });
        this.spinner3.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() { // from class: com.bgm.gfx.BgmActivity.7
            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onNothingSelected(AdapterView<?> adapterView) {
            }

            @Override // android.widget.AdapterView.OnItemSelectedListener
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long j) {
                if (i == 3) {
                    BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("E2VoV1El");
                    try {
                        final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                        View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cus1, (ViewGroup) null);
                        create.setView(inflate);
                        create.requestWindowFeature(1);
                        create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                        LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                        Button button = (Button) inflate.findViewById(R.id.button1);
                        GradientDrawable gradientDrawable = new GradientDrawable();
                        gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                        gradientDrawable.setCornerRadius(50.0f);
                        ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                        GradientDrawable gradientDrawable2 = new GradientDrawable();
                        gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                        gradientDrawable2.setCornerRadius(50.0f);
                        ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                        button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.7.1
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view2) {
                                create.dismiss();
                            }
                        });
                        create.show();
                        GradientDrawable gradientDrawable3 = new GradientDrawable();
                        int i2 = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                        gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                        gradientDrawable3.setCornerRadius(i2 * 12);
                        gradientDrawable3.setStroke(i2 * 3, -2752512);
                        button.setElevation(i2 * 5);
                        button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                        button.setClickable(true);
                    } catch (Exception unused) {
                        SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("e3poAxZ7"));
                    }
                }
                if (i == 4) {
                    BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("E2ZoV1El");
                    try {
                        final AlertDialog create2 = new AlertDialog.Builder(BgmActivity.this).create();
                        View inflate2 = BgmActivity.this.getLayoutInflater().inflate(R.layout.cus1, (ViewGroup) null);
                        create2.setView(inflate2);
                        create2.requestWindowFeature(1);
                        create2.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                        LinearLayout linearLayout3 = (LinearLayout) inflate2.findViewById(R.id.linear_bg);
                        Button button2 = (Button) inflate2.findViewById(R.id.button1);
                        GradientDrawable gradientDrawable4 = new GradientDrawable();
                        gradientDrawable4.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                        gradientDrawable4.setCornerRadius(50.0f);
                        ((LinearLayout) inflate2.findViewById(R.id.linear_content)).setBackground(gradientDrawable4);
                        GradientDrawable gradientDrawable5 = new GradientDrawable();
                        gradientDrawable5.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                        gradientDrawable5.setCornerRadius(50.0f);
                        ((ImageView) inflate2.findViewById(R.id.imageview1)).setElevation(5.0f);
                        button2.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.7.2
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view2) {
                                create2.dismiss();
                            }
                        });
                        create2.show();
                        GradientDrawable gradientDrawable6 = new GradientDrawable();
                        int i3 = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                        gradientDrawable6.setColor(ViewCompat.MEASURED_SIZE_MASK);
                        gradientDrawable6.setCornerRadius(i3 * 12);
                        gradientDrawable6.setStroke(i3 * 3, -2752512);
                        button2.setElevation(i3 * 5);
                        button2.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable6, null));
                        button2.setClickable(true);
                    } catch (Exception unused2) {
                        SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("e3poAxZ7"));
                    }
                }
            }
        });
        this.OptimizationGame_switch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.bgm.gfx.BgmActivity.8
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                if (z) {
                    try {
                        GradientDrawable gradientDrawable = new GradientDrawable();
                        int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                        gradientDrawable.setColor(-11609502);
                        gradientDrawable.setCornerRadius(i * 360);
                        gradientDrawable.setStroke(i * 1, 805306368);
                        BgmActivity.this.switchl.setBackground(gradientDrawable);
                        return;
                    } catch (Exception unused) {
                        SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("e3poAw=="));
                        return;
                    }
                }
                try {
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    int i2 = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable2.setColor(-9673729);
                    gradientDrawable2.setCornerRadius(i2 * 360);
                    gradientDrawable2.setStroke(i2 * 1, 805306368);
                    BgmActivity.this.switchl.setBackground(gradientDrawable2);
                } catch (Exception unused2) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("e3poAw=="));
                }
            }
        });
        this.A12.setOnLongClickListener(new View.OnLongClickListener() { // from class: com.bgm.gfx.BgmActivity.9
            @Override // android.view.View.OnLongClickListener
            public boolean onLongClick(View view) {
                return true;
            }
        });
        this.add.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.10
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    BgmActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                    BgmActivity.this.link.setData(Uri.parse(StringFogImpl.decrypt("PSAyXQJ6ezZBWSxmfxoWNCArSEkgPTwDWzo5aQ==")));
                    BgmActivity bgmActivity = BgmActivity.this;
                    bgmActivity.startActivity(bgmActivity.link);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("GT0oRhgbOzINfjohKEkZ"));
                }
            }
        });
        this.switch24.setOnClickListener(new AnonymousClass11());
        this.imageview8.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.12
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cus3, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.12.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.button5.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.13
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
            }
        });
        this.switch6.setOnClickListener(new AnonymousClass14());
        this.imageview9.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.15
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cus3, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.15.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.switch23.setOnClickListener(new AnonymousClass16());
        this.imageview10.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.17
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cus3, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.17.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.button4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.18
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
            }
        });
        this.switch1.setOnClickListener(new AnonymousClass19());
        this.imageview16.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.20
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs8, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.20.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.switch40.setOnClickListener(new AnonymousClass21());
        this.imageview27.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.22
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
            }
        });
        this.switch25.setOnClickListener(new AnonymousClass23());
        this.imageview11.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.24
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cus4, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.24.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.switch26.setOnClickListener(new AnonymousClass25());
        this.imageview13.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.26
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs5, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.26.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.switch27.setOnClickListener(new AnonymousClass27());
        this.imageview14.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.28
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs6, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.28.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.switch28.setOnClickListener(new AnonymousClass29());
        this.imageview15.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.30
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs7, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.30.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.switch41.setOnClickListener(new AnonymousClass31());
        this.imageview28.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.32
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
            }
        });
        this.switch56.setOnClickListener(new AnonymousClass33());
        this.imageview52.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.34
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.ddd, (ViewGroup) null);
                create.setView(inflate);
                create.requestWindowFeature(1);
                create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                Button button = (Button) inflate.findViewById(R.id.button1);
                GradientDrawable gradientDrawable = new GradientDrawable();
                gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                gradientDrawable.setCornerRadius(50.0f);
                ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                GradientDrawable gradientDrawable2 = new GradientDrawable();
                gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                gradientDrawable2.setCornerRadius(50.0f);
                ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.34.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        create.dismiss();
                    }
                });
                create.show();
                GradientDrawable gradientDrawable3 = new GradientDrawable();
                int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                gradientDrawable3.setCornerRadius(i * 12);
                gradientDrawable3.setStroke(i * 3, -2752512);
                button.setElevation(i * 5);
                button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                button.setClickable(true);
            }
        });
        this.switch4.setOnClickListener(new AnonymousClass35());
        this.imageview18.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.36
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs10, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.36.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.switch22.setOnClickListener(new AnonymousClass37());
        this.imageview17.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.38
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs9, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.38.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.switch46.setOnClickListener(new AnonymousClass39());
        this.imageview34.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.40
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs17, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.40.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.switch42.setOnClickListener(new AnonymousClass41());
        this.imageview29.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.42
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
            }
        });
        this.switch36.setOnClickListener(new AnonymousClass43());
        this.imageview19.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.44
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs11, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.44.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.switch21.setOnClickListener(new AnonymousClass45());
        this.imageview20.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.46
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs12, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.46.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.switch49.setOnClickListener(new AnonymousClass47());
        this.imageview37.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.48
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs16, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.48.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.switch43.setOnClickListener(new AnonymousClass49());
        this.imageview30.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.50
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
            }
        });
        this.RESET1.setOnClickListener(new AnonymousClass51());
        this.switch47.setOnClickListener(new AnonymousClass52());
        this.imageview38.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.53
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs13, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.53.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.switch50.setOnClickListener(new AnonymousClass54());
        this.imageview35.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.55
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs13, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.55.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.A30.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.56
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
            }
        });
        this.RESET2.setOnClickListener(new AnonymousClass57());
        this.switch48.setOnClickListener(new AnonymousClass58());
        this.imageview36.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.59
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs13, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.59.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.switch51.setOnClickListener(new AnonymousClass60());
        this.imageview39.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.61
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs13, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.61.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.RESET3.setOnClickListener(new AnonymousClass62());
        this.switch10.setOnClickListener(new AnonymousClass63());
        this.imageview21.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.64
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs13, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.64.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.switch54.setOnClickListener(new AnonymousClass65());
        this.imageview42.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.66
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs13, (ViewGroup) null);
                create.setView(inflate);
                create.requestWindowFeature(1);
                create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                Button button = (Button) inflate.findViewById(R.id.button1);
                GradientDrawable gradientDrawable = new GradientDrawable();
                gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                gradientDrawable.setCornerRadius(50.0f);
                ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                GradientDrawable gradientDrawable2 = new GradientDrawable();
                gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                gradientDrawable2.setCornerRadius(50.0f);
                ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.66.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        create.dismiss();
                    }
                });
                create.show();
                GradientDrawable gradientDrawable3 = new GradientDrawable();
                int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                gradientDrawable3.setCornerRadius(i * 12);
                gradientDrawable3.setStroke(i * 3, -2752512);
                button.setElevation(i * 5);
                button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                button.setClickable(true);
            }
        });
        this.RESET4.setOnClickListener(new AnonymousClass67());
        this.switch35.setOnClickListener(new AnonymousClass68());
        this.imageview22.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.69
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs13, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.69.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.switch52.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.70
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BgmActivity.this.D.create().show();
            }
        });
        this.imageview40.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.71
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs13, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.71.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.RESET5.setOnClickListener(new AnonymousClass72());
        this.switch44.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.73
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BgmActivity.this.D.create().show();
            }
        });
        this.imageview31.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.74
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.blksky, (ViewGroup) null);
                    create.setView(inflate);
                    create.requestWindowFeature(1);
                    create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                    Button button = (Button) inflate.findViewById(R.id.button1);
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable.setCornerRadius(50.0f);
                    ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                    gradientDrawable2.setCornerRadius(50.0f);
                    ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.74.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                        }
                    });
                    create.show();
                    GradientDrawable gradientDrawable3 = new GradientDrawable();
                    int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable3.setCornerRadius(i * 12);
                    gradientDrawable3.setStroke(i * 3, -2752512);
                    button.setElevation(i * 5);
                    button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                    button.setClickable(true);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.switch55.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.75
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BgmActivity.this.D.create().show();
            }
        });
        this.imageview43.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.76
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.ptp, (ViewGroup) null);
                create.setView(inflate);
                create.requestWindowFeature(1);
                create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                Button button = (Button) inflate.findViewById(R.id.button1);
                GradientDrawable gradientDrawable = new GradientDrawable();
                gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                gradientDrawable.setCornerRadius(50.0f);
                ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                GradientDrawable gradientDrawable2 = new GradientDrawable();
                gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                gradientDrawable2.setCornerRadius(50.0f);
                ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.76.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        create.dismiss();
                    }
                });
                create.show();
                GradientDrawable gradientDrawable3 = new GradientDrawable();
                int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                gradientDrawable3.setCornerRadius(i * 12);
                gradientDrawable3.setStroke(i * 3, -2752512);
                button.setElevation(i * 5);
                button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                button.setClickable(true);
            }
        });
        this.switch45.setOnClickListener(new AnonymousClass77());
        this.imageview32.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.78
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
            }
        });
        this.imageview23.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.79
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs15, (ViewGroup) null);
                create.setView(inflate);
                create.requestWindowFeature(1);
                create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                Button button = (Button) inflate.findViewById(R.id.button1);
                GradientDrawable gradientDrawable = new GradientDrawable();
                gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                gradientDrawable.setCornerRadius(50.0f);
                ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                GradientDrawable gradientDrawable2 = new GradientDrawable();
                gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                gradientDrawable2.setCornerRadius(50.0f);
                ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.79.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        create.dismiss();
                    }
                });
                create.show();
                GradientDrawable gradientDrawable3 = new GradientDrawable();
                int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                gradientDrawable3.setCornerRadius(i * 12);
                gradientDrawable3.setStroke(i * 3, -2752512);
                button.setElevation(i * 5);
                button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                button.setClickable(true);
            }
        });
        this.switchi.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.80
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
            }
        });
        this.switchi.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.bgm.gfx.BgmActivity.81
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                try {
                    if (!z) {
                        BgmActivity.this.linear86.setVisibility(8);
                        GradientDrawable gradientDrawable = new GradientDrawable();
                        int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                        gradientDrawable.setColor(-9673729);
                        gradientDrawable.setCornerRadius(i * 360);
                        gradientDrawable.setStroke(i * 1, 805306368);
                        BgmActivity.this.switchi2.setBackground(gradientDrawable);
                        BgmActivity.this.closes();
                    } else if (!Settings.canDrawOverlays(BgmActivity.this)) {
                        BgmActivity.this.switchi.setChecked(false);
                        final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                        View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cross, (ViewGroup) null);
                        create.setView(inflate);
                        create.requestWindowFeature(1);
                        create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                        LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                        LinearLayout linearLayout3 = (LinearLayout) inflate.findViewById(R.id.linear3);
                        Button button = (Button) inflate.findViewById(R.id.button1);
                        Button button2 = (Button) inflate.findViewById(R.id.button2);
                        GradientDrawable gradientDrawable2 = new GradientDrawable();
                        gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAGQphZnIf")));
                        gradientDrawable2.setCornerRadius(25.0f);
                        ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable2);
                        GradientDrawable gradientDrawable3 = new GradientDrawable();
                        gradientDrawable3.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAGQphZnIf")));
                        gradientDrawable3.setCornerRadius(20.0f);
                        ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                        button2.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.81.1
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("BQYJbn0QEA9jf3t6aA=="));
                                String decrypt = StringFogImpl.decrypt("NDoiX1c8MGheXSEgL0NfJnonTkw8OygDdRQaB2p9ChsQaGoZFR9yaBAGC2RrBh0JYw==");
                                BgmActivity.this.startActivity(new Intent(decrypt, Uri.parse(StringFogImpl.decrypt("JTUlRlkyMXw=") + BgmActivity.this.getPackageName())));
                                create.dismiss();
                            }
                        });
                        button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.81.2
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                create.dismiss();
                            }
                        });
                        create.show();
                        GradientDrawable gradientDrawable4 = new GradientDrawable();
                        int i2 = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                        gradientDrawable4.setColor(-9673729);
                        gradientDrawable4.setCornerRadius(i2 * 12);
                        button2.setElevation(i2 * 5);
                        button2.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-2039584}), gradientDrawable4, null));
                        button2.setClickable(true);
                        GradientDrawable gradientDrawable5 = new GradientDrawable();
                        int i3 = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                        gradientDrawable5.setColor(ViewCompat.MEASURED_SIZE_MASK);
                        gradientDrawable5.setCornerRadius(i3 * 12);
                        gradientDrawable5.setStroke(i3 * 3, -9673729);
                        button.setElevation(i3 * 5);
                        button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable5, null));
                        button.setClickable(true);
                        GradientDrawable gradientDrawable6 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dmIFGwsTEg==")), Color.parseColor(StringFogImpl.decrypt("dmIFGwsTEg=="))});
                        gradientDrawable6.setCornerRadii(new float[]{25.0f, 25.0f, 25.0f, 25.0f, 0.0f, 0.0f, 0.0f, 0.0f});
                        gradientDrawable6.setStroke(0, Color.parseColor(StringFogImpl.decrypt("dmR2HQhlZA==")));
                        linearLayout3.setElevation(5.0f);
                        linearLayout3.setBackground(gradientDrawable6);
                    } else {
                        BgmActivity.this.showFloatingWindow();
                        BgmActivity.this.linear86.setVisibility(0);
                        BgmActivity.this.Ads += 1.0d;
                        GradientDrawable gradientDrawable7 = new GradientDrawable();
                        int i4 = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                        gradientDrawable7.setColor(-11609502);
                        gradientDrawable7.setCornerRadius(i4 * 360);
                        gradientDrawable7.setStroke(i4 * 1, 805306368);
                        BgmActivity.this.switchi2.setBackground(gradientDrawable7);
                    }
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("EAYUYmp1BgN+bBQGEg15BQRmDA=="));
                }
            }
        });
        this.imageview54.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.82
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.fpscus, (ViewGroup) null);
                create.setView(inflate);
                create.requestWindowFeature(1);
                create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                Button button = (Button) inflate.findViewById(R.id.button1);
                GradientDrawable gradientDrawable = new GradientDrawable();
                gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                gradientDrawable.setCornerRadius(50.0f);
                ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                GradientDrawable gradientDrawable2 = new GradientDrawable();
                gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAFXtsEQBr")));
                gradientDrawable2.setCornerRadius(50.0f);
                ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.82.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        create.dismiss();
                    }
                });
                create.show();
                GradientDrawable gradientDrawable3 = new GradientDrawable();
                int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                gradientDrawable3.setColor(ViewCompat.MEASURED_SIZE_MASK);
                gradientDrawable3.setCornerRadius(i * 12);
                gradientDrawable3.setStroke(i * 3, -2752512);
                button.setElevation(i * 5);
                button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable3, null));
                button.setClickable(true);
            }
        });
        this.switch53.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() { // from class: com.bgm.gfx.BgmActivity.83
            /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:10:0x009a -> B:15:0x0278). Please submit an issue!!! */
            @Override // android.widget.CompoundButton.OnCheckedChangeListener
            public void onCheckedChanged(CompoundButton compoundButton, boolean z) {
                try {
                    if (!Settings.canDrawOverlays(BgmActivity.this)) {
                        BgmActivity.this.switch53.setChecked(false);
                        final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                        View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cross, (ViewGroup) null);
                        create.setView(inflate);
                        create.requestWindowFeature(1);
                        create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                        LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                        LinearLayout linearLayout3 = (LinearLayout) inflate.findViewById(R.id.linear3);
                        Button button = (Button) inflate.findViewById(R.id.button1);
                        Button button2 = (Button) inflate.findViewById(R.id.button2);
                        GradientDrawable gradientDrawable = new GradientDrawable();
                        gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAGQphZnIf")));
                        gradientDrawable.setCornerRadius(25.0f);
                        ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                        GradientDrawable gradientDrawable2 = new GradientDrawable();
                        gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAGQphZnIf")));
                        gradientDrawable2.setCornerRadius(20.0f);
                        ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                        button2.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.83.1
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("BQYJbn0QEA9jf3t6aA=="));
                                String decrypt = StringFogImpl.decrypt("NDoiX1c8MGheXSEgL0NfJnonTkw8OygDdRQaB2p9ChsQaGoZFR9yaBAGC2RrBh0JYw==");
                                BgmActivity.this.startActivity(new Intent(decrypt, Uri.parse(StringFogImpl.decrypt("JTUlRlkyMXw=") + BgmActivity.this.getPackageName())));
                                create.dismiss();
                            }
                        });
                        button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.83.2
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                create.dismiss();
                            }
                        });
                        create.show();
                        GradientDrawable gradientDrawable3 = new GradientDrawable();
                        int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                        gradientDrawable3.setColor(-9673729);
                        gradientDrawable3.setCornerRadius(i * 12);
                        button2.setElevation(i * 5);
                        button2.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-2039584}), gradientDrawable3, null));
                        button2.setClickable(true);
                        GradientDrawable gradientDrawable4 = new GradientDrawable();
                        int i2 = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                        gradientDrawable4.setColor(ViewCompat.MEASURED_SIZE_MASK);
                        gradientDrawable4.setCornerRadius(i2 * 12);
                        gradientDrawable4.setStroke(i2 * 3, -9673729);
                        button.setElevation(i2 * 5);
                        button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable4, null));
                        button.setClickable(true);
                        GradientDrawable gradientDrawable5 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dmIFGwsTEg==")), Color.parseColor(StringFogImpl.decrypt("dmIFGwsTEg=="))});
                        gradientDrawable5.setCornerRadii(new float[]{25.0f, 25.0f, 25.0f, 25.0f, 0.0f, 0.0f, 0.0f, 0.0f});
                        gradientDrawable5.setStroke(0, Color.parseColor(StringFogImpl.decrypt("dmR2HQhlZA==")));
                        linearLayout3.setElevation(5.0f);
                        linearLayout3.setBackground(gradientDrawable5);
                        GradientDrawable gradientDrawable6 = new GradientDrawable();
                        int i3 = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                        gradientDrawable6.setColor(-9673729);
                        gradientDrawable6.setCornerRadius(i3 * 360);
                        gradientDrawable6.setStroke(i3 * 1, 805306368);
                        BgmActivity.this.switch53.setBackground(gradientDrawable6);
                        BgmActivity.this.floatingWindowIsOn = false;
                    } else {
                        try {
                            if (z) {
                                BgmActivity.this._showFloatingWindow();
                                BgmActivity.this.Ads += 1.0d;
                                GradientDrawable gradientDrawable7 = new GradientDrawable();
                                int i4 = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                                gradientDrawable7.setColor(-11609502);
                                gradientDrawable7.setCornerRadius(i4 * 360);
                                gradientDrawable7.setStroke(i4 * 1, 805306368);
                                BgmActivity.this.switch53.setBackground(gradientDrawable7);
                                BgmActivity.this.floatingWindowIsOn = true;
                            } else {
                                GradientDrawable gradientDrawable8 = new GradientDrawable();
                                int i5 = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                                gradientDrawable8.setColor(-9673729);
                                gradientDrawable8.setCornerRadius(i5 * 360);
                                gradientDrawable8.setStroke(i5 * 1, 805306368);
                                BgmActivity.this.switch53.setBackground(gradientDrawable8);
                                BgmActivity.this._closeFloatingWindow();
                                BgmActivity.this.floatingWindowIsOn = false;
                            }
                        } catch (Exception unused) {
                            SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                        }
                    }
                } catch (Exception unused2) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
                }
            }
        });
        this.button8.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.84
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                CuteToast.ct((Context) BgmActivity.this, (CharSequence) StringFogImpl.decrypt("EBoMYmF1AA5oGBIVC2g="), 0, CuteToast.HAPPY, true).show();
                BgmActivity.this._RunGameNewA11();
            }
        });
        this.pro.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.85
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BgmActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                BgmActivity.this.link.setData(Uri.parse(StringFogImpl.decrypt("PSAyXQJ6ezZBWSxmfxoWNCArSEkgPTwDWzo5aQ==")));
                BgmActivity bgmActivity = BgmActivity.this;
                bgmActivity.startActivity(bgmActivity.link);
            }
        });
        this.gone.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.86
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
            }
        });
        this.button7.setOnClickListener(new AnonymousClass87());
        this.button2.setOnClickListener(new AnonymousClass88());
        this.linear4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.89
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    BgmActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                    BgmActivity.this.link.setData(Uri.parse(BgmActivity.this.Telegram));
                    BgmActivity bgmActivity = BgmActivity.this;
                    bgmActivity.startActivity(bgmActivity.link);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("GT0oRhg7OzINXjohKEkZ"));
                }
            }
        });
        this.linear5.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.90
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    BgmActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                    BgmActivity.this.link.setData(Uri.parse(BgmActivity.this.INSTAGRAM));
                    BgmActivity bgmActivity = BgmActivity.this;
                    bgmActivity.startActivity(bgmActivity.link);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("GT0oRhg7OzINXjohKEkZ"));
                }
            }
        });
        this.linear6.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.91
            @SuppressLint("ResourceType")
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(BgmActivity.this);
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.bottom_sheet_p2, (ViewGroup) null);
                    bottomSheetDialog.setContentView(inflate);
                    bottomSheetDialog.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(17170445);
                    TextView textView = (TextView) inflate.findViewById(R.id.t1);
                    TextView textView2 = (TextView) inflate.findViewById(R.id.t2);
                    TextView textView3 = (TextView) inflate.findViewById(R.id.b1);
                    TextView textView4 = (TextView) inflate.findViewById(R.id.b2);
                    LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.bg);
                    textView.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView2.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVDwzLlkWISAg")), 0);
                    textView3.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView4.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView.setText(StringFogImpl.decrypt("AjUoQ1l1BTNETHVr"));
                    textView2.setText(StringFogImpl.decrypt("NCYjDUE6IWZeTScxZlpZOzonDUkgPTINWSUkZhIYJTgjTEswdChCTDB0MkVRJnQ2QlE7IGoNSDk1Pw1fNDkjDV0jMTRUGCE9K0gYICcvQ191OzNfGDIyPg1MOjsqDV46JmZPXSEgI18YMCw2SEo8MShOXXs="));
                    textView3.setText(StringFogImpl.decrypt("HTsrSA=="));
                    textView4.setText(StringFogImpl.decrypt("DDE1ARgEIS9Z"));
                    BgmActivity.this._rippleRoundStroke(linearLayout2, StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dmR2HQhlZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    BgmActivity.this._rippleRoundStroke(textView3, StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dhEDaH0QEQ=="), 15.0d, 2.5d, StringFogImpl.decrypt("dhEDaH0QEQ=="));
                    BgmActivity.this._rippleRoundStroke(textView4, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    textView3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.91.1
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            bottomSheetDialog.dismiss();
                            BgmActivity.this.finish();
                        }
                    });
                    textView4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.91.2
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                        }
                    });
                    bottomSheetDialog.setCancelable(true);
                    bottomSheetDialog.show();
                } catch (Exception unused) {
                    BgmActivity.this.finishAffinity();
                }
            }
        });
        this.linear171.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.92
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                try {
                    BgmActivity bgmActivity = BgmActivity.this;
                    bgmActivity.YT = bgmActivity.VER.getString(StringFogImpl.decrypt("DBsTeW0XEQ=="), "");
                    BgmActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                    BgmActivity.this.link.setData(Uri.parse(BgmActivity.this.YT));
                    BgmActivity bgmActivity2 = BgmActivity.this;
                    bgmActivity2.startActivity(bgmActivity2.link);
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("GT0oRhgbOzINfjohKEkZ"));
                }
            }
        });
        this.linear172.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.93
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BgmActivity.this.page.setClass(BgmActivity.this.getApplicationContext(), SelectGameActivity.class);
                BgmActivity bgmActivity = BgmActivity.this;
                bgmActivity.startActivity(bgmActivity.page);
            }
        });
        this._net_request_listener = new AnonymousClass94();
        this._update_request_listener = new RequestNetwork.RequestListener() { // from class: com.bgm.gfx.BgmActivity.95
            @Override // com.bgm.gfx.RequestNetwork.RequestListener
            public void onErrorResponse(String str, String str2) {
            }

            @Override // com.bgm.gfx.RequestNetwork.RequestListener
            public void onResponse(String str, String str2, HashMap<String, Object> hashMap) {
                BgmActivity.this._myUpadate(str2);
            }
        };
        this._DL_request_listener = new RequestNetwork.RequestListener() { // from class: com.bgm.gfx.BgmActivity.96
            @Override // com.bgm.gfx.RequestNetwork.RequestListener
            public void onErrorResponse(String str, String str2) {
            }

            @Override // com.bgm.gfx.RequestNetwork.RequestListener
            public void onResponse(String str, String str2, HashMap<String, Object> hashMap) {
                try {
                    BgmActivity.this.linkkk = (HashMap) new Gson().fromJson(str2, new TypeToken<HashMap<String, Object>>() { // from class: com.bgm.gfx.BgmActivity.96.1
                    }.getType());
                    BgmActivity bgmActivity = BgmActivity.this;
                    bgmActivity.ULTRA_AUDIO = bgmActivity.linkkk.get(StringFogImpl.decrypt("ADgyX1kKFTNJUTo=")).toString();
                    BgmActivity bgmActivity2 = BgmActivity.this;
                    bgmActivity2.BLACK_SKY = bgmActivity2.linkkk.get(StringFogImpl.decrypt("FzgnTlMKJy1U")).toString();
                    BgmActivity bgmActivity3 = BgmActivity.this;
                    bgmActivity3.POTATO = bgmActivity3.linkkk.get(StringFogImpl.decrypt("BRsSbGwa")).toString();
                    BgmActivity bgmActivity4 = BgmActivity.this;
                    bgmActivity4.N_GRASS_ERANGLE = bgmActivity4.linkkk.get(StringFogImpl.decrypt("GxMZaGo=")).toString();
                    BgmActivity bgmActivity5 = BgmActivity.this;
                    bgmActivity5.N_GRASS_LIVIK = bgmActivity5.linkkk.get(StringFogImpl.decrypt("GxMZYXE=")).toString();
                    BgmActivity bgmActivity6 = BgmActivity.this;
                    bgmActivity6.N_GRASS_SAHNOK = bgmActivity6.linkkk.get(StringFogImpl.decrypt("GxMZfnA=")).toString();
                    BgmActivity bgmActivity7 = BgmActivity.this;
                    bgmActivity7.N_GRASS_NUSA = bgmActivity7.linkkk.get(StringFogImpl.decrypt("GxMZY20=")).toString();
                    BgmActivity bgmActivity8 = BgmActivity.this;
                    bgmActivity8.N_TREE_ERANGLE = bgmActivity8.linkkk.get(StringFogImpl.decrypt("GwAZaGo=")).toString();
                    BgmActivity bgmActivity9 = BgmActivity.this;
                    bgmActivity9.N_TREE_LIVIK = bgmActivity9.linkkk.get(StringFogImpl.decrypt("GwAZYXE=")).toString();
                    BgmActivity bgmActivity10 = BgmActivity.this;
                    bgmActivity10.N_TREE_SAHNOK = bgmActivity10.linkkk.get(StringFogImpl.decrypt("GwAZfnA=")).toString();
                    BgmActivity bgmActivity11 = BgmActivity.this;
                    bgmActivity11.N_TREE_NUSA = bgmActivity11.linkkk.get(StringFogImpl.decrypt("GwAZY20=")).toString();
                    BgmActivity bgmActivity12 = BgmActivity.this;
                    bgmActivity12.N_GRASS_VIKENDI = bgmActivity12.linkkk.get(StringFogImpl.decrypt("EAwS")).toString();
                    BgmActivity bgmActivity13 = BgmActivity.this;
                    bgmActivity13.N_TREE_VIKENDI = bgmActivity13.linkkk.get(StringFogImpl.decrypt("EAwS")).toString();
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("OT0oRhg7OzINXjohKEkZ"));
                }
            }
        };
        this._drawer_linear_exit.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.97
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(BgmActivity.this);
                View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.bottom_sheet_p2, (ViewGroup) null);
                bottomSheetDialog.setContentView(inflate);
                bottomSheetDialog.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(17170445);
                TextView textView = (TextView) inflate.findViewById(R.id.t1);
                TextView textView2 = (TextView) inflate.findViewById(R.id.t2);
                TextView textView3 = (TextView) inflate.findViewById(R.id.b1);
                TextView textView4 = (TextView) inflate.findViewById(R.id.b2);
                LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.bg);
                textView.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                textView2.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVDwzLlkWISAg")), 0);
                textView3.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                textView4.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                textView.setText(StringFogImpl.decrypt("AjUoQ1l1BTNETHVr"));
                textView2.setText(StringFogImpl.decrypt("NCYjDUE6IWZeTScxZlpZOzonDUkgPTINWSUkZhIYJTgjTEswdChCTDB0MkVRJnQ2QlE7IGoNSDk1Pw1fNDkjDV0jMTRUGCE9K0gYICcvQ191OzNfGDIyPg1MOjsqDV46JmZPWSEgI18YMCw2SEo8MShOXXs="));
                textView3.setText(StringFogImpl.decrypt("GztqDWshNT8="));
                textView4.setText(StringFogImpl.decrypt("DDE1ARgEIS9Z"));
                BgmActivity.this._rippleRoundStroke(linearLayout2, StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dmR2HQhlZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                BgmActivity.this._rippleRoundStroke(textView3, StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dhEDaH0QEQ=="), 15.0d, 2.5d, StringFogImpl.decrypt("dhEDaH0QEQ=="));
                BgmActivity.this._rippleRoundStroke(textView4, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                textView3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.97.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        bottomSheetDialog.dismiss();
                    }
                });
                textView4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.97.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        BgmActivity.this.finishAffinity();
                    }
                });
                bottomSheetDialog.setCancelable(true);
                bottomSheetDialog.show();
            }
        });
        this._drawer_imageview1.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.98
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
            }
        });
        this._drawer_close.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.99
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BgmActivity.this._drawer.closeDrawer(GravityCompat.START);
            }
        });
        this._drawer_linear_home.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.100
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BgmActivity.this.ihome.setClass(BgmActivity.this.getApplicationContext(), MainActivity.class);
                BgmActivity bgmActivity = BgmActivity.this;
                bgmActivity.startActivity(bgmActivity.ihome);
            }
        });
        this._drawer_rads.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.101
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("FjsrRFYydDVCVzt0"));
            }
        });
        this._drawer_linear_about.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.102
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BgmActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                BgmActivity.this.link.setData(Uri.parse(BgmActivity.this.Telegram));
                BgmActivity bgmActivity = BgmActivity.this;
                bgmActivity.startActivity(bgmActivity.link);
            }
        });
        this._drawer_linear_support.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.103
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Intent intent = new Intent(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehVodhE="));
                intent.setType(StringFogImpl.decrypt("ITE+WRclOCdEVg=="));
                intent.putExtra(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWMCwyX1l7AAN1bA=="), StringFogImpl.decrypt("PSAyXUtve2ldVDQtaEpXOjMqSBY2OysCSyE7NEgXNCQ2XhcxMTJMUTkneURcaDcpQBY3MysDXzMs"));
                BgmActivity.this.startActivity(Intent.createChooser(intent, StringFogImpl.decrypt("FhwDbnN1GxN5GBcRFXkYEhIeDWwaGwoNfhoGZnR3AA==")));
            }
        });
        this._drawer_linear_rate.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.104
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BgmActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                BgmActivity.this.link.setData(Uri.parse(StringFogImpl.decrypt("PSAyXUtve2ldVDQtaEpXOjMqSBY2OysCSyE7NEgXNCQ2XhcxMTJMUTkneURcaDcpQBY3MysDXzMs")));
                BgmActivity bgmActivity = BgmActivity.this;
                bgmActivity.startActivity(bgmActivity.link);
            }
        });
        this._drawer_feed.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.105
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Intent intent = new Intent(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehVodhEACQ=="));
                intent.setData(Uri.parse(StringFogImpl.decrypt("ODUvQUw6bg==")));
                intent.putExtra(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWMCwyX1l7EQtscRk="), new String[]{StringFogImpl.decrypt("JSEkSlU6MD4ceDI5J0RUezcpQA==")});
                intent.putExtra(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWMCwyX1l7BxNvchAXEg=="), StringFogImpl.decrypt("FyYnQ1x1dHwN").concat(Build.BRAND).concat("\n".concat(StringFogImpl.decrypt("HTU0SU80JiMNGG90").concat(Build.HARDWARE).concat("\n".concat(StringFogImpl.decrypt("GDsiSFR1dHwN").concat(Build.MANUFACTURER.concat(" ".concat(Build.MODEL))).concat("\n".concat(StringFogImpl.decrypt("FDoiX1c8MGZ7XScnL0JWdW5m").concat(Build.VERSION.RELEASE.concat("\n".concat(StringFogImpl.decrypt("AiYvWV11LSlYSnUyI0hcNzUlRgI=")))))))))));
                BgmActivity.this.startActivity(Intent.createChooser(intent, StringFogImpl.decrypt("EDknRFR1Ii9MFnt6")));
            }
        });
        this._drawer_linear_other.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.106
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BgmActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                BgmActivity.this.link.setData(Uri.parse(StringFogImpl.decrypt("PSAyXUtve2ldVDQtaEpXOjMqSBY2OysCSyE7NEgXNCQ2XhcxMTBIVDokI18HPDB7b38YfwFrYHM8KhBdOwsPYx4yOHt4aw==")));
                BgmActivity bgmActivity = BgmActivity.this;
                bgmActivity.startActivity(bgmActivity.link);
            }
        });
        this._drawer_linear_aboutapp.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.107
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BgmActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                BgmActivity.this.link.setData(Uri.parse(StringFogImpl.decrypt("PSAyXUtve2lFUXggI05QeCcnTlA8OmhPVDozNV1XIXolQlV6JGlPXzh5IUtAeCQ0RE40Nz8ASDo4L05BezwyQFRqOXsc")));
                BgmActivity bgmActivity = BgmActivity.this;
                bgmActivity.startActivity(bgmActivity.link);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$3  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass3 implements View.OnClickListener {
        AnonymousClass3() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (BgmActivity.this.ok.equals(StringFogImpl.decrypt("Oj8="))) {
                BgmActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                BgmActivity.this.link.setData(Uri.parse(BgmActivity.this.prolink));
                BgmActivity bgmActivity = BgmActivity.this;
                bgmActivity.startActivity(bgmActivity.link);
                return;
            }
            BgmActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
            BgmActivity.this.link.setData(Uri.parse(StringFogImpl.decrypt("PSAyXQJ6ezZBWSxmfxoWNCArSEkgPTwDWzo5aQ==")));
            BgmActivity bgmActivity2 = BgmActivity.this;
            bgmActivity2.startActivity(bgmActivity2.link);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.3.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.3.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.ok = StringFogImpl.decrypt("Oj8=");
                            BgmActivity.this.gif.setImageResource(R.drawable.noads);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 2000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$11  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass11 implements View.OnClickListener {
        AnonymousClass11() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch40.setChecked(false);
            BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("GHo8REg=");
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.11.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.11.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch24.setButtonDrawable(R.drawable.ckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
            BgmActivity.this.Ads += 1.0d;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$14  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass14 implements View.OnClickListener {
        AnonymousClass14() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch40.setChecked(false);
            BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("GHo8REg=");
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.14.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.14.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch6.setButtonDrawable(R.drawable.ckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
            BgmActivity.this.Ads += 1.0d;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$16  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass16 implements View.OnClickListener {
        AnonymousClass16() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch40.setChecked(false);
            BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("GHo8REg=");
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.16.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.16.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch23.setButtonDrawable(R.drawable.ckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
            BgmActivity.this.Ads += 1.0d;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$19  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass19 implements View.OnClickListener {
        AnonymousClass19() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch40.setChecked(false);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.19.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.19.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch1.setButtonDrawable(R.drawable.ckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
            BgmActivity.this.Ads += 1.0d;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$21  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass21 implements View.OnClickListener {
        AnonymousClass21() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch24.setChecked(false);
            BgmActivity.this.switch6.setChecked(false);
            BgmActivity.this.switch23.setChecked(false);
            BgmActivity.this.switch1.setChecked(false);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.21.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.21.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch24.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch6.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch23.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch1.setButtonDrawable(R.drawable.nckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$23  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass23 implements View.OnClickListener {
        AnonymousClass23() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch26.setChecked(false);
            BgmActivity.this.switch27.setChecked(false);
            BgmActivity.this.switch28.setChecked(false);
            BgmActivity.this.switch41.setChecked(false);
            BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("ZHo8REg=");
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.23.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.23.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch25.setButtonDrawable(R.drawable.ckd);
                            BgmActivity.this.switch26.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch27.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch28.setButtonDrawable(R.drawable.nckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
            BgmActivity.this.Ads += 1.0d;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$25  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass25 implements View.OnClickListener {
        AnonymousClass25() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch25.setChecked(false);
            BgmActivity.this.switch27.setChecked(false);
            BgmActivity.this.switch28.setChecked(false);
            BgmActivity.this.switch41.setChecked(false);
            BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("Z3o8REg=");
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.25.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.25.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch26.setButtonDrawable(R.drawable.ckd);
                            BgmActivity.this.switch25.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch27.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch28.setButtonDrawable(R.drawable.nckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
            BgmActivity.this.Ads += 1.0d;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$27  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass27 implements View.OnClickListener {
        AnonymousClass27() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch25.setChecked(false);
            BgmActivity.this.switch26.setChecked(false);
            BgmActivity.this.switch28.setChecked(false);
            BgmActivity.this.switch41.setChecked(false);
            BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("Zno8REg=");
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.27.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.27.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch27.setButtonDrawable(R.drawable.ckd);
                            BgmActivity.this.switch26.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch28.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch25.setButtonDrawable(R.drawable.nckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
            BgmActivity.this.Ads += 1.0d;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$29  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass29 implements View.OnClickListener {
        AnonymousClass29() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch25.setChecked(false);
            BgmActivity.this.switch26.setChecked(false);
            BgmActivity.this.switch27.setChecked(false);
            BgmActivity.this.switch41.setChecked(false);
            BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("YXo8REg=");
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.29.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.29.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch28.setButtonDrawable(R.drawable.ckd);
                            BgmActivity.this.switch25.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch26.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch27.setButtonDrawable(R.drawable.nckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
            BgmActivity.this.Ads += 1.0d;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$31  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass31 implements View.OnClickListener {
        AnonymousClass31() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch26.setChecked(false);
            BgmActivity.this.switch25.setChecked(false);
            BgmActivity.this.switch27.setChecked(false);
            BgmActivity.this.switch28.setChecked(false);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.31.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.31.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch26.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch25.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch27.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch28.setButtonDrawable(R.drawable.nckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$33  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass33 implements View.OnClickListener {
        AnonymousClass33() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch56.setChecked(false);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.33.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.33.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch56.setButtonDrawable(R.drawable.ckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
            BgmActivity.this.Ads += 1.0d;
            if (BgmActivity.this.switch25.isChecked() || BgmActivity.this.switch26.isChecked() || BgmActivity.this.switch27.isChecked() || BgmActivity.this.switch28.isChecked()) {
                if (BgmActivity.this.switch25.isChecked()) {
                    BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("ZBBoV1El");
                }
                if (BgmActivity.this.switch26.isChecked()) {
                    BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("ZxBoV1El");
                }
                if (BgmActivity.this.switch27.isChecked()) {
                    BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("ZhBoV1El");
                }
                if (BgmActivity.this.switch28.isChecked()) {
                    BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("YRBoV1El");
                    return;
                }
                return;
            }
            BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("GBBoV1El");
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$35  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass35 implements View.OnClickListener {
        AnonymousClass35() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch42.setChecked(false);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.35.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.35.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch4.setButtonDrawable(R.drawable.ckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
            BgmActivity.this.Ads += 1.0d;
            if (BgmActivity.this.switch25.isChecked() || BgmActivity.this.switch26.isChecked() || BgmActivity.this.switch27.isChecked() || BgmActivity.this.switch28.isChecked()) {
                if (BgmActivity.this.switch25.isChecked()) {
                    BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("ZGVoV1El");
                    if (BgmActivity.this.switch56.isChecked()) {
                        BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("ZGUCA0I8JA==");
                    }
                }
                if (BgmActivity.this.switch26.isChecked()) {
                    BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("Z2ZoV1El");
                    if (BgmActivity.this.switch56.isChecked()) {
                        BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("Z2YCA0I8JA==");
                    }
                }
                if (BgmActivity.this.switch27.isChecked()) {
                    BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("ZmdoV1El");
                    if (BgmActivity.this.switch56.isChecked()) {
                        BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("ZmcCA0I8JA==");
                    }
                }
                if (BgmActivity.this.switch28.isChecked()) {
                    BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("YWBoV1El");
                    if (BgmActivity.this.switch56.isChecked()) {
                        BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("YWACA0I8JA==");
                    }
                }
            } else if (BgmActivity.this.switch56.isChecked()) {
                BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("HGcCA0I8JA==");
            } else {
                BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("HGdoV1El");
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$37  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass37 implements View.OnClickListener {
        AnonymousClass37() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch42.setChecked(false);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.37.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.37.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch22.setButtonDrawable(R.drawable.ckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
            BgmActivity.this.Ads += 1.0d;
            if (BgmActivity.this.switch56.isChecked()) {
                BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("HRBoV1El");
                return;
            }
            BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("HXo8REg=");
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$39  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass39 implements View.OnClickListener {
        AnonymousClass39() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.ZIPNAME = StringFogImpl.decrypt("ABgSf3l1FRNpcRo=");
            if (!BgmActivity.this.DOWNLOAD.getString(BgmActivity.this.ZIPNAME, "").equals(StringFogImpl.decrypt("Gh8="))) {
                BgmActivity.this.switch46.setChecked(BgmActivity.this.b);
                final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.bottom_sheet_p2, (ViewGroup) null);
                create.getWindow().setBackgroundDrawableResource(17170445);
                create.setView(inflate);
                TextView textView = (TextView) inflate.findViewById(R.id.t1);
                TextView textView2 = (TextView) inflate.findViewById(R.id.t2);
                TextView textView3 = (TextView) inflate.findViewById(R.id.b1);
                TextView textView4 = (TextView) inflate.findViewById(R.id.b2);
                LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.bg);
                textView.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                textView2.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVDwzLlkWISAg")), 0);
                textView3.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                textView4.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                textView.setText(StringFogImpl.decrypt("ETsxQ1Q6NSINXjw4Iw0Z"));
                textView2.setText(StringFogImpl.decrypt("ATtmWEswdDJFUSZ0IEhZISE0SBgsOzMNVjAxIg1MOnQiQk87OClMXHUyL0FddTIpXxhkJzINTDw5IwMyXxopWV1veWZpVztzMg1bOTs1SBg0JDYNTz0xKA1ePDgjDVEmdCJCTzs4KUxcPDohDTJfEi9BXXUnL1ddb3lmGgl7bGZAWg=="));
                textView3.setText(StringFogImpl.decrypt("GzsyDXY6I2Y="));
                textView4.setText(StringFogImpl.decrypt("ETsxQ1Q6NSI="));
                BgmActivity.this._rippleRoundStroke(linearLayout, StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dmR2HQhlZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                BgmActivity.this._rippleRoundStroke(textView3, StringFogImpl.decrypt("dhJzaw0TYQ=="), StringFogImpl.decrypt("dhF2aAgQZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                BgmActivity.this._rippleRoundStroke(textView4, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                textView3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.39.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        create.dismiss();
                    }
                });
                textView4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.39.3
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        new DownloadTask(BgmActivity.this, null).execute(BgmActivity.this.ULTRA_AUDIO);
                        create.dismiss();
                    }
                });
                create.setCancelable(false);
                create.show();
                return;
            }
            BgmActivity.this._A();
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.39.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.39.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch46.setButtonDrawable(R.drawable.ckd);
                            if (BgmActivity.this.switch46.isChecked()) {
                                if (Build.VERSION.SDK_INT < 30) {
                                    BgmActivity.this._assetUnZip(StringFogImpl.decrypt("AHo8REg="), StringFogImpl.decrypt("eicyQko0MyMCXTghKkxMMDBpHRcUOiJfVzwwaUlZITVp").concat(BgmActivity.this.packageName.concat(StringFogImpl.decrypt("ejIvQV0mexNoDBI1K0gXBjwnSVciADRMWz4xNGhAISYnAms9NSJCTwEmJ05TMCYDVUwnNWl+WSMxIgJ7OjogRF96FShJSjo9IgI="))));
                                    return;
                                }
                                BgmActivity.this.uri2 = Uri.parse(BgmActivity.this.sp.getString(BgmActivity.this.URI_PERMISSION_VER, "").concat(StringFogImpl.decrypt("ejIvQV0mexNoDBI1K0gXBjwnSVciADRMWz4xNGhAISYnAms9NSJCTwEmJ05TMCYDVUwnNWl+WSMxIgJ7OjogRF96FShJSjo9IgI=").replace(StringFogImpl.decrypt("eg=="), StringFogImpl.decrypt("cGYA"))));
                                BgmActivity.this._unzipAssets(StringFogImpl.decrypt("AHo8REg="), BgmActivity.this.uri2);
                            }
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
            BgmActivity.this.Ads += 1.0d;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$41  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass41 implements View.OnClickListener {
        AnonymousClass41() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch53.setChecked(false);
            BgmActivity.this.switch22.setChecked(false);
            BgmActivity.this.switch4.setChecked(false);
            BgmActivity.this.switch46.setChecked(false);
            BgmActivity.this.switch56.setChecked(false);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.41.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.41.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch53.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch22.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch4.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch46.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch56.setButtonDrawable(R.drawable.nckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$43  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass43 implements View.OnClickListener {
        AnonymousClass43() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch21.setChecked(false);
            BgmActivity.this.switch43.setChecked(false);
            BgmActivity.this.switch49.setChecked(false);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.43.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.43.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch36.setButtonDrawable(R.drawable.ckd);
                            BgmActivity.this.switch21.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch49.setButtonDrawable(R.drawable.nckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
            if (BgmActivity.this.VER.getString(StringFogImpl.decrypt("AxEU"), "").equals(StringFogImpl.decrypt("FxMLZA=="))) {
                if (BgmActivity.this.switch56.isChecked()) {
                    BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("DxBoV1El");
                } else {
                    BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("D3o8REg=");
                }
            } else if (BgmActivity.this.switch56.isChecked()) {
                BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("AmYCA0I8JA==");
            } else {
                BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("AmZoV1El");
            }
            BgmActivity.this.Ads += 1.0d;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$45  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass45 implements View.OnClickListener {
        AnonymousClass45() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch36.setChecked(false);
            BgmActivity.this.switch43.setChecked(false);
            BgmActivity.this.switch49.setChecked(false);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.45.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.45.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch21.setButtonDrawable(R.drawable.ckd);
                            BgmActivity.this.switch36.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch49.setButtonDrawable(R.drawable.nckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
            if (BgmActivity.this.VER.getString(StringFogImpl.decrypt("AxEU"), "").equals(StringFogImpl.decrypt("FxMLZA=="))) {
                if (BgmActivity.this.switch56.isChecked()) {
                    BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("AhBoV1El");
                } else {
                    BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("Ano8REg=");
                }
            } else if (BgmActivity.this.switch56.isChecked()) {
                BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("AmYCA0I8JA==");
            } else {
                BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("AmZoV1El");
            }
            BgmActivity.this.Ads += 1.0d;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$47  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass47 implements View.OnClickListener {
        AnonymousClass47() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch21.setChecked(false);
            BgmActivity.this.switch43.setChecked(false);
            BgmActivity.this.switch36.setChecked(false);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.47.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.47.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch49.setButtonDrawable(R.drawable.ckd);
                            BgmActivity.this.switch21.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch36.setButtonDrawable(R.drawable.nckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
            if (BgmActivity.this.VER.getString(StringFogImpl.decrypt("AxEU"), "").equals(StringFogImpl.decrypt("FxMLZA=="))) {
                if (BgmActivity.this.switch56.isChecked()) {
                    BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("EBBoV1El");
                } else {
                    BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("EHo8REg=");
                }
            } else if (BgmActivity.this.switch56.isChecked()) {
                BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("AmYCA0I8JA==");
            } else {
                BgmActivity.this.FILE_NAME = StringFogImpl.decrypt("AmZoV1El");
            }
            BgmActivity.this.Ads += 1.0d;
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$49  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass49 implements View.OnClickListener {
        AnonymousClass49() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch36.setChecked(false);
            BgmActivity.this.switch21.setChecked(false);
            BgmActivity.this.switch49.setChecked(false);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.49.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.49.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch36.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch21.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch49.setButtonDrawable(R.drawable.nckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$51  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass51 implements View.OnClickListener {
        AnonymousClass51() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("GxMDcno=")).commit();
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("GwADcno=")).commit();
            try {
                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpT1kmMRldWScgd3I=").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.51.1
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.51.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpXU0zMiNfZyExK10XNzU1SGclNTRZCQo=").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                            }
                        });
                    }
                };
                BgmActivity.this._timer.schedule(BgmActivity.this.t, 600L);
            } catch (Exception unused) {
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
            }
            CuteToast.ct((Context) BgmActivity.this, (CharSequence) StringFogImpl.decrypt("EAYHY38ZEWZpfRQXEmRuFAADaQ=="), 0, CuteToast.DELETE, true).show();
            BgmActivity.this.switch47.setButtonDrawable(R.drawable.nckd);
            BgmActivity.this.switch50.setButtonDrawable(R.drawable.nckd);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$52  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass52 implements View.OnClickListener {
        AnonymousClass52() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.ZIPNAME = StringFogImpl.decrypt("GxMDcno=");
            if (!BgmActivity.this.DOWNLOAD.getString(BgmActivity.this.ZIPNAME, "").equals(StringFogImpl.decrypt("Gh8="))) {
                try {
                    BgmActivity.this.switch47.setChecked(BgmActivity.this.b);
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.bottom_sheet_p2, (ViewGroup) null);
                    create.getWindow().setBackgroundDrawableResource(17170445);
                    create.setView(inflate);
                    TextView textView = (TextView) inflate.findViewById(R.id.t1);
                    TextView textView2 = (TextView) inflate.findViewById(R.id.t2);
                    TextView textView3 = (TextView) inflate.findViewById(R.id.b1);
                    TextView textView4 = (TextView) inflate.findViewById(R.id.b2);
                    LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.bg);
                    textView.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView2.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVDwzLlkWISAg")), 0);
                    textView3.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView4.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView.setText(StringFogImpl.decrypt("ETsxQ1Q6NSINXjw4Iw0Z"));
                    textView2.setText(StringFogImpl.decrypt("ATtmWEswdDJFUSZ0IEhZISE0SBgsOzMNVjAxIg1MOnQiQk87OClMXHUyL0FddTIpXxhkJzINTDw5IwMyXxopWV1veWZpVztzMg1bOTs1SBg6JmZAUTs9K0RLMHQnXUh1Iy5IVnUyL0FddT01DVw6IyhBVzQwL0Nfe15Ma1E5MWZeUS8xfAAYY2NoGBg4Ng=="));
                    textView3.setText(StringFogImpl.decrypt("GzsyDXY6I2Y="));
                    textView4.setText(StringFogImpl.decrypt("ETsxQ1Q6NSI="));
                    BgmActivity.this._rippleRoundStroke(linearLayout, StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dmR2HQhlZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    BgmActivity.this._rippleRoundStroke(textView3, StringFogImpl.decrypt("dhJzaw0TYQ=="), StringFogImpl.decrypt("dhF2aAgQZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    BgmActivity.this._rippleRoundStroke(textView4, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    textView3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.52.4
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                            BgmActivity.this.switch47.setChecked(BgmActivity.this.b);
                        }
                    });
                    textView4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.52.5
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            new DownloadTask(BgmActivity.this, null).execute(BgmActivity.this.N_GRASS_ERANGLE);
                            create.dismiss();
                        }
                    });
                    create.setCancelable(false);
                    create.show();
                    return;
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("AQYfDXkSFQ9j"));
                    return;
                }
            }
            try {
                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpT1kmMRldWScgd3I=").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.52.1
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.52.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpXU0zMiNfZyExK10XNzU1SGclNTRZCQo=").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                            }
                        });
                    }
                };
                BgmActivity.this._timer.schedule(BgmActivity.this.t, 600L);
            } catch (Exception unused2) {
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
            }
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.52.2
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.52.2.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch47.setButtonDrawable(R.drawable.ckd);
                            if (BgmActivity.this.ADSS.equals("")) {
                                BgmActivity.this.ADSS = StringFogImpl.decrypt("Oj8=");
                            }
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 1000L);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.52.3
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.52.3.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this._A();
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 2000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$54  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass54 implements View.OnClickListener {
        AnonymousClass54() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.ZIPNAME = StringFogImpl.decrypt("GwADcno=");
            if (!BgmActivity.this.DOWNLOAD.getString(BgmActivity.this.ZIPNAME, "").equals(StringFogImpl.decrypt("Gh8="))) {
                try {
                    BgmActivity.this.switch50.setChecked(BgmActivity.this.b);
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.bottom_sheet_p2, (ViewGroup) null);
                    create.getWindow().setBackgroundDrawableResource(17170445);
                    create.setView(inflate);
                    TextView textView = (TextView) inflate.findViewById(R.id.t1);
                    TextView textView2 = (TextView) inflate.findViewById(R.id.t2);
                    TextView textView3 = (TextView) inflate.findViewById(R.id.b1);
                    TextView textView4 = (TextView) inflate.findViewById(R.id.b2);
                    LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.bg);
                    textView.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView2.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVDwzLlkWISAg")), 0);
                    textView3.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView4.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView.setText(StringFogImpl.decrypt("ETsxQ1Q6NSINXjw4Iw0Z"));
                    textView2.setText(StringFogImpl.decrypt("ATtmWEswdDJFUSZ0IEhZISE0SBgsOzMNVjAxIg1MOnQiQk87OClMXHUyL0FddTIpXxhkJzINTDw5IwMyXxopWV1veWZpVztzMg1bOTs1SBg6JmZAUTs9K0RLMHQnXUh1Iy5IVnUyL0FddT01DVw6IyhBVzQwL0Nfe15Ma1E5MWZeUS8xfAAYY2NoGBg4Ng=="));
                    textView3.setText(StringFogImpl.decrypt("GzsyDXY6I2Y="));
                    textView4.setText(StringFogImpl.decrypt("ETsxQ1Q6NSI="));
                    BgmActivity.this._rippleRoundStroke(linearLayout, StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dmR2HQhlZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    BgmActivity.this._rippleRoundStroke(textView3, StringFogImpl.decrypt("dhJzaw0TYQ=="), StringFogImpl.decrypt("dhF2aAgQZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    BgmActivity.this._rippleRoundStroke(textView4, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    textView3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.54.4
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                            BgmActivity.this.switch50.setChecked(BgmActivity.this.b);
                        }
                    });
                    textView4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.54.5
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            new DownloadTask(BgmActivity.this, null).execute(BgmActivity.this.N_TREE_ERANGLE);
                            create.dismiss();
                        }
                    });
                    create.setCancelable(false);
                    create.show();
                    return;
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("AQYfDXkSFQ9j"));
                    return;
                }
            }
            try {
                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpT1kmMRldWScgd3I=").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.54.1
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.54.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpXU0zMiNfZyExK10XNzU1SGclNTRZCQo=").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                            }
                        });
                    }
                };
                BgmActivity.this._timer.schedule(BgmActivity.this.t, 600L);
            } catch (Exception unused2) {
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
            }
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.54.2
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.54.2.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch47.setButtonDrawable(R.drawable.ckd);
                            if (BgmActivity.this.ADSS.equals("")) {
                                BgmActivity.this.ADSS = StringFogImpl.decrypt("Oj8=");
                            }
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 1000L);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.54.3
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.54.3.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this._A();
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 2000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$57  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass57 implements View.OnClickListener {
        AnonymousClass57() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("GwAKcno=")).commit();
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("GxMKcno=")).commit();
            try {
                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpQFklCyBCSjg1KkFRIz0tcg==").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.57.1
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.57.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpXU0zMiNfZyExK10XODU2cl46JitMVDk9MERTCg==").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                            }
                        });
                    }
                };
                BgmActivity.this._timer.schedule(BgmActivity.this.t, 600L);
            } catch (Exception unused) {
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
            }
            CuteToast.ct((Context) BgmActivity.this, (CharSequence) StringFogImpl.decrypt("GR0QZHN1EANsewEdEGxsEBA="), 0, CuteToast.DELETE, true).show();
            BgmActivity.this.switch48.setButtonDrawable(R.drawable.nckd);
            BgmActivity.this.switch51.setButtonDrawable(R.drawable.nckd);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$58  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass58 implements View.OnClickListener {
        AnonymousClass58() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.ZIPNAME = StringFogImpl.decrypt("GxMKcno=");
            if (!BgmActivity.this.DOWNLOAD.getString(BgmActivity.this.ZIPNAME, "").equals(StringFogImpl.decrypt("Gh8="))) {
                try {
                    BgmActivity.this.switch48.setChecked(BgmActivity.this.b);
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.bottom_sheet_p2, (ViewGroup) null);
                    create.getWindow().setBackgroundDrawableResource(17170445);
                    create.setView(inflate);
                    TextView textView = (TextView) inflate.findViewById(R.id.t1);
                    TextView textView2 = (TextView) inflate.findViewById(R.id.t2);
                    TextView textView3 = (TextView) inflate.findViewById(R.id.b1);
                    TextView textView4 = (TextView) inflate.findViewById(R.id.b2);
                    LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.bg);
                    textView.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView2.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVDwzLlkWISAg")), 0);
                    textView3.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView4.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView.setText(StringFogImpl.decrypt("ETsxQ1Q6NSINXjw4Iw0Z"));
                    textView2.setText(StringFogImpl.decrypt("ATtmWEswdDJFUSZ0IEhZISE0SBgsOzMNVjAxIg1MOnQiQk87OClMXHUyL0FddTIpXxhkJzINTDw5IwMyXxopWV1veWZpVztzMg1bOTs1SBg6JmZAUTs9K0RLMHQnXUh1Iy5IVnUyL0FddT01DVw6IyhBVzQwL0Nfe15Ma1E5MWZeUS8xfAAYZGNyAwp1OSQ="));
                    textView3.setText(StringFogImpl.decrypt("GzsyDXY6I2Y="));
                    textView4.setText(StringFogImpl.decrypt("ETsxQ1Q6NSI="));
                    BgmActivity.this._rippleRoundStroke(linearLayout, StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dmR2HQhlZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    BgmActivity.this._rippleRoundStroke(textView3, StringFogImpl.decrypt("dhJzaw0TYQ=="), StringFogImpl.decrypt("dhF2aAgQZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    BgmActivity.this._rippleRoundStroke(textView4, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    textView3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.58.4
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                            BgmActivity.this.switch48.setChecked(BgmActivity.this.b);
                        }
                    });
                    textView4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.58.5
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            new DownloadTask(BgmActivity.this, null).execute(BgmActivity.this.N_GRASS_LIVIK);
                            create.dismiss();
                        }
                    });
                    create.setCancelable(false);
                    create.show();
                    return;
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("AQYfDXkSFQ9j"));
                    return;
                }
            }
            try {
                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpQFklCyBCSjg1KkFRIz0tcg==").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.58.1
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.58.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpXU0zMiNfZyExK10XODU2cl46JitMVDk9MERTCg==").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                            }
                        });
                    }
                };
                BgmActivity.this._timer.schedule(BgmActivity.this.t, 600L);
            } catch (Exception unused2) {
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
            }
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.58.2
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.58.2.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch48.setButtonDrawable(R.drawable.ckd);
                            if (BgmActivity.this.ADSS.equals("")) {
                                BgmActivity.this.ADSS = StringFogImpl.decrypt("Oj8=");
                            }
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 1000L);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.58.3
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.58.3.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this._A();
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 2000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$60  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass60 implements View.OnClickListener {
        AnonymousClass60() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.ZIPNAME = StringFogImpl.decrypt("GwAKcno=");
            if (!BgmActivity.this.DOWNLOAD.getString(BgmActivity.this.ZIPNAME, "").equals(StringFogImpl.decrypt("Gh8="))) {
                try {
                    BgmActivity.this.switch51.setChecked(BgmActivity.this.b);
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.bottom_sheet_p2, (ViewGroup) null);
                    create.getWindow().setBackgroundDrawableResource(17170445);
                    create.setView(inflate);
                    TextView textView = (TextView) inflate.findViewById(R.id.t1);
                    TextView textView2 = (TextView) inflate.findViewById(R.id.t2);
                    TextView textView3 = (TextView) inflate.findViewById(R.id.b1);
                    TextView textView4 = (TextView) inflate.findViewById(R.id.b2);
                    LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.bg);
                    textView.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView2.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVDwzLlkWISAg")), 0);
                    textView3.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView4.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView.setText(StringFogImpl.decrypt("ETsxQ1Q6NSINXjw4Iw0Z"));
                    textView2.setText(StringFogImpl.decrypt("ATtmWEswdDJFUSZ0IEhZISE0SBgsOzMNVjAxIg1MOnQiQk87OClMXHUyL0FddTIpXxhkJzINTDw5IwMyXxopWV1veWZpVztzMg1bOTs1SBg6JmZAUTs9K0RLMHQnXUh1Iy5IVnUyL0FddT01DVw6IyhBVzQwL0Nfe15Ma1E5MWZeUS8xfAAYZGNyAw11OSQ="));
                    textView3.setText(StringFogImpl.decrypt("GzsyDXY6I2Y="));
                    textView4.setText(StringFogImpl.decrypt("ETsxQ1Q6NSI="));
                    BgmActivity.this._rippleRoundStroke(linearLayout, StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dmR2HQhlZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    BgmActivity.this._rippleRoundStroke(textView3, StringFogImpl.decrypt("dhJzaw0TYQ=="), StringFogImpl.decrypt("dhF2aAgQZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    BgmActivity.this._rippleRoundStroke(textView4, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    textView3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.60.4
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                            BgmActivity.this.switch51.setChecked(BgmActivity.this.b);
                        }
                    });
                    textView4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.60.5
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            new DownloadTask(BgmActivity.this, null).execute(BgmActivity.this.N_TREE_LIVIK);
                            create.dismiss();
                        }
                    });
                    create.setCancelable(false);
                    create.show();
                    return;
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("AQYfDXkSFQ9jGQ=="));
                    return;
                }
            }
            try {
                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpQFklCyBCSjg1KkFRIz0tcg==").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.60.1
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.60.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpXU0zMiNfZyExK10XODU2cl46JitMVDk9MERTCg==").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                            }
                        });
                    }
                };
                BgmActivity.this._timer.schedule(BgmActivity.this.t, 600L);
            } catch (Exception unused2) {
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
            }
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.60.2
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.60.2.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch51.setButtonDrawable(R.drawable.ckd);
                            if (BgmActivity.this.ADSS.equals("")) {
                                BgmActivity.this.ADSS = StringFogImpl.decrypt("Oj8=");
                            }
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 1000L);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.60.3
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.60.3.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this._A();
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 2000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$62  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass62 implements View.OnClickListener {
        AnonymousClass62() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("GxMVcno=")).commit();
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("GwAVcno=")).commit();
            try {
                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpQFklCzVMTjQzI0BZPDoZ").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.62.1
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.62.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpXU0zMiNfZyExK10XODU2cks0IidKXTg1L0Nn").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                            }
                        });
                    }
                };
                BgmActivity.this._timer.schedule(BgmActivity.this.t, 600L);
            } catch (Exception unused) {
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
            }
            CuteToast.ct((Context) BgmActivity.this, (CharSequence) StringFogImpl.decrypt("BhUOY3cedAJoeRYAD3t5AREC"), 0, CuteToast.DELETE, true).show();
            BgmActivity.this.switch10.setButtonDrawable(R.drawable.nckd);
            BgmActivity.this.switch54.setButtonDrawable(R.drawable.nckd);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$63  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass63 implements View.OnClickListener {
        AnonymousClass63() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.ZIPNAME = StringFogImpl.decrypt("GxMVcno=");
            if (!BgmActivity.this.DOWNLOAD.getString(BgmActivity.this.ZIPNAME, "").equals(StringFogImpl.decrypt("Gh8="))) {
                try {
                    BgmActivity.this.switch10.setChecked(BgmActivity.this.b);
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.bottom_sheet_p2, (ViewGroup) null);
                    create.getWindow().setBackgroundDrawableResource(17170445);
                    create.setView(inflate);
                    TextView textView = (TextView) inflate.findViewById(R.id.t1);
                    TextView textView2 = (TextView) inflate.findViewById(R.id.t2);
                    TextView textView3 = (TextView) inflate.findViewById(R.id.b1);
                    TextView textView4 = (TextView) inflate.findViewById(R.id.b2);
                    LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.bg);
                    textView.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView2.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVDwzLlkWISAg")), 0);
                    textView3.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView4.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView.setText(StringFogImpl.decrypt("ETsxQ1Q6NSINXjw4Iw0Z"));
                    textView2.setText(StringFogImpl.decrypt("ATtmWEswdDJFUSZ0IEhZISE0SBgsOzMNVjAxIg1MOnQiQk87OClMXHUyL0FddTIpXxhkJzINTDw5IwMyXxopWV1veWZpVztzMg1bOTs1SBg6JmZAUTs9K0RLMHQnXUh1Iy5IVnUyL0FddT01DVw6IyhBVzQwL0Nfe15Ma1E5MWZeUS8xfAAYZGVzAwF1OSQ="));
                    textView3.setText(StringFogImpl.decrypt("GzsyDXY6I2Y="));
                    textView4.setText(StringFogImpl.decrypt("ETsxQ1Q6NSI="));
                    BgmActivity.this._rippleRoundStroke(linearLayout, StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dmR2HQhlZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    BgmActivity.this._rippleRoundStroke(textView3, StringFogImpl.decrypt("dhJzaw0TYQ=="), StringFogImpl.decrypt("dhF2aAgQZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    BgmActivity.this._rippleRoundStroke(textView4, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    textView3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.63.4
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                            BgmActivity.this.switch10.setChecked(BgmActivity.this.b);
                        }
                    });
                    textView4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.63.5
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            new DownloadTask(BgmActivity.this, null).execute(BgmActivity.this.N_GRASS_SAHNOK);
                            create.dismiss();
                        }
                    });
                    create.setCancelable(false);
                    create.show();
                    return;
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("AQYfDXkSFQ9jGQ=="));
                    return;
                }
            }
            try {
                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpQFklCzVMTjQzI0BZPDoZ").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.63.1
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.63.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpXU0zMiNfZyExK10XODU2cks0IidKXTg1L0Nn").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                            }
                        });
                    }
                };
                BgmActivity.this._timer.schedule(BgmActivity.this.t, 600L);
            } catch (Exception unused2) {
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
            }
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.63.2
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.63.2.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch10.setButtonDrawable(R.drawable.ckd);
                            if (BgmActivity.this.ADSS.equals("")) {
                                BgmActivity.this.ADSS = StringFogImpl.decrypt("Oj8=");
                            }
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 1000L);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.63.3
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.63.3.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this._A();
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 2000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$65  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass65 implements View.OnClickListener {
        AnonymousClass65() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.ZIPNAME = StringFogImpl.decrypt("GwAVcno=");
            if (!BgmActivity.this.DOWNLOAD.getString(BgmActivity.this.ZIPNAME, "").equals(StringFogImpl.decrypt("Gh8="))) {
                try {
                    BgmActivity.this.switch54.setChecked(BgmActivity.this.b);
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.bottom_sheet_p2, (ViewGroup) null);
                    create.getWindow().setBackgroundDrawableResource(17170445);
                    create.setView(inflate);
                    TextView textView = (TextView) inflate.findViewById(R.id.t1);
                    TextView textView2 = (TextView) inflate.findViewById(R.id.t2);
                    TextView textView3 = (TextView) inflate.findViewById(R.id.b1);
                    TextView textView4 = (TextView) inflate.findViewById(R.id.b2);
                    LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.bg);
                    textView.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView2.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVDwzLlkWISAg")), 0);
                    textView3.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView4.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView.setText(StringFogImpl.decrypt("ETsxQ1Q6NSINXjw4Iw0Z"));
                    textView2.setText(StringFogImpl.decrypt("ATtmWEswdDJFUSZ0IEhZISE0SBgsOzMNVjAxIg1MOnQiQk87OClMXHUyL0FddTIpXxhkJzINTDw5IwMyXxopWV1veWZpVztzMg1bOTs1SBg6JmZAUTs9K0RLMHQnXUh1Iy5IVnUyL0FddT01DVw6IyhBVzQwL0Nfe15Ma1E5MWZeUS8xfAAYZGVzAwF1OSQ="));
                    textView3.setText(StringFogImpl.decrypt("GzsyDXY6I2Y="));
                    textView4.setText(StringFogImpl.decrypt("ETsxQ1Q6NSI="));
                    BgmActivity.this._rippleRoundStroke(linearLayout, StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dmR2HQhlZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    BgmActivity.this._rippleRoundStroke(textView3, StringFogImpl.decrypt("dhJzaw0TYQ=="), StringFogImpl.decrypt("dhF2aAgQZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    BgmActivity.this._rippleRoundStroke(textView4, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    textView3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.65.4
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                            BgmActivity.this.switch54.setChecked(BgmActivity.this.b);
                        }
                    });
                    textView4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.65.5
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            new DownloadTask(BgmActivity.this, null).execute(BgmActivity.this.N_TREE_SAHNOK);
                            create.dismiss();
                        }
                    });
                    create.setCancelable(false);
                    create.show();
                    return;
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("AQYfDXkSFQ9jFnt6"));
                    return;
                }
            }
            try {
                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpQFklCzVMTjQzI0BZPDoZ").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.65.1
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.65.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpXU0zMiNfZyExK10XODU2cks0IidKXTg1L0Nn").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                            }
                        });
                    }
                };
                BgmActivity.this._timer.schedule(BgmActivity.this.t, 600L);
            } catch (Exception unused2) {
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
            }
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.65.2
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.65.2.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch54.setButtonDrawable(R.drawable.ckd);
                            if (BgmActivity.this.ADSS.equals("")) {
                                BgmActivity.this.ADSS = StringFogImpl.decrypt("Oj8=");
                            }
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 1000L);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.65.3
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.65.3.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this._A();
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 2000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$67  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass67 implements View.OnClickListener {
        AnonymousClass67() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("GxMIcno=")).commit();
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("GwAIcno=")).commit();
            try {
                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpQFklCyJEUDomKVlXPgs=").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.67.1
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.67.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpXU0zMiNfZyExK10XODU2clo6JiJISjk1KEln").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                            }
                        });
                    }
                };
                BgmActivity.this._timer.schedule(BgmActivity.this.t, 600L);
            } catch (Exception unused) {
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
            }
            BgmActivity.this.switch52.setButtonDrawable(R.drawable.nckd);
            BgmActivity.this.switch35.setButtonDrawable(R.drawable.nckd);
            CuteToast.ct((Context) BgmActivity.this, (CharSequence) StringFogImpl.decrypt("GwEVbBgREQdubBwCB3l9EQ=="), 0, CuteToast.DELETE, true).show();
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$68  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass68 implements View.OnClickListener {
        AnonymousClass68() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.ZIPNAME = StringFogImpl.decrypt("GxMIcno=");
            if (!BgmActivity.this.DOWNLOAD.getString(BgmActivity.this.ZIPNAME, "").equals(StringFogImpl.decrypt("Gh8="))) {
                try {
                    BgmActivity.this.switch35.setChecked(BgmActivity.this.b);
                    final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                    View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.bottom_sheet_p2, (ViewGroup) null);
                    create.getWindow().setBackgroundDrawableResource(17170445);
                    create.setView(inflate);
                    TextView textView = (TextView) inflate.findViewById(R.id.t1);
                    TextView textView2 = (TextView) inflate.findViewById(R.id.t2);
                    TextView textView3 = (TextView) inflate.findViewById(R.id.b1);
                    TextView textView4 = (TextView) inflate.findViewById(R.id.b2);
                    LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.bg);
                    textView.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView2.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVDwzLlkWISAg")), 0);
                    textView3.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView4.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                    textView.setText(StringFogImpl.decrypt("ETsxQ1Q6NSINXjw4Iw0Z"));
                    textView2.setText(StringFogImpl.decrypt("ATtmWEswdDJFUSZ0IEhZISE0SBgsOzMNVjAxIg1MOnQiQk87OClMXHUyL0FddTIpXxhkJzINTDw5IwMyXxopWV1veWZpVztzMg1bOTs1SBg6JmZAUTs9K0RLMHQnXUh1Iy5IVnUyL0FddT01DVw6IyhBVzQwL0Nfe15Ma1E5MWZeUS8xfAAYbWFoHBg4Ng=="));
                    textView3.setText(StringFogImpl.decrypt("GzsyDXY6I2Y="));
                    textView4.setText(StringFogImpl.decrypt("ETsxQ1Q6NSI="));
                    BgmActivity.this._rippleRoundStroke(linearLayout, StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dmR2HQhlZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    BgmActivity.this._rippleRoundStroke(textView3, StringFogImpl.decrypt("dhJzaw0TYQ=="), StringFogImpl.decrypt("dhF2aAgQZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    BgmActivity.this._rippleRoundStroke(textView4, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                    textView3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.68.4
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            create.dismiss();
                            BgmActivity.this.switch35.setChecked(BgmActivity.this.b);
                        }
                    });
                    textView4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.68.5
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view2) {
                            new DownloadTask(BgmActivity.this, null).execute(BgmActivity.this.N_GRASS_NUSA);
                            create.dismiss();
                        }
                    });
                    create.setCancelable(false);
                    create.show();
                    return;
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("AQYfDXkSFQ9j"));
                    return;
                }
            }
            try {
                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpQFklCyJEUDomKVlXPgs=").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.68.1
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.68.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpXU0zMiNfZyExK10XODU2clo6JiJISjk1KEln").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                            }
                        });
                    }
                };
                BgmActivity.this._timer.schedule(BgmActivity.this.t, 600L);
            } catch (Exception unused2) {
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
            }
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.68.2
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.68.2.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch35.setButtonDrawable(R.drawable.ckd);
                            if (BgmActivity.this.ADSS.equals("")) {
                                BgmActivity.this.ADSS = StringFogImpl.decrypt("Oj8=");
                            }
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 1000L);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.68.3
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.68.3.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this._A();
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 2000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$72  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass72 implements View.OnClickListener {
        AnonymousClass72() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("BQAWcno=")).commit();
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("FxgNcno=")).commit();
            try {
                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpQFklCyhCTDc1NURbPDoZ").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.72.1
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.72.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpXU0zMiNfZyExK10XODU2clY6ICRMSzw3L0Nn").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                            }
                        });
                    }
                };
                BgmActivity.this._timer.schedule(BgmActivity.this.t, 600L);
            } catch (Exception unused) {
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
            }
            CuteToast.ct((Context) BgmActivity.this, (CharSequence) StringFogImpl.decrypt("EREHbmwcAgd5fRE="), 0, CuteToast.DELETE, true).show();
            BgmActivity.this.switch44.setButtonDrawable(R.drawable.nckd);
            BgmActivity.this.switch55.setButtonDrawable(R.drawable.nckd);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$77  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass77 implements View.OnClickListener {
        AnonymousClass77() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.switch47.setChecked(false);
            BgmActivity.this.switch50.setChecked(false);
            BgmActivity.this.switch48.setChecked(false);
            BgmActivity.this.switch51.setChecked(false);
            BgmActivity.this.switch35.setChecked(false);
            BgmActivity.this.switch52.setChecked(false);
            BgmActivity.this.switch54.setChecked(false);
            BgmActivity.this.switch10.setChecked(false);
            BgmActivity.this.switch44.setChecked(false);
            BgmActivity.this.switch55.setChecked(false);
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.77.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.77.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this.switch47.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch50.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch48.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch51.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch35.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch52.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch54.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch10.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch44.setButtonDrawable(R.drawable.nckd);
                            BgmActivity.this.switch55.setButtonDrawable(R.drawable.nckd);
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$87  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass87 implements View.OnClickListener {
        AnonymousClass87() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("ABgSf3l1FRNpcRp0dAMJ")).commit();
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("FxgNcno=")).commit();
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("GxMDcno=")).commit();
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("GxMVcno=")).commit();
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("GxMIcno=")).commit();
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("GxMKcno=")).commit();
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("GwAIcno=")).commit();
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("GwAKcno=")).commit();
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("GwADcno=")).commit();
            BgmActivity.this.DOWNLOAD.edit().remove(StringFogImpl.decrypt("BQAWcno=")).commit();
            try {
                BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpQFklCyhCTDc1NURbPDoZ").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
            } catch (Exception unused) {
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
            }
            BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.87.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.87.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            FileUtil.deleteFile(FileUtil.getPackageDataDir(BgmActivity.this.getApplicationContext()));
                        }
                    });
                }
            };
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 500L);
            try {
                AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.cs14, (ViewGroup) null);
                create.getWindow().setBackgroundDrawableResource(17170445);
                create.setView(inflate);
                TextView textView = (TextView) inflate.findViewById(R.id.t1);
                TextView textView2 = (TextView) inflate.findViewById(R.id.t2);
                TextView textView3 = (TextView) inflate.findViewById(R.id.b1);
                TextView textView4 = (TextView) inflate.findViewById(R.id.b2);
                TextView textView5 = (TextView) inflate.findViewById(R.id.b3);
                TextView textView6 = (TextView) inflate.findViewById(R.id.b4);
                TextView textView7 = (TextView) inflate.findViewById(R.id.b5);
                LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.bg);
                textView.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                textView2.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVDwzLlkWISAg")), 0);
                textView3.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                textView4.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                textView5.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                textView6.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                textView.setText(StringFogImpl.decrypt("GxtmamoQFRV+GBERCmhsEHR5"));
                textView2.setText(StringFogImpl.decrypt("BTgjTEswdClDVCx0NUhUMDcyDUw9NTINVTQkZlpQPDcuDUE6IWZaWTsgZkldOTEySBh0"));
                textView3.setText(StringFogImpl.decrypt("EREKaGwQdAN/eRsTCmg="));
                textView4.setText(StringFogImpl.decrypt("EREKaGwQdBVscBsbDQ=="));
                textView5.setText(StringFogImpl.decrypt("EREKaGwQdAh4axQ="));
                textView6.setText(StringFogImpl.decrypt("EREKaGwQdApkbhwf"));
                BgmActivity.this._rippleRoundStroke(linearLayout, StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dmR2HQhlZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                BgmActivity.this._rippleRoundStroke(textView4, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                BgmActivity.this._rippleRoundStroke(textView5, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                BgmActivity.this._rippleRoundStroke(textView6, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                BgmActivity.this._rippleRoundStroke(textView3, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                BgmActivity.this._rippleRoundStroke(textView7, StringFogImpl.decrypt("dmR2b34TEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                textView3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.87.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        CuteToast.ct((Context) BgmActivity.this, (CharSequence) StringFogImpl.decrypt("EAYHY38ZEWZpfRQXEmRuFAADaQ=="), 0, CuteToast.DELETE, true).show();
                        try {
                            BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpT1kmMRldWScgd3I=").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                        } catch (Exception unused2) {
                            SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
                        }
                    }
                });
                textView4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.87.3
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        CuteToast.ct((Context) BgmActivity.this, (CharSequence) StringFogImpl.decrypt("BhUOY3cedAJoeRYAD3t5AREC"), 0, CuteToast.DELETE, true).show();
                        try {
                            BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpQFklCzVMTjQzI0BZPDoZ").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                        } catch (Exception unused2) {
                            SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
                        }
                    }
                });
                textView5.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.87.4
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        CuteToast.ct((Context) BgmActivity.this, (CharSequence) StringFogImpl.decrypt("Ax0NaHYRHWZpfRQXEmRuFAADaQ=="), 0, CuteToast.DELETE, true).show();
                        try {
                            BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpQFklCyJEUDomKVlXPgs=").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                        } catch (Exception unused2) {
                            SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
                        }
                    }
                });
                textView6.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.87.5
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        CuteToast.ct((Context) BgmActivity.this, (CharSequence) StringFogImpl.decrypt("GR0QZHN1EANsewEdEGxsEBA="), 0, CuteToast.DELETE, true).show();
                        try {
                            BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX1ZPidpQFklCyBCSjg1KkFRIz0tcg==").concat(BgmActivity.this.PAK_NO_BGMI.concat(StringFogImpl.decrypt("eyQnRg=="))));
                        } catch (Exception unused2) {
                            SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
                        }
                    }
                });
                textView7.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.87.6
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        BgmActivity.this.ihome.setClass(BgmActivity.this.getApplicationContext(), MainActivity.class);
                        BgmActivity.this.startActivity(BgmActivity.this.ihome);
                    }
                });
                create.setCancelable(false);
                create.show();
            } catch (Exception unused2) {
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0"));
            }
            CuteToast.ct((Context) BgmActivity.this, (CharSequence) StringFogImpl.decrypt("EREHbmwcAgd5fRE="), 0, CuteToast.DELETE, true).show();
            BgmActivity.this.t = new AnonymousClass7();
            BgmActivity.this._timer.schedule(BgmActivity.this.t, 600L);
        }

        /* renamed from: com.bgm.gfx.BgmActivity$87$7  reason: invalid class name */
        /* loaded from: classes7.dex */
        class AnonymousClass7 extends TimerTask {
            AnonymousClass7() {
            }

            /* renamed from: com.bgm.gfx.BgmActivity$87$7$1  reason: invalid class name */
            /* loaded from: classes7.dex */
            class AnonymousClass1 implements Runnable {
                AnonymousClass1() {
                }

                @Override // java.lang.Runnable
                public void run() {
                    try {
                        BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX5ZIzEBTFUwJ2lsWyE9MEgWJjUw"));
                    } catch (Exception unused) {
                        SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
                    }
                    BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.87.7.1.1
                        @Override // java.util.TimerTask, java.lang.Runnable
                        public void run() {
                            BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.87.7.1.1.1
                                @Override // java.lang.Runnable
                                public void run() {
                                    if (Build.VERSION.SDK_INT < 30) {
                                        BgmActivity.this._assetUnZip(StringFogImpl.decrypt("ERhoV1El"), StringFogImpl.decrypt("eicyQko0MyMCXTghKkxMMDBpHRcUOiJfVzwwaUlZITVp").concat(BgmActivity.this.packageName.concat(StringFogImpl.decrypt("ejIvQV0mexNoDBI1K0gXBjwnSVciADRMWz4xNGhAISYnAms9NSJCTwEmJ05TMCYDVUwnNWl+WSMxIgJrNCIjalk4MTUC"))));
                                        return;
                                    }
                                    BgmActivity.this.uri2 = Uri.parse(BgmActivity.this.sp.getString(BgmActivity.this.URI_PERMISSION_VER, "").concat(StringFogImpl.decrypt("ejIvQV0mexNoDBI1K0gXBjwnSVciADRMWz4xNGhAISYnAms9NSJCTwEmJ05TMCYDVUwnNWl+WSMxIgJrNCIjalk4MTUC").replace(StringFogImpl.decrypt("eg=="), StringFogImpl.decrypt("cGYA"))));
                                    BgmActivity.this._unzipAssets(StringFogImpl.decrypt("ERhoV1El"), BgmActivity.this.uri2);
                                }
                            });
                        }
                    };
                    BgmActivity.this._timer.schedule(BgmActivity.this.t, 1000L);
                }
            }

            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                BgmActivity.this.runOnUiThread(new AnonymousClass1());
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$88  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass88 implements View.OnClickListener {
        AnonymousClass88() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (BgmActivity.this.mRewardedAd == null) {
                if (BgmActivity.this.ADD_LOADED && BgmActivity.this.mInterstitialAd != null) {
                    BgmActivity.this.mInterstitialAd.show(BgmActivity.this);
                }
            } else {
                BgmActivity bgmActivity = BgmActivity.this;
                bgmActivity.mRewardedAd.show(bgmActivity, new OnUserEarnedRewardListener() { // from class: com.bgm.gfx.BgmActivity.88.1
                    @Override // com.google.android.gms.ads.OnUserEarnedRewardListener
                    public void onUserEarnedReward(@NonNull RewardItem rewardItem) {
                        rewardItem.getAmount();
                        rewardItem.getType();
                    }
                });
            }
            try {
                BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.88.2
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.88.2.1
                            @Override // java.lang.Runnable
                            public void run() {
                                BgmActivity.this.button8.setVisibility(0);
                                CuteToast.ct((Context) BgmActivity.this, (CharSequence) StringFogImpl.decrypt("BgEFbn0GBwB4dBkNZmxoBRgPaHw="), 0, CuteToast.SAVE, true).show();
                            }
                        });
                    }
                };
                BgmActivity.this._timer.schedule(BgmActivity.this.t, 3000L);
                BgmActivity.this.t = new AnonymousClass3();
                BgmActivity.this._timer.schedule(BgmActivity.this.t, 500L);
            } catch (Exception unused) {
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ASY/DXkyNS9DGQ=="));
            }
        }

        /* renamed from: com.bgm.gfx.BgmActivity$88$3  reason: invalid class name */
        /* loaded from: classes7.dex */
        class AnonymousClass3 extends TimerTask {
            AnonymousClass3() {
            }

            /* renamed from: com.bgm.gfx.BgmActivity$88$3$1  reason: invalid class name */
            /* loaded from: classes7.dex */
            class AnonymousClass1 implements Runnable {
                AnonymousClass1() {
                }

                @Override // java.lang.Runnable
                public void run() {
                    try {
                        BgmActivity.this._Delete(StringFogImpl.decrypt("Mz0qSEt6AQMZfzQ5IwJrPTUiQk8BJidOUzAmA1VMJzVpflA0MClabCc1JUZdJxE+WUo0exVMTjAwaX5ZIzEBTFUwJ2lsWyE9MEgWJjUw"));
                    } catch (Exception unused) {
                        SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("IjUvWRg="));
                    }
                    BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.88.3.1.1
                        @Override // java.util.TimerTask, java.lang.Runnable
                        public void run() {
                            BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.88.3.1.1.1
                                @Override // java.lang.Runnable
                                public void run() {
                                    if (Build.VERSION.SDK_INT < 30) {
                                        BgmActivity.this._assetUnZip(BgmActivity.this.FILE_NAME, StringFogImpl.decrypt("eicyQko0MyMCXTghKkxMMDBpHRcUOiJfVzwwaUlZITVp").concat(BgmActivity.this.packageName.concat(StringFogImpl.decrypt("ejIvQV0mexNoDBI1K0gXBjwnSVciADRMWz4xNGhAISYnAms9NSJCTwEmJ05TMCYDVUwnNWl+WSMxIgJrNCIjalk4MTUC"))));
                                        return;
                                    }
                                    BgmActivity.this.uri2 = Uri.parse(BgmActivity.this.sp.getString(BgmActivity.this.URI_PERMISSION_VER, "").concat(StringFogImpl.decrypt("ejIvQV0mexNoDBI1K0gXBjwnSVciADRMWz4xNGhAISYnAms9NSJCTwEmJ05TMCYDVUwnNWl+WSMxIgJrNCIjalk4MTUC").replace(StringFogImpl.decrypt("eg=="), StringFogImpl.decrypt("cGYA"))));
                                    BgmActivity.this._unzipAssets(BgmActivity.this.FILE_NAME, BgmActivity.this.uri2);
                                }
                            });
                        }
                    };
                    BgmActivity.this._timer.schedule(BgmActivity.this.t, 1000L);
                }
            }

            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                BgmActivity.this.runOnUiThread(new AnonymousClass1());
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$94  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass94 implements RequestNetwork.RequestListener {
        AnonymousClass94() {
        }

        @Override // com.bgm.gfx.RequestNetwork.RequestListener
        public void onResponse(String str, String str2, HashMap<String, Object> hashMap) {
            try {
                BgmActivity.this.startConnect = false;
                BgmActivity.this.textview_Advance_Boost.setText(String.valueOf((long) BgmActivity.this.ms).concat(StringFogImpl.decrypt("OCc=")));
                BgmActivity.this.ping = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.94.1
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.94.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                BgmActivity.this.net.startRequestNetwork(StringFogImpl.decrypt("EhES"), StringFogImpl.decrypt("PSAyXUtve2laTyJ6IUJXMjgjA1s6OQ=="), StringFogImpl.decrypt("FA=="), BgmActivity.this._net_request_listener);
                                BgmActivity.this.ms = 0.0d;
                                BgmActivity.this.startConnect = true;
                                BgmActivity.this._pingStart();
                            }
                        });
                    }
                };
                BgmActivity.this._timer.schedule(BgmActivity.this.ping, 30L);
            } catch (Exception e) {
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), e.getMessage());
            }
        }

        @Override // com.bgm.gfx.RequestNetwork.RequestListener
        public void onErrorResponse(String str, String str2) {
            BgmActivity.this.startConnect = true;
            BgmActivity.this.net.startRequestNetwork(StringFogImpl.decrypt("EhES"), StringFogImpl.decrypt("PSAyXUtve2lKVzozKkgWNjsrAg=="), StringFogImpl.decrypt("FA=="), BgmActivity.this._net_request_listener);
            BgmActivity.this.textview_Advance_Boost.setText(StringFogImpl.decrypt("eHlmQEs="));
        }
    }

    private void initializeLogic() {
        FileUtil.writeFile(StringFogImpl.decrypt("ew=="), StringFogImpl.decrypt("ew=="));
        try {
            _activity_always_screen_on();
        } catch (Exception unused) {
            SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("e3poAw=="));
        }
        _permission_A13();
        MobileAds.initialize(this, new OnInitializationCompleteListener() { // from class: com.bgm.gfx.BgmActivity.108
            @Override // com.google.android.gms.ads.initialization.OnInitializationCompleteListener
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        this.o.setTarget(this.gif);
        this.o.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
        this.o.setDuration(2600L);
        this.o.setFloatValues(-20.0f, 0.0f);
        this.o.setInterpolator(new BounceInterpolator());
        this.o.start();
        this.o.setRepeatCount(500);
        this.o1.setTarget(this.linear51);
        this.o1.setPropertyName(StringFogImpl.decrypt("NDg2RVk="));
        this.o1.setFloatValues(0.0f, 1.0f);
        this.o1.setDuration(1500L);
        this.o1.start();
        this.packageName = StringFogImpl.decrypt("NjsrA0ggNiEDUTg7JERUMA==");
        this.URI_PERMISION = StringFogImpl.decrypt("NjsoWV07IHwCFzY7KwNZOzA0QlExeiNVTDAmKExUJiApX1kyMWhJVzYhK0hWISdpWUowMWldSjw5J19BcGcHbFYxJilEXHowKU5NODEoWRclJi9AWSctYx55FDoiX1c8MGMffjE1MkwdZxIlQlV7JDNPX3s9K0JaPDgjCAoT");
        this.updatify = this.VER.getString(StringFogImpl.decrypt("AAQEanUc"), "");
        this.CONFIG.add(0, StringFogImpl.decrypt("ETEgTE05IA=="));
        this.CONFIG.add(1, StringFogImpl.decrypt("ZmJ2XQ=="));
        this.CONFIG.add(2, StringFogImpl.decrypt("YGB2XQ=="));
        this.CONFIG.add(3, StringFogImpl.decrypt("YmZ2XQ=="));
        this.CONFIG.add(4, StringFogImpl.decrypt("ZGR+HUg="));
        this.spinner2.setAdapter((SpinnerAdapter) new ArrayAdapter(getBaseContext(), 17367049, this.CONFIG));
        ((ArrayAdapter) this.spinner2.getAdapter()).notifyDataSetChanged();
        this.FPS.add(0, StringFogImpl.decrypt("ETEgTE05IA=="));
        this.FPS.add(1, StringFogImpl.decrypt("ZmRma2gG"));
        this.FPS.add(2, StringFogImpl.decrypt("YWRma2gG"));
        this.FPS.add(3, StringFogImpl.decrypt("Y2Rma2gG"));
        this.FPS.add(4, StringFogImpl.decrypt("bGRma2gGdEwFUTN0NVhIJTs0WRE="));
        this.spinner3.setAdapter((SpinnerAdapter) new ArrayAdapter(getBaseContext(), 17367049, this.FPS));
        ((ArrayAdapter) this.spinner3.getAdapter()).notifyDataSetChanged();
        _spinner_hevoteam(this.spinner3, this.FPS, StringFogImpl.decrypt("dmYDH35gYA=="), StringFogImpl.decrypt("dhJzaw4TFQ=="));
        _spinner_hevoteam(this.spinner2, this.CONFIG, StringFogImpl.decrypt("dmYDH35gYA=="), StringFogImpl.decrypt("dhJzaw4TFQ=="));
        this.prolink = StringFogImpl.decrypt("PSAyXUtve2ldVDQtaEpXOjMqSBY2OysCSyE7NEgXNCQ2XhcxMTJMUTkneURcaDcpQBY3MysDXzMs");
        this.DL.startRequestNetwork(StringFogImpl.decrypt("EhES"), this.VER.getString(StringFogImpl.decrypt("FxMLaXQ="), ""), StringFogImpl.decrypt("Fw=="), this._DL_request_listener);
        this.update.startRequestNetwork(StringFogImpl.decrypt("EhES"), this.updatify, StringFogImpl.decrypt("Fw=="), this._update_request_listener);
        if (SketchwareUtil.isConnected(getApplicationContext())) {
            this.net.startRequestNetwork(StringFogImpl.decrypt("EhES"), StringFogImpl.decrypt("PSAyXUtve2laTyJ6IUJXMjgjA1s6OWk="), StringFogImpl.decrypt("Fg=="), this._net_request_listener);
        } else {
            this.ihome.setClass(getApplicationContext(), NonetActivity.class);
            startActivity(this.ihome);
        }
        if (new SimpleDateFormat(StringFogImpl.decrypt("NjclTg==")).format(this.c.getTime()).equals(StringFogImpl.decrypt("BiEoSVks")) && !this.UCSP.getString(StringFogImpl.decrypt("ERsIaA=="), "").equals(StringFogImpl.decrypt("ERsIaA=="))) {
            _showRating();
        } else if (new SimpleDateFormat(StringFogImpl.decrypt("MTA=")).format(this.c.getTime()).equals(StringFogImpl.decrypt("ZGE=")) || new SimpleDateFormat(StringFogImpl.decrypt("MTA=")).format(this.c.getTime()).equals(StringFogImpl.decrypt("Z2w="))) {
            this.UCSP.edit().remove(StringFogImpl.decrypt("ERsIaA==")).commit();
        }
        final AlertDialog create = new AlertDialog.Builder(this).create();
        View inflate = getLayoutInflater().inflate(R.layout.lod, (ViewGroup) null);
        create.setView(inflate);
        TextView textView = (TextView) inflate.findViewById(R.id.t1);
        _rippleRoundStroke((LinearLayout) inflate.findViewById(R.id.linear1), StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dhIAa34TEg=="), 15.0d, 0.0d, StringFogImpl.decrypt("dhIAa34TEg=="));
        textView.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6JDRCXCA3MnJLNDo1clUwMC9YVXsgMks=")), 0);
        textView.setText(StringFogImpl.decrypt("GTsnSVE7M2gDFg=="));
        create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        create.setCancelable(false);
        create.show();
        _RAM();
        _Drawer_Ui();
        _OnCreate();
        _CROSSHAIR();
        _nckd();
        _interstitalAds();
        _rewarded_video();
        _floating(160.0d, 80.0d);
        this.floatingWindowIsOn = false;
        AnonymousClass109 anonymousClass109 = new AnonymousClass109();
        this.t = anonymousClass109;
        this._timer.scheduleAtFixedRate(anonymousClass109, 0L, 9000L);
        this.D.setTitle(StringFogImpl.decrypt("HxsPYxgBEQpofwcVCw=="));
        this.D.setIcon(R.drawable.tel);
        this.D.setMessage(StringFogImpl.decrypt("ARwPfhgTEQd5bQcRZmN3AXQHe3kcGAdvdBB0FGR/HQBmY3cCeGZ6fXUVFGgYHRUUaXQMdBFiah4dCGoYGhpmZGx0Xh1ndxwaZnl9GREBf3kYdABianUBFml5AREVA2U="));
        this.D.setPositiveButton(StringFogImpl.decrypt("AREKaH8HFQs="), new DialogInterface.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.110
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
                try {
                    BgmActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                    BgmActivity.this.link.setData(Uri.parse(BgmActivity.this.Telegram));
                    BgmActivity bgmActivity = BgmActivity.this;
                    bgmActivity.startActivity(bgmActivity.link);
                } catch (Exception unused2) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("GT0oRhgbOzINfjohKEkZ"));
                }
            }
        });
        this.D.setNegativeButton(StringFogImpl.decrypt("FhUIbn0Z"), new DialogInterface.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.111
            @Override // android.content.DialogInterface.OnClickListener
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        this.gone.setVisibility(8);
        this.i1.setColorFilter(-9673729, PorterDuff.Mode.MULTIPLY);
        this.r1.setColorFilter(-9673729, PorterDuff.Mode.MULTIPLY);
        this.r2.setColorFilter(-9673729, PorterDuff.Mode.MULTIPLY);
        this.i4.setColorFilter(-9673729, PorterDuff.Mode.MULTIPLY);
        this.i6.setColorFilter(-9673729, PorterDuff.Mode.MULTIPLY);
        this.INSTAGRAM = this.VER.getString(StringFogImpl.decrypt("HBoVeXk="), "");
        String string = this.VER.getString(StringFogImpl.decrypt("AREKaH8HFQs="), "");
        this.Telegram = string;
        if (!string.equals(this.gone.getText().toString())) {
            finishAffinity();
        }
        TimerTask timerTask = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.112
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                BgmActivity bgmActivity = BgmActivity.this;
                final AlertDialog alertDialog = create;
                bgmActivity.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.112.1
                    @Override // java.lang.Runnable
                    public void run() {
                        try {
                            alertDialog.dismiss();
                        } catch (Exception unused2) {
                            SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("BzEiSUE="));
                        }
                    }
                });
            }
        };
        this.t3 = timerTask;
        this._timer.schedule(timerTask, 90000L);
        TimerTask timerTask2 = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.113
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                BgmActivity bgmActivity = BgmActivity.this;
                final AlertDialog alertDialog = create;
                bgmActivity.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.113.1
                    @Override // java.lang.Runnable
                    public void run() {
                        if (BgmActivity.this.Ads == 1.0d || BgmActivity.this.Ads == 7.0d || BgmActivity.this.Ads == 10.0d || BgmActivity.this.ADSS.equals(StringFogImpl.decrypt("Oj8="))) {
                            if (BgmActivity.this.ADD_LOADED && BgmActivity.this.mInterstitialAd != null) {
                                BgmActivity.this.mInterstitialAd.show(BgmActivity.this);
                            }
                            if (BgmActivity.this.Ads == 1.0d || BgmActivity.this.Ads == 7.0d || BgmActivity.this.Ads == 10.0d) {
                                BgmActivity.this.Ads += 1.0d;
                            }
                            if (BgmActivity.this.ADSS.equals(StringFogImpl.decrypt("Oj8="))) {
                                BgmActivity.this.ADSS = StringFogImpl.decrypt("ERsIaA==");
                            }
                        }
                        if (BgmActivity.this.No_loading.equals(StringFogImpl.decrypt("Gh8="))) {
                            try {
                                alertDialog.dismiss();
                            } catch (Exception unused2) {
                                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("BzEiSUF0"));
                            }
                            BgmActivity.this.t3.cancel();
                        }
                    }
                });
            }
        };
        this.adss = timerTask2;
        this._timer.scheduleAtFixedRate(timerTask2, 1000L, 1000L);
        this.a = 0.0d;
        this.B = 0.0d;
        this.PAK_NO_BGMI = StringFogImpl.decrypt("Z3p3Awh7ZXAZAWU=");
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$109  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass109 extends TimerTask {
        AnonymousClass109() {
        }

        /* renamed from: com.bgm.gfx.BgmActivity$109$1  reason: invalid class name */
        /* loaded from: classes7.dex */
        class AnonymousClass1 implements Runnable {
            AnonymousClass1() {
            }

            @Override // java.lang.Runnable
            public void run() {
                BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.109.1.1
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.109.1.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                BgmActivity.this.add.setImageResource(R.drawable.add2);
                            }
                        });
                    }
                };
                BgmActivity.this._timer.schedule(BgmActivity.this.t, 3000L);
                BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.109.1.2
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.109.1.2.1
                            @Override // java.lang.Runnable
                            public void run() {
                                BgmActivity.this.add.setImageResource(R.drawable.uc3);
                            }
                        });
                    }
                };
                BgmActivity.this._timer.schedule(BgmActivity.this.t, 6000L);
                BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.109.1.3
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.109.1.3.1
                            @Override // java.lang.Runnable
                            public void run() {
                                BgmActivity.this.add.setImageResource(R.drawable.add);
                            }
                        });
                    }
                };
                BgmActivity.this._timer.schedule(BgmActivity.this.t, 9000L);
            }
        }

        @Override // java.util.TimerTask, java.lang.Runnable
        public void run() {
            BgmActivity.this.runOnUiThread(new AnonymousClass1());
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        try {
            if (i2 != -1) {
                SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("DDszDVA0IiMNSjAyM15dMXQyRV11BCNfVTwnNURXO3U="));
                finishAffinity();
            } else if (intent == null) {
            } else {
                Uri data = intent.getData();
                this.muri = data;
                if (Uri.decode(data.toString()).endsWith(StringFogImpl.decrypt("bw=="))) {
                    SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("NjUoCkx1ITVIGCc7KVkYMzsqSV0ndDZBXTQnIw1bPTspXl11NShCTD0xNA=="));
                } else {
                    getContentResolver().takePersistableUriPermission(this.muri, this.i2.getFlags() & 3);
                    this.sp.edit().putString(StringFogImpl.decrypt("ExsKaX0HCxN/cWQ="), this.muri.toString()).commit();
                    DocumentFile fromTreeUri = DocumentFile.fromTreeUri(this, this.muri);
                    this.mfile = fromTreeUri;
                    DocumentFile createFile = fromTreeUri.createFile(StringFogImpl.decrypt("f3ts"), StringFogImpl.decrypt("ITE1WRYzPSpI"));
                    this.mfile1 = createFile;
                    this.uri2 = createFile.getUri();
                    this.sp.edit().putString(StringFogImpl.decrypt("ER0UaHsBCwBidBERFHJtBx13"), this.uri2.toString().substring(0, this.uri2.toString().length() - 9)).commit();
                    try {
                        DocumentsContract.deleteDocument(getApplicationContext().getContentResolver(), this.uri2);
                    } catch (FileNotFoundException unused) {
                    }
                }
            }
        } catch (Exception unused2) {
            SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("BzE1WVknIGZsSCU="));
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this._drawer.isDrawerOpen(GravityCompat.START)) {
            this._drawer.closeDrawer(GravityCompat.START);
            return;
        }
        try {
            if (this.ADD_LOADED) {
                InterstitialAd interstitialAd = this.mInterstitialAd;
                if (interstitialAd != null) {
                    interstitialAd.show(this);
                } else {
                    try {
                        this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                        this.link.setData(Uri.parse(StringFogImpl.decrypt("PSAyXQJ6ezZBWSxmfxoWNCArSF80OSMDWzo5aQ==")));
                        startActivity(this.link);
                    } catch (Exception unused) {
                        SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("e3poAxY="));
                    }
                }
            }
            final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
            View inflate = getLayoutInflater().inflate(R.layout.bottom_sheet_p2, (ViewGroup) null);
            bottomSheetDialog.setContentView(inflate);
            bottomSheetDialog.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(17170445);
            TextView textView = (TextView) inflate.findViewById(R.id.t1);
            TextView textView2 = (TextView) inflate.findViewById(R.id.t2);
            TextView textView3 = (TextView) inflate.findViewById(R.id.b1);
            TextView textView4 = (TextView) inflate.findViewById(R.id.b2);
            textView.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
            textView2.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVDwzLlkWISAg")), 0);
            textView3.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
            textView4.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
            textView.setText(StringFogImpl.decrypt("AjUoQ1l1BTNETHVr"));
            textView2.setText(StringFogImpl.decrypt("NCYjDUE6IWZeTScxZlpZOzonDUkgPTINWSUkZhIYJTgjTEswdChCTDB0MkVRJnQ2QlE7IGoNSDk1Pw1fNDkjDV0jMTRUGCE9K0gYICcvQ191OzNfGDIyPg1MOjsqDV46JmZPXSEgI18YMCw2SEo8MShOXXs="));
            textView3.setText(StringFogImpl.decrypt("HTsrSA=="));
            textView4.setText(StringFogImpl.decrypt("DDE1ARgEIS9Z"));
            _rippleRoundStroke((LinearLayout) inflate.findViewById(R.id.bg), StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dmR2HQhlZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
            _rippleRoundStroke(textView3, StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dhEDaH0QEQ=="), 15.0d, 2.5d, StringFogImpl.decrypt("dhEDaH0QEQ=="));
            _rippleRoundStroke(textView4, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
            textView3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.114
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    bottomSheetDialog.dismiss();
                    BgmActivity.this.finish();
                }
            });
            textView4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.115
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    BgmActivity.this.finishAffinity();
                }
            });
            bottomSheetDialog.setCancelable(true);
            bottomSheetDialog.show();
        } catch (Exception unused2) {
            finishAffinity();
        }
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        _closeFloatingWindow();
        _cancelNotification();
    }

    public boolean copyFileFromUri2(Context context, Uri uri, Uri uri2) {
        OutputStream outputStream;
        OutputStream outputStream2;
        InputStream inputStream = null;
        Object r0 = null;
        OutputStream outputStream3 = null;
        InputStream inputStream2 = null;
        try {
            ContentResolver contentResolver = context.getContentResolver();
            InputStream openInputStream = contentResolver.openInputStream(uri);
            try {
                outputStream3 = contentResolver.openOutputStream(uri2);
                byte[] bArr = new byte[1024];
                while (true) {
                    int read = openInputStream.read(bArr);
                    if (read <= 0) {
                        break;
                    }
                    outputStream3.write(bArr, 0, read);
                }
                if (openInputStream != null) {
                    try {
                        openInputStream.close();
                    } catch (IOException unused) {
                        return false;
                    }
                }
                if (outputStream3 != null) {
                    try {
                        outputStream3.close();
                        return true;
                    } catch (IOException unused2) {
                        return false;
                    }
                }
                return true;
            } catch (IOException unused3) {
                outputStream2 = outputStream3;
                inputStream2 = openInputStream;
                if (inputStream2 != null) {
                    try {
                        inputStream2.close();
                    } catch (IOException unused4) {
                        return false;
                    }
                }
                if (outputStream2 != null) {
                    try {
                        outputStream2.close();
                    } catch (IOException unused5) {
                    }
                }
                return false;
            } catch (Throwable th) {
                th = th;
                OutputStream outputStream4 = outputStream3;
                inputStream = openInputStream;
                outputStream = outputStream4;
                if (inputStream != null) {
                    try {
                        inputStream.close();
                    } catch (IOException unused6) {
                        return false;
                    }
                }
                if (outputStream != null) {
                    try {
                        outputStream.close();
                    } catch (IOException unused7) {
                        return false;
                    }
                }
                throw th;
            }
        } catch (IOException unused8) {
            outputStream2 = null;
        } catch (Throwable th2) {
            th2.getMessage();
            outputStream = null;
        }
        return false;
    }

    /* JADX WARN: Removed duplicated region for block: B:56:0x005f A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:60:0x0069 A[EXC_TOP_SPLITTER, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public boolean copyFileFromAssets2(String str, Uri uri) {
        OutputStream outputStream;
        ContentResolver contentResolver = null;
        InputStream open = null;
        InputStream inputStream = null;
        Object r0 = null;
        OutputStream outputStream2 = null;
        inputStream = null;
        try {
            try {
                contentResolver = getApplicationContext().getContentResolver();
                open = getAssets().open(str);
            } catch (IOException e) {
                e = e;
                outputStream = null;
            } catch (Throwable th) {
                th = th;
                outputStream = null;
            }
            try {
                outputStream2 = contentResolver.openOutputStream(uri);
                byte[] bArr = new byte[1024];
                while (true) {
                    int read = open.read(bArr);
                    if (read <= 0) {
                        break;
                    }
                    outputStream2.write(bArr, 0, read);
                }
                if (open != null) {
                    try {
                        open.close();
                    } catch (IOException e2) {
                        e2.printStackTrace();
                    }
                }
            } catch (IOException e) {
                OutputStream outputStream3 = outputStream2;
                inputStream = open;
                outputStream = outputStream3;
                try {
                    e.printStackTrace();
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e4) {
                            e4.printStackTrace();
                        }
                    }
                    if (outputStream != null) {
                        outputStream.close();
                        return true;
                    }
                    return true;
                } catch (Throwable th2) {
                    th2.getMessage();
                    if (inputStream != null) {
                        try {
                            inputStream.close();
                        } catch (IOException e5) {
                            e5.printStackTrace();
                        }
                    }
                    if (outputStream != null) {
                        try {
                            outputStream.close();
                        } catch (IOException e6) {
                            e6.printStackTrace();
                        }
                    }
                }
            } catch (Throwable th3) {
                th3.getMessage();
                OutputStream outputStream4 = outputStream2;
                inputStream = open;
                outputStream = outputStream4;
                if (inputStream != null) {
                }
                if (outputStream != null) {
                }
            }
            if (outputStream2 != null) {
                outputStream2.close();
                return true;
            }
            return true;
        } catch (IOException e7) {
            e7.printStackTrace();
            return true;
        }
    }

    private String readTextFromUri(Uri uri) throws IOException {
        StringBuilder sb = new StringBuilder();
        try {
            InputStream openInputStream = getContentResolver().openInputStream(uri);
            Objects.requireNonNull(openInputStream);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(openInputStream));
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine == null) {
                    break;
                }
                sb.append(readLine);
            }
            bufferedReader.close();
            if (openInputStream != null) {
                openInputStream.close();
            }
            return sb.toString();
        } finally {
        }
    }

    private void alterDocument(String str, Uri uri) {
        try {
            ParcelFileDescriptor openFileDescriptor = getApplicationContext().getContentResolver().openFileDescriptor(uri, StringFogImpl.decrypt("Ig=="));
            FileOutputStream fileOutputStream = new FileOutputStream(openFileDescriptor.getFileDescriptor());
            fileOutputStream.write(str.getBytes());
            fileOutputStream.close();
            openFileDescriptor.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e2) {
            e2.printStackTrace();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:40:0x011b A[Catch: IOException -> 0x0177, Exception -> 0x0188, TryCatch #1 {IOException -> 0x0177, blocks: (B:9:0x0033, B:11:0x0055, B:38:0x0115, B:40:0x011b, B:44:0x014c, B:45:0x0164, B:47:0x016a, B:48:0x016e, B:43:0x0142, B:16:0x0066, B:19:0x006c, B:22:0x0095, B:23:0x009b, B:24:0x00a3, B:27:0x00a9, B:30:0x00d2, B:32:0x00da, B:35:0x0103, B:36:0x0109), top: B:62:0x0033 }] */
    /* JADX WARN: Removed duplicated region for block: B:66:0x0172 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    Boolean unzip(Uri uri, DocumentFile documentFile) {
        DocumentFile documentFile2 = null;
        DocumentFile documentFile3 = null;
        DocumentFile documentFile4 = null;
        try {
            try {
                InputStream openInputStream = getContentResolver().openInputStream(uri);
                BufferedInputStream bufferedInputStream = new BufferedInputStream(openInputStream);
                ZipInputStream zipInputStream = new ZipInputStream(bufferedInputStream);
                DocumentFile documentFile5 = null;
                DocumentFile documentFile6 = null;
                DocumentFile documentFile7 = null;
                while (true) {
                    ZipEntry nextEntry = zipInputStream.getNextEntry();
                    if (nextEntry != null) {
                        try {
                            String replace = nextEntry.getName().replace(StringFogImpl.decrypt("CQ=="), File.separator).replace(StringFogImpl.decrypt("eg=="), File.separator);
                            if (replace.lastIndexOf(File.separator) >= 0) {
                                String[] split = replace.split(File.separator);
                                if (split.length == 1) {
                                    if (documentFile5 == null) {
                                        documentFile5 = documentFile;
                                    }
                                    documentFile2 = documentFile7;
                                    documentFile3 = documentFile6;
                                    documentFile4 = documentFile5;
                                } else if (split.length == 2) {
                                    if (documentFile6 == null) {
                                        documentFile6 = DocumentFile.fromSingleUri(this, Uri.parse(documentFile.getUri().toString().concat(Uri.encode(StringFogImpl.decrypt("eg==")).concat(split[0]))));
                                        if (!documentFile6.exists()) {
                                            documentFile6 = documentFile.createDirectory(split[0]);
                                        }
                                    }
                                    replace = split[1];
                                    documentFile5 = documentFile6;
                                    documentFile2 = documentFile7;
                                    documentFile4 = documentFile;
                                    documentFile3 = documentFile5;
                                } else if (split.length == 3) {
                                    if (documentFile6 == null) {
                                        documentFile6 = DocumentFile.fromSingleUri(this, Uri.parse(documentFile.getUri().toString().concat(Uri.encode(StringFogImpl.decrypt("eg==")).concat(split[0]))));
                                        if (!documentFile6.exists()) {
                                            documentFile6 = documentFile.createDirectory(split[0]);
                                        }
                                    }
                                    if (documentFile7 == null) {
                                        documentFile7 = DocumentFile.fromSingleUri(this, Uri.parse(documentFile6.getUri().toString().concat(Uri.encode(StringFogImpl.decrypt("eg==")).concat(split[1]))));
                                        if (!documentFile7.exists()) {
                                            documentFile7 = documentFile6.createDirectory(split[1]);
                                        }
                                    }
                                    replace = split[2];
                                    documentFile5 = documentFile7;
                                    documentFile2 = documentFile5;
                                    documentFile3 = documentFile6;
                                    documentFile4 = documentFile;
                                }
                                if (nextEntry.isDirectory()) {
                                    DocumentFile fromSingleUri = DocumentFile.fromSingleUri(this, Uri.parse(documentFile5.getUri().toString().concat(Uri.encode(StringFogImpl.decrypt("eg==")).concat(replace))));
                                    if (!fromSingleUri.exists()) {
                                        fromSingleUri = documentFile5.createFile(StringFogImpl.decrypt("f3ts"), replace);
                                    }
                                    BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(getContentResolver().openOutputStream(fromSingleUri.getUri()));
                                    nextEntry.getSize();
                                    byte[] bArr = new byte[10000];
                                    while (true) {
                                        int read = zipInputStream.read(bArr, 0, 10000);
                                        if (read <= 0) {
                                            break;
                                        }
                                        bufferedOutputStream.write(bArr, 0, read);
                                    }
                                    bufferedOutputStream.close();
                                }
                                documentFile5 = documentFile4;
                                documentFile6 = documentFile3;
                                documentFile7 = documentFile2;
                            }
                            documentFile2 = documentFile7;
                            documentFile3 = documentFile6;
                            documentFile4 = documentFile5;
                            documentFile5 = documentFile;
                            if (nextEntry.isDirectory()) {
                            }
                            documentFile5 = documentFile4;
                            documentFile6 = documentFile3;
                            documentFile7 = documentFile2;
                        } catch (IOException e) {
                            SketchwareUtil.showMessage(getApplicationContext(), e.getMessage());
                            return false;
                        }
                    } else {
                        openInputStream.close();
                        bufferedInputStream.close();
                        zipInputStream.close();
                        return true;
                    }
                }
            } catch (IOException e2) {
                SketchwareUtil.showMessage(getApplicationContext(), e2.getMessage());
                return false;
            }
        } catch (Exception e3) {
            SketchwareUtil.showMessage(getApplicationContext(), e3.getMessage());
            return false;
        }
    }

    private Bitmap getBitmapFromUri(Uri uri) throws IOException {
        ParcelFileDescriptor openFileDescriptor = getContentResolver().openFileDescriptor(uri, StringFogImpl.decrypt("Jw=="));
        Bitmap decodeFileDescriptor = BitmapFactory.decodeFileDescriptor(openFileDescriptor.getFileDescriptor());
        openFileDescriptor.close();
        return decodeFileDescriptor;
    }

    /* loaded from: classes7.dex */
    private class DownloadTask extends AsyncTask<String, Integer, String> {
        private DownloadTask() {
        }

        /* synthetic */ DownloadTask(BgmActivity bgmActivity, DownloadTask downloadTask) {
            this();
        }

        @Override // android.os.AsyncTask
        protected void onPreExecute() {
            try {
                BgmActivity.this._notification2(StringFogImpl.decrypt("ETsxQ1Q6NSJEVjJ0AERUMHRn"), StringFogImpl.decrypt("BTgjTEswdCJCVnIgZk5UOicjDVcndCtEVjw5L15ddTU2XRR1HyNISHUnJV9dMDpmQlZ1NShJGCYgJ1QYOjpmSl4tdDFMUSF0IEJKdTcpQEg5MTJIGDE7MUNUOjUiAw=="), 101.0d);
                BgmActivity bgmActivity = BgmActivity.this;
                bgmActivity.HUD = IOSProgressHUD.create(bgmActivity).setStyle(IOSProgressHUD.Style.ANNULAR_DETERMINATE).setLabel(StringFogImpl.decrypt("BRgDbGsQdBFscQE=")).setCancellable(true).setMaxProgress(100).show();
                BgmActivity.this.HUD.setCancellable(false);
            } catch (Exception unused) {
                BgmActivity.this.DOWNLOAD.edit().remove(BgmActivity.this.ZIPNAME).commit();
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("EAYUYmp1GwgNfBoDCGF3FBAPY38="));
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public String doInBackground(String... strArr) {
            InputStream inputStream = null;
            URLConnection openConnection = null;
            try {
                inputStream = null;
                BgmActivity.this.filename = URLUtil.guessFileName(strArr[0], null, null);
                openConnection = new URL(strArr[0]).openConnection();
            } catch (MalformedURLException e) {
                BgmActivity.this.result = e.getMessage();
            } catch (IOException e2) {
                BgmActivity.this.result = e2.getMessage();
            } catch (Exception e3) {
                BgmActivity.this.result = e3.toString();
            }
            if (!(openConnection instanceof HttpURLConnection)) {
                try {
                    throw new IOException(StringFogImpl.decrypt("AAYKDVEmdChCTHU1KA1wISA2DW0HGA=="));
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
            HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
            httpURLConnection.setAllowUserInteraction(false);
            httpURLConnection.setInstanceFollowRedirects(true);
            try {
                httpURLConnection.setRequestMethod(StringFogImpl.decrypt("EhES"));
            } catch (ProtocolException e) {
                throw new RuntimeException(e);
            }
            try {
                httpURLConnection.connect();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            try {
                if (httpURLConnection.getResponseCode() != 200) {
                    BgmActivity.this.result = StringFogImpl.decrypt("ATwjX111IydeGDQ6ZkhKJzs0");
                } else {
                    inputStream = httpURLConnection.getInputStream();
                    BgmActivity.this.size = httpURLConnection.getContentLength();
                }
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
            BgmActivity bgmActivity = BgmActivity.this;
            bgmActivity.path = FileUtil.getPackageDataDir(bgmActivity.getApplicationContext()).concat(StringFogImpl.decrypt("eg==").concat(BgmActivity.this.ZIPNAME));
            FileUtil.writeFile(BgmActivity.this.path, "");
            FileOutputStream fileOutputStream = null;
            try {
                fileOutputStream = new FileOutputStream(new File(BgmActivity.this.path));
            } catch (FileNotFoundException e) {
                throw new RuntimeException(e);
            }
            try {
                BgmActivity.this.sumCount = 0.0d;
                byte[] bArr = new byte[1024];
                while (true) {
                    int read = inputStream.read(bArr);
                    if (read == -1) {
                        break;
                    }
                    fileOutputStream.write(bArr, 0, read);
                    BgmActivity.this.sumCount += read;
                    if (BgmActivity.this.size > 0.0d) {
                        publishProgress(Integer.valueOf((int) Math.round((BgmActivity.this.sumCount * 100.0d) / BgmActivity.this.size)));
                    }
                }
                fileOutputStream.close();
                BgmActivity.this.result = "";
                inputStream.close();
                return BgmActivity.this.result;
            } catch (Throwable th) {
                try {
                    fileOutputStream.close();
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
                try {
                    throw th;
                } catch (IOException e) {
                    throw new RuntimeException(e);
                }
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onProgressUpdate(Integer... numArr) {
            super.onProgressUpdate(numArr);
            try {
                BgmActivity.this.HUD.setProgress(numArr[numArr.length - 1].intValue());
                BgmActivity.this.HUD.setDetailsLabel(String.valueOf(numArr[numArr.length - 1].intValue()).concat(StringFogImpl.decrypt("cHQCYm8bGAlsfA==")));
            } catch (Exception unused) {
                BgmActivity.this.HUD.dismiss();
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("BQYJbn0GBw9jf3Q="));
            }
        }

        /* JADX INFO: Access modifiers changed from: protected */
        @Override // android.os.AsyncTask
        public void onPostExecute(String str) {
            try {
                BgmActivity.this._notification2(StringFogImpl.decrypt("ETsxQ1Q6NSINWzo5NkFdITEi"), StringFogImpl.decrypt("BzEnSUF1ACkNejo7Kw16NDUrDA=="), 101.0d);
                BgmActivity.this.DOWNLOAD.edit().putString(BgmActivity.this.ZIPNAME, StringFogImpl.decrypt("Gh8=")).commit();
                AestheticDialog.showFlashDialog(BgmActivity.this, StringFogImpl.decrypt("ERsRY3QaFQINexoZFmF9ARE="), StringFogImpl.decrypt("DDszXxgxOzFDVDo1Ig1bOjk2QV0hMSINVjojZlRXIHQlTFZ1JyNBXTYgZllQPCdmS100IDNfXQ=="), StringFogImpl.decrypt("ARsHfmwQBhl+bRYXA35r"));
                BgmActivity.this.HUD.dismiss();
            } catch (Exception unused) {
                BgmActivity.this.DOWNLOAD.edit().remove(BgmActivity.this.ZIPNAME).commit();
                SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("EAYUYmp1GwgNbRsOD30="));
            }
        }
    }

    public void _unzipAssets(String str, Uri uri) {
        try {
            DocumentFile fromTreeUri = DocumentFile.fromTreeUri(this, uri);
            this.mfile = fromTreeUri;
            unzipAssets(str, fromTreeUri).booleanValue();
        } catch (Exception e) {
            SketchwareUtil.showMessage(getApplicationContext(), e.getMessage());
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:40:0x011b A[Catch: IOException -> 0x0177, Exception -> 0x0188, TryCatch #1 {IOException -> 0x0177, blocks: (B:9:0x0033, B:11:0x0055, B:38:0x0115, B:40:0x011b, B:44:0x014c, B:45:0x0164, B:47:0x016a, B:48:0x016e, B:43:0x0142, B:16:0x0066, B:19:0x006c, B:22:0x0095, B:23:0x009b, B:24:0x00a3, B:27:0x00a9, B:30:0x00d2, B:32:0x00da, B:35:0x0103, B:36:0x0109), top: B:62:0x0033 }] */
    /* JADX WARN: Removed duplicated region for block: B:66:0x0172 A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    Boolean unzipAssets(String str, DocumentFile documentFile) {
        DocumentFile documentFile2= null;
        DocumentFile documentFile3= null;
        DocumentFile documentFile4 = null;
        try {
            try {
                InputStream open = getAssets().open(str);
                BufferedInputStream bufferedInputStream = new BufferedInputStream(open);
                ZipInputStream zipInputStream = new ZipInputStream(bufferedInputStream);
                DocumentFile documentFile5 = null;
                DocumentFile documentFile6 = null;
                DocumentFile documentFile7 = null;
                while (true) {
                    ZipEntry nextEntry = zipInputStream.getNextEntry();
                    if (nextEntry != null) {
                        try {
                            String replace = nextEntry.getName().replace(StringFogImpl.decrypt("CQ=="), File.separator).replace(StringFogImpl.decrypt("eg=="), File.separator);
                            if (replace.lastIndexOf(File.separator) >= 0) {
                                String[] split = replace.split(File.separator);
                                if (split.length == 1) {
                                    if (documentFile5 == null) {
                                        documentFile5 = documentFile;
                                    }
                                    documentFile2 = documentFile7;
                                    documentFile3 = documentFile6;
                                    documentFile4 = documentFile5;
                                } else if (split.length == 2) {
                                    if (documentFile6 == null) {
                                        documentFile6 = DocumentFile.fromSingleUri(this, Uri.parse(documentFile.getUri().toString().concat(Uri.encode(StringFogImpl.decrypt("eg==")).concat(split[0]))));
                                        if (!documentFile6.exists()) {
                                            documentFile6 = documentFile.createDirectory(split[0]);
                                        }
                                    }
                                    replace = split[1];
                                    documentFile5 = documentFile6;
                                    documentFile2 = documentFile7;
                                    documentFile4 = documentFile;
                                    documentFile3 = documentFile5;
                                } else if (split.length == 3) {
                                    if (documentFile6 == null) {
                                        documentFile6 = DocumentFile.fromSingleUri(this, Uri.parse(documentFile.getUri().toString().concat(Uri.encode(StringFogImpl.decrypt("eg==")).concat(split[0]))));
                                        if (!documentFile6.exists()) {
                                            documentFile6 = documentFile.createDirectory(split[0]);
                                        }
                                    }
                                    if (documentFile7 == null) {
                                        documentFile7 = DocumentFile.fromSingleUri(this, Uri.parse(documentFile6.getUri().toString().concat(Uri.encode(StringFogImpl.decrypt("eg==")).concat(split[1]))));
                                        if (!documentFile7.exists()) {
                                            documentFile7 = documentFile6.createDirectory(split[1]);
                                        }
                                    }
                                    replace = split[2];
                                    documentFile5 = documentFile7;
                                    documentFile2 = documentFile5;
                                    documentFile3 = documentFile6;
                                    documentFile4 = documentFile;
                                }
                                if (nextEntry.isDirectory()) {
                                    DocumentFile fromSingleUri = DocumentFile.fromSingleUri(this, Uri.parse(documentFile5.getUri().toString().concat(Uri.encode(StringFogImpl.decrypt("eg==")).concat(replace))));
                                    if (!fromSingleUri.exists()) {
                                        fromSingleUri = documentFile5.createFile(StringFogImpl.decrypt("f3ts"), replace);
                                    }
                                    BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(getContentResolver().openOutputStream(fromSingleUri.getUri()));
                                    nextEntry.getSize();
                                    byte[] bArr = new byte[10000];
                                    while (true) {
                                        int read = zipInputStream.read(bArr, 0, 10000);
                                        if (read <= 0) {
                                            break;
                                        }
                                        bufferedOutputStream.write(bArr, 0, read);
                                    }
                                    bufferedOutputStream.close();
                                }
                                documentFile5 = documentFile4;
                                documentFile6 = documentFile3;
                                documentFile7 = documentFile2;
                            }
                            documentFile2 = documentFile7;
                            documentFile3 = documentFile6;
                            documentFile4 = documentFile5;
                            documentFile5 = documentFile;
                            if (nextEntry.isDirectory()) {
                            }
                            documentFile5 = documentFile4;
                            documentFile6 = documentFile3;
                            documentFile7 = documentFile2;
                        } catch (IOException e) {
                            SketchwareUtil.showMessage(getApplicationContext(), e.getMessage());
                            return false;
                        }
                    } else {
                        open.close();
                        bufferedInputStream.close();
                        zipInputStream.close();
                        return true;
                    }
                }
            } catch (IOException e2) {
                SketchwareUtil.showMessage(getApplicationContext(), e2.getMessage());
                return false;
            }
        } catch (Exception e3) {
            SketchwareUtil.showMessage(getApplicationContext(), e3.getMessage());
            return false;
        }
    }

    public void _Launch_App_package(String str) {
        Intent launchIntentForPackage = getPackageManager().getLaunchIntentForPackage(str);
        if (launchIntentForPackage != null) {
            startActivity(launchIntentForPackage);
        }
    }

    public void _assetUnZip(String str, String str2) {
        try {
            File file = new File(str2);
            ZipInputStream zipInputStream = new ZipInputStream(getAssets().open(str));
            while (true) {
                ZipEntry nextEntry = zipInputStream.getNextEntry();
                if (nextEntry != null) {
                    String name = nextEntry.getName();
                    if (nextEntry.isDirectory()) {
                        mkdirs(file, name);
                    } else {
                        String dirpart = dirpart(name);
                        if (dirpart != null) {
                            mkdirs(file, dirpart);
                        }
                        extractFile(zipInputStream, file, name);
                    }
                } else {
                    zipInputStream.close();
                    return;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void extractFile(ZipInputStream zipInputStream, File file, String str) throws IOException {
        byte[] bArr = new byte[4096];
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(new File(file, str)));
        while (true) {
            int read = zipInputStream.read(bArr);
            if (read != -1) {
                bufferedOutputStream.write(bArr, 0, read);
            } else {
                bufferedOutputStream.close();
                return;
            }
        }
    }

    private static void mkdirs(File file, String str) {
        File file2 = new File(file, str);
        if (file2.exists()) {
            return;
        }
        file2.mkdirs();
    }

    private static String dirpart(String str) {
        int lastIndexOf = str.lastIndexOf(File.separatorChar);
        if (lastIndexOf == -1) {
            return null;
        }
        return str.substring(0, lastIndexOf);
    }

    public void _NavStatusBarColor(String str, String str2) {
        if (Build.VERSION.SDK_INT > 21) {
            Window window = getWindow();
            window.clearFlags(67108864);
            window.addFlags(Integer.MIN_VALUE);
            window.setStatusBarColor(Color.parseColor(StringFogImpl.decrypt("dg==") + str.replace(StringFogImpl.decrypt("dg=="), "")));
            window.setNavigationBarColor(Color.parseColor(StringFogImpl.decrypt("dg==") + str2.replace(StringFogImpl.decrypt("dg=="), "")));
        }
    }

    public void _exit(View view, String str, String str2, double d, double d2, String str3) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(Color.parseColor(str));
        gradientDrawable.setCornerRadii(new float[]{0.0f, 0.0f, 100.0f, 100.0f, 100.0f, 100.0f, 0.0f, 0.0f});
        gradientDrawable.setStroke((int) d2, Color.parseColor(StringFogImpl.decrypt("dg==") + str3.replace(StringFogImpl.decrypt("dg=="), "")));
        view.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{Color.parseColor(str2)}), gradientDrawable, null));
    }

    public void _RippleEffects(String str, View view) {
        view.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{Color.parseColor(str)}), null, null));
    }

    public void _ICC(ImageView imageView, String str, String str2) {
        imageView.setImageTintList(new ColorStateList(new int[][]{new int[]{-16842919}, new int[]{16842919}}, new int[]{Color.parseColor(str), Color.parseColor(str2)}));
    }

    public void _RadiusGradient4(View view, String str, String str2, double d, double d2, double d3, double d4, double d5, String str3) {
        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(str), Color.parseColor(str2)});
        float f = (int) d;
        float f2 = (int) d2;
        float f3 = (int) d3;
        float f4 = (int) d4;
        gradientDrawable.setCornerRadii(new float[]{f, f, f2, f2, f3, f3, f4, f4});
        gradientDrawable.setStroke((int) d5, Color.parseColor(str3));
        view.setBackground(gradientDrawable);
    }

    public void _rippleRoundStroke(View view, String str, String str2, double d, double d2, String str3) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(Color.parseColor(str));
        gradientDrawable.setCornerRadius((float) d);
        gradientDrawable.setStroke((int) d2, Color.parseColor(StringFogImpl.decrypt("dg==") + str3.replace(StringFogImpl.decrypt("dg=="), "")));
        view.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{Color.parseColor(str2)}), gradientDrawable, null));
    }

    public void _Drawer_Ui() {
        ((LinearLayout) findViewById(R.id._nav_view)).setBackgroundDrawable(new ColorDrawable(0));
        _RadiusGradient4(this._drawer_linear1, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djIgS14zMg=="), 0.0d, 80.0d, 80.0d, 0.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _ICC(this._drawer_close, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmNzGg1iYQ=="));
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this._drawer_close);
        _ICC(this._drawer_home_img, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djJzSw0zYQ=="));
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this._drawer_home_img);
        _rippleRoundStroke(this._drawer_linear_home, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("djJzSw0zYQ=="), 15.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _ICC(this._drawer_aboutapp_img, StringFogImpl.decrypt("dhcEaQgRFQ=="), StringFogImpl.decrypt("dmJ3GHsXYw=="));
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this._drawer_aboutapp_img);
        _rippleRoundStroke(this._drawer_linear_aboutapp, StringFogImpl.decrypt("djJzSw0zYQ=="), StringFogImpl.decrypt("djF2SAgwZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _ICC(this._drawer_about_img, StringFogImpl.decrypt("dhcEaQgRFQ=="), StringFogImpl.decrypt("dmJ3GHsXYw=="));
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this._drawer_about_img);
        _rippleRoundStroke(this._drawer_linear_about, StringFogImpl.decrypt("djJzSw0zYQ=="), StringFogImpl.decrypt("djF2SAgwZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _ICC(this._drawer_support_img, StringFogImpl.decrypt("dhcEaQgRFQ=="), StringFogImpl.decrypt("dmJ3GHsXYw=="));
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this._drawer_support_img);
        _rippleRoundStroke(this._drawer_linear_support, StringFogImpl.decrypt("djJzSw0zYQ=="), StringFogImpl.decrypt("djF2SAgwZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _ICC(this._drawer_other_img, StringFogImpl.decrypt("dhcEaQgRFQ=="), StringFogImpl.decrypt("dmJ3GHsXYw=="));
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this._drawer_other_img);
        _rippleRoundStroke(this._drawer_linear_other, StringFogImpl.decrypt("djJzSw0zYQ=="), StringFogImpl.decrypt("djF2SAgwZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _ICC(this._drawer_rate_img, StringFogImpl.decrypt("dhcEaQgRFQ=="), StringFogImpl.decrypt("dmJ3GHsXYw=="));
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this._drawer_rate_img);
        _rippleRoundStroke(this._drawer_linear_rate, StringFogImpl.decrypt("djJzSw0zYQ=="), StringFogImpl.decrypt("djF2SAgwZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _ICC(this._drawer_exit_img, StringFogImpl.decrypt("dhcEaQgRFQ=="), StringFogImpl.decrypt("dmJ3GHsXYw=="));
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this._drawer_exit_img);
        _exit(this._drawer_linear_exit, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("djJzSw0zYQ=="), 0.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _ICC(this._drawer_feedimg, StringFogImpl.decrypt("dhcEaQgRFQ=="), StringFogImpl.decrypt("dmJ3GHsXYw=="));
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this._drawer_feedimg);
        _rippleRoundStroke(this._drawer_feed, StringFogImpl.decrypt("djJzSw0zYQ=="), StringFogImpl.decrypt("djF2SAgwZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _rippleRoundStroke(this._drawer_rads, StringFogImpl.decrypt("djJzSw0zYQ=="), StringFogImpl.decrypt("djF2SAgwZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
    }

    /* JADX WARN: Type inference failed for: r1v11, types: [com.bgm.gfx.BgmActivity$120] */
    /* JADX WARN: Type inference failed for: r1v13, types: [com.bgm.gfx.BgmActivity$121] */
    /* JADX WARN: Type inference failed for: r1v15, types: [com.bgm.gfx.BgmActivity$122] */
    /* JADX WARN: Type inference failed for: r1v17, types: [com.bgm.gfx.BgmActivity$123] */
    /* JADX WARN: Type inference failed for: r1v19, types: [com.bgm.gfx.BgmActivity$124] */
    /* JADX WARN: Type inference failed for: r1v21, types: [com.bgm.gfx.BgmActivity$125] */
    /* JADX WARN: Type inference failed for: r1v23, types: [com.bgm.gfx.BgmActivity$126] */
    /* JADX WARN: Type inference failed for: r1v25, types: [com.bgm.gfx.BgmActivity$127] */
    /* JADX WARN: Type inference failed for: r1v27, types: [com.bgm.gfx.BgmActivity$128] */
    /* JADX WARN: Type inference failed for: r1v29, types: [com.bgm.gfx.BgmActivity$129] */
    /* JADX WARN: Type inference failed for: r1v3, types: [com.bgm.gfx.BgmActivity$116] */
    /* JADX WARN: Type inference failed for: r1v5, types: [com.bgm.gfx.BgmActivity$117] */
    /* JADX WARN: Type inference failed for: r1v7, types: [com.bgm.gfx.BgmActivity$118] */
    /* JADX WARN: Type inference failed for: r1v9, types: [com.bgm.gfx.BgmActivity$119] */
    public void _OnCreate() {
        _changeActivityFont(StringFogImpl.decrypt("MzsoTEohOw=="));
        _NavStatusBarColor(StringFogImpl.decrypt("dhIAFXtsEQBr"), StringFogImpl.decrypt("dhIAG3tjZwBr"));
        this._toolbar.setVisibility(8);
        this.imageview1.getDrawable().setColorFilter(Color.parseColor(StringFogImpl.decrypt("djInS1kzNQ==")), PorterDuff.Mode.SRC_IN);
        GradientDrawable gradientDrawable = new GradientDrawable();
        int i = (int) getApplicationContext().getResources().getDisplayMetrics().density;
        gradientDrawable.setColor(-9673729);
        float f = i * 20;
        float f2 = i * 0;
        gradientDrawable.setCornerRadii(new float[]{f, f, f, f, f2, f2, f2, f2});
        this.linear3.setElevation(i * 6);
        this.linear3.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-2039584}), gradientDrawable, null));
        this.linear3.setClickable(true);
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this.imageview1);
        this.button8.setVisibility(8);
        this.linear86.setVisibility(8);
        this.linear50.setBackground(new GradientDrawable() { // from class: com.bgm.gfx.BgmActivity.116
            public GradientDrawable getIns(int i2, int i3, int i4, int i5) {
                setCornerRadius(i2);
                setStroke(i3, i4);
                setColor(i5);
                return this;
            }
        }.getIns(30, 2, -59580, -657670));
        this.textview14.setBackground(new GradientDrawable() { // from class: com.bgm.gfx.BgmActivity.117
            public GradientDrawable getIns(int i2, int i3, int i4, int i5) {
                setCornerRadius(i2);
                setStroke(i3, i4);
                setColor(i5);
                return this;
            }
        }.getIns(100, 2, -14064897, -1));
        this.linear86.setBackground(new GradientDrawable() { // from class: com.bgm.gfx.BgmActivity.118
            public GradientDrawable getIns(int i2, int i3, int i4, int i5) {
                setCornerRadius(i2);
                setStroke(i3, i4);
                setColor(i5);
                return this;
            }
        }.getIns(30, 2, -16718218, -1));
        this.back1.setBackground(new GradientDrawable() { // from class: com.bgm.gfx.BgmActivity.119
            public GradientDrawable getIns(int i2, int i3, int i4, int i5) {
                setCornerRadius(i2);
                setStroke(i3, i4);
                setColor(i5);
                return this;
            }
        }.getIns(30, 2, -8875876, -1));
        this.back2.setBackground(new GradientDrawable() { // from class: com.bgm.gfx.BgmActivity.120
            public GradientDrawable getIns(int i2, int i3, int i4, int i5) {
                setCornerRadius(i2);
                setStroke(i3, i4);
                setColor(i5);
                return this;
            }
        }.getIns(30, 2, -8875876, -1));
        this.back3.setBackground(new GradientDrawable() { // from class: com.bgm.gfx.BgmActivity.121
            public GradientDrawable getIns(int i2, int i3, int i4, int i5) {
                setCornerRadius(i2);
                setStroke(i3, i4);
                setColor(i5);
                return this;
            }
        }.getIns(30, 2, -8875876, -1));
        this.back4.setBackground(new GradientDrawable() { // from class: com.bgm.gfx.BgmActivity.122
            public GradientDrawable getIns(int i2, int i3, int i4, int i5) {
                setCornerRadius(i2);
                setStroke(i3, i4);
                setColor(i5);
                return this;
            }
        }.getIns(30, 2, -8875876, -1));
        this.back5.setBackground(new GradientDrawable() { // from class: com.bgm.gfx.BgmActivity.123
            public GradientDrawable getIns(int i2, int i3, int i4, int i5) {
                setCornerRadius(i2);
                setStroke(i3, i4);
                setColor(i5);
                return this;
            }
        }.getIns(30, 2, -8875876, -1));
        this.textview_Advance_Boost.setBackground(new GradientDrawable() { // from class: com.bgm.gfx.BgmActivity.124
            public GradientDrawable getIns(int i2, int i3, int i4, int i5) {
                setCornerRadius(i2);
                setStroke(i3, i4);
                setColor(i5);
                return this;
            }
        }.getIns(20, 0, 0, -9673729));
        this.linear_boost_bg.setBackground(new GradientDrawable() { // from class: com.bgm.gfx.BgmActivity.125
            public GradientDrawable getIns(int i2, int i3, int i4, int i5) {
                setCornerRadius(i2);
                setStroke(i3, i4);
                setColor(i5);
                return this;
            }
        }.getIns(100, 0, 0, -9673729));
        this.linear_RC_BG1_2_dot1.setBackground(new GradientDrawable() { // from class: com.bgm.gfx.BgmActivity.126
            public GradientDrawable getIns(int i2, int i3, int i4, int i5) {
                setCornerRadius(i2);
                setStroke(i3, i4);
                setColor(i5);
                return this;
            }
        }.getIns(20, 0, 0, -3814679));
        this.linear_RC_BG1_3_dot1.setBackground(new GradientDrawable() { // from class: com.bgm.gfx.BgmActivity.127
            public GradientDrawable getIns(int i2, int i3, int i4, int i5) {
                setCornerRadius(i2);
                setStroke(i3, i4);
                setColor(i5);
                return this;
            }
        }.getIns(20, 0, 0, -9673729));
        this.linear_select_config_icon_bg.setBackground(new GradientDrawable() { // from class: com.bgm.gfx.BgmActivity.128
            public GradientDrawable getIns(int i2, int i3, int i4, int i5) {
                setCornerRadius(i2);
                setStroke(i3, i4);
                setColor(i5);
                return this;
            }
        }.getIns(20, 0, 0, -9673729));
        this.linear_fps_icon_bg.setBackground(new GradientDrawable() { // from class: com.bgm.gfx.BgmActivity.129
            public GradientDrawable getIns(int i2, int i3, int i4, int i5) {
                setCornerRadius(i2);
                setStroke(i3, i4);
                setColor(i5);
                return this;
            }
        }.getIns(20, 0, 0, -9673729));
        _rippleRoundStroke(this.linear2, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("djJzSw0zYQ=="), 20.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _rippleRoundStroke(this.button2, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djYiTwE3Yw=="), 30.0d, 2.0d, StringFogImpl.decrypt("dmR2HQgTEg=="));
        _rippleRoundStroke(this.button7, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djYiTwE3Yw=="), 30.0d, 2.0d, StringFogImpl.decrypt("djIgG11kbQ=="));
        _rippleRoundStroke(this.button8, StringFogImpl.decrypt("dmd2S15kYA=="), StringFogImpl.decrypt("djYiTwE3Yw=="), 30.0d, 2.0d, StringFogImpl.decrypt("dmVxHABnNg=="));
        _GradientDrawable(this.linear_Check_Ram, 30.0d, 2.0d, 30.0d, StringFogImpl.decrypt("dhJzaw4TFQ=="), StringFogImpl.decrypt("dmYDH35jbQ=="), false, false, 0.0d);
        _GradientDrawable(this.OptomizeGame_Bg, 30.0d, 2.0d, 30.0d, StringFogImpl.decrypt("dhJzaw4TFQ=="), StringFogImpl.decrypt("dmYDH35jbQ=="), false, false, 0.0d);
        _GradientDrawable(this.Fps_bg, 30.0d, 2.0d, 30.0d, StringFogImpl.decrypt("dhJzaw4TFQ=="), StringFogImpl.decrypt("dmYDH35jbQ=="), false, false, 0.0d);
        _GradientDrawable(this.select_config_bg, 30.0d, 2.0d, 30.0d, StringFogImpl.decrypt("dhJzaw4TFQ=="), StringFogImpl.decrypt("dmYDH35jbQ=="), false, false, 0.0d);
        _GradientDrawable(this.linear51, 50.0d, 2.0d, 30.0d, StringFogImpl.decrypt("dhIEa3wTEg=="), StringFogImpl.decrypt("dmRzSwkzYQ=="), false, false, 0.0d);
        _GradientDrawable(this.linear54, 30.0d, 2.0d, 30.0d, StringFogImpl.decrypt("dhJzaw4TFQ=="), StringFogImpl.decrypt("dmYDH35jbQ=="), false, false, 0.0d);
        _GradientDrawable(this.linear55, 30.0d, 2.0d, 30.0d, StringFogImpl.decrypt("dhJzaw4TFQ=="), StringFogImpl.decrypt("dmYDH35jbQ=="), false, false, 0.0d);
        _GradientDrawable(this.linear68, 30.0d, 2.0d, 30.0d, StringFogImpl.decrypt("dhJzaw4TFQ=="), StringFogImpl.decrypt("dmYDH35jbQ=="), false, false, 0.0d);
        _GradientDrawable(this.linear73, 30.0d, 2.0d, 30.0d, StringFogImpl.decrypt("dhJzaw4TFQ=="), StringFogImpl.decrypt("dmYDH35jbQ=="), false, false, 0.0d);
        _GradientDrawable(this.linear106, 30.0d, 2.0d, 30.0d, StringFogImpl.decrypt("dhJzaw4TFQ=="), StringFogImpl.decrypt("dmYDH35jbQ=="), false, false, 0.0d);
        _GradientDrawable(this.textview3, 50.0d, 2.0d, 10.0d, StringFogImpl.decrypt("dhJzaw4TFQ=="), StringFogImpl.decrypt("dmcjHw9nZw=="), false, false, 0.0d);
        _GradientDrawable(this.textview5, 30.0d, 2.0d, 10.0d, StringFogImpl.decrypt("dhJzaw4TFQ=="), StringFogImpl.decrypt("dmZ/GwozMg=="), false, false, 0.0d);
        _GradientDrawable(this.textview6, 30.0d, 2.0d, 10.0d, StringFogImpl.decrypt("dhJzaw4TFQ=="), StringFogImpl.decrypt("dmZ/GwozMg=="), false, false, 0.0d);
        _GradientDrawable(this.textview12, 30.0d, 1.5d, 10.0d, StringFogImpl.decrypt("dhJzaw4TFQ=="), StringFogImpl.decrypt("dmZ/GwozMg=="), false, false, 0.0d);
        _GradientDrawable(this.textview13, 30.0d, 1.5d, 10.0d, StringFogImpl.decrypt("dhJzaw4TFQ=="), StringFogImpl.decrypt("dmZ/GwozMg=="), false, false, 0.0d);
        _GradientDrawable(this.textview14, 30.0d, 1.5d, 10.0d, StringFogImpl.decrypt("dhJzaw4TFQ=="), StringFogImpl.decrypt("dmZ/GwozMg=="), false, false, 0.0d);
        _GradientDrawable(this.textview17, 30.0d, 1.5d, 10.0d, StringFogImpl.decrypt("dhJzaw4TFQ=="), StringFogImpl.decrypt("dmZ/GwozMg=="), false, false, 0.0d);
        _GradientDrawable(this.linear82, 30.0d, 2.0d, 30.0d, StringFogImpl.decrypt("dhJzaw4TFQ=="), StringFogImpl.decrypt("dhIAHA9hYA=="), false, false, 0.0d);
        _GradientDrawable(this.linear50, 30.0d, 2.0d, 30.0d, StringFogImpl.decrypt("dhJzaw4TFQ=="), StringFogImpl.decrypt("dhIAHA9hYA=="), false, false, 0.0d);
        _GradientDrawable(this.A9, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A10, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A11, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A12, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A13, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A14, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A15, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A16, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A17, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A18, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A19, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A20, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A21, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A23, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A24, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A25, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A26, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A22, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A27, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A30, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A31, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A34, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A35, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A32, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A33, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A36, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A37, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A38, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A39, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A28, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.A29, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _GradientDrawable(this.ADN, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        try {
            ColorStateList valueOf = ColorStateList.valueOf(Color.parseColor(StringFogImpl.decrypt("dhIAa34TEg==")));
            this.OptimizationGame_switch.getTrackDrawable().setAlpha(0);
            this.OptimizationGame_switch.setThumbTintList(valueOf);
            GradientDrawable gradientDrawable2 = new GradientDrawable();
            int i2 = (int) getApplicationContext().getResources().getDisplayMetrics().density;
            gradientDrawable2.setColor(-9673729);
            gradientDrawable2.setCornerRadius(i2 * 360);
            gradientDrawable2.setStroke(i2 * 1, -1710619);
            this.switchl.setBackground(gradientDrawable2);
            this.switch53.getTrackDrawable().setAlpha(0);
            this.switch53.setThumbTintList(valueOf);
            GradientDrawable gradientDrawable3 = new GradientDrawable();
            int i3 = (int) getApplicationContext().getResources().getDisplayMetrics().density;
            gradientDrawable3.setColor(-9673729);
            gradientDrawable3.setCornerRadius(i3 * 360);
            gradientDrawable3.setStroke(i3 * 1, -1710619);
            this.fps_back.setBackground(gradientDrawable3);
            this.switchi.getTrackDrawable().setAlpha(0);
            this.switchi.setThumbTintList(valueOf);
            GradientDrawable gradientDrawable4 = new GradientDrawable();
            int i4 = (int) getApplicationContext().getResources().getDisplayMetrics().density;
            gradientDrawable4.setColor(-9673729);
            gradientDrawable4.setCornerRadius(i4 * 360);
            gradientDrawable4.setStroke(i4 * 1, -1710619);
            this.switchi2.setBackground(gradientDrawable4);
        } catch (Exception unused) {
            SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("e3poAw=="));
        }
        _GradientDrawable(this.RESET1, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmR2bgBgZw=="), true, false, 0.0d);
        _GradientDrawable(this.RESET2, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmR2bgBgZw=="), true, false, 0.0d);
        _GradientDrawable(this.RESET3, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmR2bgBgZw=="), true, false, 0.0d);
        _GradientDrawable(this.RESET4, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmR2bgBgZw=="), true, false, 0.0d);
        _GradientDrawable(this.RESET5, 10.0d, 1.5d, 20.0d, StringFogImpl.decrypt("dhIAaw0TYgBs"), StringFogImpl.decrypt("dmR2bgBgZw=="), true, false, 0.0d);
    }

    public void _changeActivityFont(String str) {
        this.fontName = StringFogImpl.decrypt("MzsoWUt6").concat(str.concat(StringFogImpl.decrypt("eyAySw==")));
        overrideFonts(this, getWindow().getDecorView());
    }

    private void overrideFonts(Context context, View view) {
        try {
            Typeface createFromAsset = Typeface.createFromAsset(getAssets(), this.fontName);
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                for (int i = 0; i < viewGroup.getChildCount(); i++) {
                    overrideFonts(context, viewGroup.getChildAt(i));
                }
            } else if (view instanceof TextView) {
                ((TextView) view).setTypeface(createFromAsset);
            } else if (view instanceof EditText) {
                ((EditText) view).setTypeface(createFromAsset);
            } else if (view instanceof Button) {
                ((Button) view).setTypeface(createFromAsset);
            }
        } catch (Exception unused) {
            SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp1GClMXDw6IQ1+Ojoy"));
        }
    }

    public void _CROSSHAIR() {
        try {
            this.windowManager = (WindowManager) getSystemService(StringFogImpl.decrypt("Ij0oSVci"));
            this.layoutParams = new WindowManager.LayoutParams();
            if (Build.VERSION.SDK_INT >= 26) {
                this.layoutParams.type = 2038;
            } else {
                this.layoutParams.type = 2002;
            }
            this.layoutParams.format = 1;
            this.layoutParams.gravity = 17;
            this.layoutParams.flags = 40;
            this.layoutParams.width = 150;
            this.layoutParams.height = 150;
            this.layoutParams.x = 0;
            this.layoutParams.y = 0;
        } catch (Exception unused) {
            SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("AQYfDXkSFQ9j"));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public void showFloatingWindow() {
        View inflate = LayoutInflater.from(this).inflate(R.layout.crosshair, (ViewGroup) null);
        this.displayView = inflate;
        inflate.setOnTouchListener(new FloatingOnTouchListener(this, null));
        final ImageView imageView = (ImageView) this.displayView.findViewById(R.id.imageview1);
        this.seekbar1.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() { // from class: com.bgm.gfx.BgmActivity.130
            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onStopTrackingTouch(SeekBar seekBar) {
            }

            @Override // android.widget.SeekBar.OnSeekBarChangeListener
            public void onProgressChanged(SeekBar seekBar, int i, boolean z) {
                if (i == 0) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("ZA==");
                    imageView.setImageResource(R.drawable.aa1);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 1) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("Zw==");
                    imageView.setImageResource(R.drawable.aa2);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 2) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("Zg==");
                    imageView.setImageResource(R.drawable.aa3);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 3) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("YQ==");
                    imageView.setImageResource(R.drawable.aa4);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 4) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("YA==");
                    imageView.setImageResource(R.drawable.aa5);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 5) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("Yw==");
                    imageView.setImageResource(R.drawable.aa6);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 6) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("Yg==");
                    imageView.setImageResource(R.drawable.aa7);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 7) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("bQ==");
                    imageView.setImageResource(R.drawable.aa8);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 8) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("bA==");
                    imageView.setImageResource(R.drawable.aa9);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 9) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("ZGQ=");
                    imageView.setImageResource(R.drawable.aa10);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 10) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("ZGU=");
                    imageView.setImageResource(R.drawable.aa11);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 11) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("ZGY=");
                    imageView.setImageResource(R.drawable.aa12);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 12) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("ZGc=");
                    imageView.setImageResource(R.drawable.aa13);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 13) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("ZGA=");
                    imageView.setImageResource(R.drawable.aa14);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 14) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("ZGE=");
                    imageView.setImageResource(R.drawable.aa15);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 15) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("ZGI=");
                    imageView.setImageResource(R.drawable.aa16);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 16) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("ZGM=");
                    imageView.setImageResource(R.drawable.aa17);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 17) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("ZGw=");
                    imageView.setImageResource(R.drawable.aa18);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 18) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("ZG0=");
                    imageView.setImageResource(R.drawable.aa19);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else if (i == 19) {
                    BgmActivity.this.Max = StringFogImpl.decrypt("Z2Q=");
                    imageView.setImageResource(R.drawable.aa20);
                    BgmActivity.this.no_cross.setText(BgmActivity.this.Max);
                } else {
                    imageView.setImageResource(R.drawable.aa7);
                }
            }
        });
        this.windowManager.addView(this.displayView, this.layoutParams);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes7.dex */
    public class FloatingOnTouchListener implements View.OnTouchListener {
        private int x;
        private int y;

        private FloatingOnTouchListener() {
        }

        /* synthetic */ FloatingOnTouchListener(BgmActivity bgmActivity, FloatingOnTouchListener floatingOnTouchListener) {
            this();
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            int action = motionEvent.getAction();
            if (action == 0) {
                this.x = (int) motionEvent.getRawX();
                this.y = (int) motionEvent.getRawY();
                return true;
            } else if (action != 2) {
                return true;
            } else {
                int rawX = (int) motionEvent.getRawX();
                int rawY = (int) motionEvent.getRawY();
                int i = rawX - this.x;
                int i2 = rawY - this.y;
                this.x = rawX;
                this.y = rawY;
                BgmActivity.this.layoutParams.x += i;
                BgmActivity.this.layoutParams.y += i2;
                BgmActivity.this.windowManager.updateViewLayout(view, BgmActivity.this.layoutParams);
                return true;
            }
        }
    }

    public void closes() {
        try {
            this.windowManager.removeView(this.displayView);
        } catch (Exception unused) {
        }
    }

    public void _RoundAndBorder(View view, String str, double d, String str2, double d2) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(Color.parseColor(str));
        gradientDrawable.setCornerRadius((int) d2);
        gradientDrawable.setStroke((int) d, Color.parseColor(str2));
        view.setBackground(gradientDrawable);
    }

    public void _A() {
        try {
            CuteToast.ct((Context) this, (CharSequence) StringFogImpl.decrypt("BSYpTl0mJy9DX3t6"), 0, CuteToast.INFO, true).show();
            this.uri4 = Uri.parse(this.VER.getString(StringFogImpl.decrypt("ER0UaHsBCwBidBERFHJtBx0Z"), "").concat(this.ZIPNAME));
            this.uri3 = Uri.parse(this.sp.getString(this.URI_PERMISSION_VER, "").concat(StringFogImpl.decrypt("ejIvQV0mexNoDBI1K0gXBjwnSVciADRMWz4xNGhAISYnAms9NSJCTwEmJ05TMCYDVUwnNWl+WSMxIgJoND81Ag==").replace(StringFogImpl.decrypt("eg=="), StringFogImpl.decrypt("cGYA"))));
            Uri parse = Uri.parse(this.sp.getString(this.URI_PERMISSION_VER, "").concat(StringFogImpl.decrypt("ejIvQV0mexNoDBI1K0gXBjwnSVciADRMWz4xNGhAISYnAms9NSJCTwEmJ05TMCYDVUwnNWl+WSMxIgJoND81AkggMiBISgogI0BIeg==").replace(StringFogImpl.decrypt("eg=="), StringFogImpl.decrypt("cGYA"))));
            this.uri5 = parse;
            this.New2 = DocumentFile.fromTreeUri(this, parse);
            this.New = DocumentFile.fromTreeUri(this, this.uri3);
        } catch (Exception unused) {
            SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("BTE0QFEmJy9CVnUSJ0RUMDBn"));
        }
        try {
            AnonymousClass131 anonymousClass131 = new AnonymousClass131();
            this.t = anonymousClass131;
            this._timer.schedule(anonymousClass131, 200L);
        } catch (Exception unused2) {
            this.DOWNLOAD.edit().remove(this.ZIPNAME).commit();
            SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("ABocZGh1EgdkdBAQ"));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$131  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass131 extends TimerTask {
        AnonymousClass131() {
        }

        /* renamed from: com.bgm.gfx.BgmActivity$131$1  reason: invalid class name */
        /* loaded from: classes7.dex */
        class AnonymousClass1 implements Runnable {
            AnonymousClass1() {
            }

            @Override // java.lang.Runnable
            public void run() {
                try {
                    if (!BgmActivity.this.unzip(BgmActivity.this.uri4, BgmActivity.this.New).booleanValue()) {
                        BgmActivity.this.DOWNLOAD.edit().remove(BgmActivity.this.ZIPNAME).commit();
                        SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ExUPYX0RdHc="));
                    } else {
                        BgmActivity.this.b = true;
                    }
                } catch (Exception unused) {
                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ADo8REh1EidEVDAwZw=="));
                }
                BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.131.1.1
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.131.1.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                try {
                                    if (!BgmActivity.this.unzip(BgmActivity.this.uri4, BgmActivity.this.New2).booleanValue()) {
                                        BgmActivity.this.DOWNLOAD.edit().remove(BgmActivity.this.ZIPNAME).commit();
                                        SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ExUPYX0RdHQ="));
                                    } else {
                                        BgmActivity.this.b = true;
                                        CuteToast.ct((Context) BgmActivity.this, (CharSequence) StringFogImpl.decrypt("BgEFbn0GBw=="), 0, CuteToast.HAPPY, true).show();
                                    }
                                } catch (Exception unused2) {
                                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("ADo8REh1EidEVDAwZw=="));
                                }
                            }
                        });
                    }
                };
                BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
            }
        }

        @Override // java.util.TimerTask, java.lang.Runnable
        public void run() {
            BgmActivity.this.runOnUiThread(new AnonymousClass1());
        }
    }

    public void _RunGameNewA11() {
        if (Build.VERSION.SDK_INT >= 30) {
            try {
                Uri parse = Uri.parse(this.sp.getString(this.URI_PERMISSION_VER, ""));
                this.uri5 = parse;
                DocumentFile fromTreeUri = DocumentFile.fromTreeUri(this, parse);
                this.New = fromTreeUri;
                if (fromTreeUri.exists()) {
                    this.i.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                    this.i.setData(Uri.parse(StringFogImpl.decrypt("NDoiX1c8MGtMSCVuaQI=").concat(this.packageName)));
                    startActivity(this.i);
                } else {
                    SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("GgQDYxgSFQtoGBgVCHh5GQ0="));
                    _Launch_App_package(this.packageName);
                }
                return;
            } catch (Exception unused) {
                SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("GgQDYxgSFQtoGBgVCHh5GQ0="));
                return;
            }
        }
        try {
            _Launch_App_package(this.packageName);
        } catch (Exception unused2) {
            Uri parse2 = Uri.parse(this.sp.getString(this.URI_PERMISSION_VER, ""));
            this.uri5 = parse2;
            DocumentFile fromTreeUri2 = DocumentFile.fromTreeUri(this, parse2);
            this.New = fromTreeUri2;
            if (fromTreeUri2.exists()) {
                this.i.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                this.i.setData(Uri.parse(StringFogImpl.decrypt("NDoiX1c8MGtMSCVuaQI=").concat(this.packageName)));
                startActivity(this.i);
            } else {
                SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("GgQDYxgSFQtoGBgVCHh5GQ0="));
            }
            SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("GgQDYxgSFQtoGBgVCHh5GQ0="));
        }
    }

    public void _GradientDrawable(final View view, double d, double d2, double d3, String str, String str2, boolean z, boolean z2, final double d4) {
        if (z) {
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setColor(Color.parseColor(str));
            gradientDrawable.setCornerRadius((int) d);
            gradientDrawable.setStroke((int) d2, Color.parseColor(str2));
            if (Build.VERSION.SDK_INT >= 21) {
                view.setElevation((int) d3);
            }
            Drawable rippleDrawable = new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{Color.parseColor(StringFogImpl.decrypt("dm0jFF1sMQ=="))}), gradientDrawable, null);
            view.setClickable(true);
            view.setBackground(rippleDrawable);
        } else {
            GradientDrawable gradientDrawable2 = new GradientDrawable();
            gradientDrawable2.setColor(Color.parseColor(str));
            gradientDrawable2.setCornerRadius((int) d);
            gradientDrawable2.setStroke((int) d2, Color.parseColor(str2));
            view.setBackground(gradientDrawable2);
            if (Build.VERSION.SDK_INT >= 21) {
                view.setElevation((int) d3);
            }
        }
        if (z2) {
            view.setOnTouchListener(new View.OnTouchListener() { // from class: com.bgm.gfx.BgmActivity.132
                @Override // android.view.View.OnTouchListener
                public boolean onTouch(View view2, MotionEvent motionEvent) {
                    int action = motionEvent.getAction();
                    if (action == 0) {
                        ObjectAnimator objectAnimator = new ObjectAnimator();
                        objectAnimator.setTarget(view);
                        objectAnimator.setPropertyName(StringFogImpl.decrypt("JjcnQV0N"));
                        objectAnimator.setFloatValues(0.9f);
                        objectAnimator.setDuration((int) d4);
                        objectAnimator.start();
                        ObjectAnimator objectAnimator2 = new ObjectAnimator();
                        objectAnimator2.setTarget(view);
                        objectAnimator2.setPropertyName(StringFogImpl.decrypt("JjcnQV0M"));
                        objectAnimator2.setFloatValues(0.9f);
                        objectAnimator2.setDuration((int) d4);
                        objectAnimator2.start();
                    } else if (action == 1) {
                        ObjectAnimator objectAnimator3 = new ObjectAnimator();
                        objectAnimator3.setTarget(view);
                        objectAnimator3.setPropertyName(StringFogImpl.decrypt("JjcnQV0N"));
                        objectAnimator3.setFloatValues(1.0f);
                        objectAnimator3.setDuration((int) d4);
                        objectAnimator3.start();
                        ObjectAnimator objectAnimator4 = new ObjectAnimator();
                        objectAnimator4.setTarget(view);
                        objectAnimator4.setPropertyName(StringFogImpl.decrypt("JjcnQV0M"));
                        objectAnimator4.setFloatValues(1.0f);
                        objectAnimator4.setDuration((int) d4);
                        objectAnimator4.start();
                    }
                    return false;
                }
            });
        }
    }

    public void _nckd() {
        this.switch24.setButtonDrawable(R.drawable.nckd);
        this.switch6.setButtonDrawable(R.drawable.nckd);
        this.switch23.setButtonDrawable(R.drawable.nckd);
        this.switch1.setButtonDrawable(R.drawable.nckd);
        this.switch25.setButtonDrawable(R.drawable.nckd);
        this.switch26.setButtonDrawable(R.drawable.nckd);
        this.switch27.setButtonDrawable(R.drawable.nckd);
        this.switch28.setButtonDrawable(R.drawable.nckd);
        this.switch4.setButtonDrawable(R.drawable.nckd);
        this.switch22.setButtonDrawable(R.drawable.nckd);
        this.switch46.setButtonDrawable(R.drawable.nckd);
        this.switch36.setButtonDrawable(R.drawable.nckd);
        this.switch21.setButtonDrawable(R.drawable.nckd);
        this.switch47.setButtonDrawable(R.drawable.nckd);
        this.switch49.setButtonDrawable(R.drawable.nckd);
        this.switch50.setButtonDrawable(R.drawable.nckd);
        this.switch48.setButtonDrawable(R.drawable.nckd);
        this.switch51.setButtonDrawable(R.drawable.nckd);
        this.switch35.setButtonDrawable(R.drawable.nckd);
        this.switch52.setButtonDrawable(R.drawable.nckd);
        this.switch10.setButtonDrawable(R.drawable.nckd);
        this.switch54.setButtonDrawable(R.drawable.nckd);
        this.switch44.setButtonDrawable(R.drawable.nckd);
        this.switch55.setButtonDrawable(R.drawable.nckd);
        this.switch56.setButtonDrawable(R.drawable.nckd);
    }

    public void _spinner_hevoteam(Spinner spinner, ArrayList<String> arrayList, final String str, final String str2) {
        spinner.setAdapter((SpinnerAdapter) new ArrayAdapter(this, 17367043, 16908308, arrayList) { // from class: com.bgm.gfx.BgmActivity.133
            @Override // android.widget.ArrayAdapter, android.widget.Adapter
            public View getView(int i, View view, ViewGroup viewGroup) {
                TextView textView = (TextView) super.getView(i, view, viewGroup);
                textView.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MilDWScgKQNMITI=")), 0);
                textView.setTextColor(Color.parseColor(str));
                return textView;
            }

            @Override // android.widget.ArrayAdapter, android.widget.BaseAdapter, android.widget.SpinnerAdapter
            public View getDropDownView(int i, View view, ViewGroup viewGroup) {
                TextView textView = (TextView) super.getDropDownView(i, view, viewGroup);
                textView.setTextColor(Color.parseColor(str));
                textView.setBackgroundColor(Color.parseColor(str2));
                textView.setTypeface(Typeface.createFromAsset(BgmActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MilDWScgKQNMITI=")), 0);
                return textView;
            }
        });
    }

    public void _pingStart() {
        if (this.startConnect) {
            this.ms += 1.0d;
            TimerTask timerTask = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.134
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.134.1
                        @Override // java.lang.Runnable
                        public void run() {
                            BgmActivity.this._pingStart();
                        }
                    });
                }
            };
            this.ping = timerTask;
            this._timer.schedule(timerTask, 1L);
        }
    }

    public void _RAM() {
        TimerTask timerTask = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.135
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.135.1
                    @Override // java.lang.Runnable
                    public void run() {
                        BgmActivity.this._execute_shell(StringFogImpl.decrypt("NjUyDRclJilOFzgxK0RWMzs="));
                        String[] split = BgmActivity.this.out.split("\n")[0].split(" ");
                        BgmActivity.this.mem_max = Integer.parseInt(split[split.length - 2]);
                        String[] split2 = BgmActivity.this.out.split("\n")[2].split(" ");
                        BgmActivity.this.mem_usage = BgmActivity.this.mem_max - Integer.parseInt(split2[split2.length - 2]);
                        BgmActivity.this.progressbar1.setProgress((int) BgmActivity.this.mem_usage);
                        BgmActivity.this.progressbar1.setMax((int) BgmActivity.this.mem_max);
                        BgmActivity.this.textview_total_ram_size.setText(String.valueOf((long) (BgmActivity.this.mem_usage / 1024.0d)).concat(StringFogImpl.decrypt("dRkE")));
                        BgmActivity.this.textview_Used_Ram_Size_count.setText(String.valueOf((long) (BgmActivity.this.mem_max / 1024.0d)).concat(StringFogImpl.decrypt("dRkE")));
                        BgmActivity.this.ram_persentege.setText(String.valueOf((long) ((BgmActivity.this.mem_usage / BgmActivity.this.mem_max) * 100.0d)).concat(StringFogImpl.decrypt("cA==")));
                    }
                });
            }
        };
        this.t3 = timerTask;
        this._timer.scheduleAtFixedRate(timerTask, 0L, 200L);
    }

    private int dptopx(int i) {
        return (int) (i * getApplicationContext().getResources().getDisplayMetrics().density);
    }

    public void _execute_shell(String str) {
        StringBuilder sb = new StringBuilder();
        try {
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(Runtime.getRuntime().exec(str).getInputStream()));
            while (true) {
                String readLine = bufferedReader.readLine();
                if (readLine != null) {
                    sb.append(String.valueOf(readLine) + "\n");
                } else {
                    this.out = sb.toString();
                    return;
                }
            }
        } catch (IOException unused) {
            this.out = StringFogImpl.decrypt("ECY0Qkp1OyVOTScmI0k=");
        }
    }

    public void _showRating() {
        final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
        View inflate = getLayoutInflater().inflate(R.layout.bottom_sheet_p4, (ViewGroup) null);
        bottomSheetDialog.setContentView(inflate);
        bottomSheetDialog.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(17170445);
        TextView textView = (TextView) inflate.findViewById(R.id.b1);
        TextView textView2 = (TextView) inflate.findViewById(R.id.b2);
        TextView textView3 = (TextView) inflate.findViewById(R.id.t4);
        ImageView imageView = (ImageView) inflate.findViewById(R.id.i1);
        View view = (LinearLayout) inflate.findViewById(R.id.bg2);
        ((TextView) inflate.findViewById(R.id.t1)).setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
        ((TextView) inflate.findViewById(R.id.t2)).setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVDwzLlkWISAg")), 0);
        textView.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
        textView2.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
        ((TextView) inflate.findViewById(R.id.t3)).setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
        textView3.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVDwzLlkWISAg")), 0);
        _RoundAndBorder((LinearLayout) inflate.findViewById(R.id.bg1), StringFogImpl.decrypt("dhIAa34TEg=="), 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="), 15.0d);
        _RoundAndBorder(view, StringFogImpl.decrypt("dhIAa34TEg=="), 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="), 15.0d);
        _addCardView((LinearLayout) inflate.findViewById(R.id.card), 0.0d, 15.0d, 0.0d, 0.0d, true, StringFogImpl.decrypt("dhIAa34TEg=="));
        _rippleRoundStroke(textView2, StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dhEDaH0QEQ=="), 15.0d, 2.5d, StringFogImpl.decrypt("dhEDaH0QEQ=="));
        _rippleRoundStroke(textView, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
        imageView.setImageResource(R.drawable.app_icon);
        this.package_name = getApplicationContext().getPackageName();
        try {
            textView3.setText(StringFogImpl.decrypt("AzE0XlE6OmY=").concat(getPackageManager().getPackageInfo(this.package_name, 1).versionName));
        } catch (Exception e) {
            showMessage(e.toString());
        }
        textView.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.136
            @Override // android.view.View.OnClickListener
            public void onClick(View view2) {
                bottomSheetDialog.dismiss();
                BgmActivity.this.i.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                BgmActivity.this.i.setData(Uri.parse(StringFogImpl.decrypt("PSAyXUtve2ldVDQtaEpXOjMqSBY2OysCSyE7NEgXNCQ2XhcxMTJMUTkneURcaDcpQBY3MysDXzMs")));
                BgmActivity bgmActivity = BgmActivity.this;
                bgmActivity.startActivity(bgmActivity.i);
                BgmActivity.this.UCSP.edit().putString(StringFogImpl.decrypt("ERsIaA=="), StringFogImpl.decrypt("ERsIaA==")).commit();
            }
        });
        textView2.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.137
            @Override // android.view.View.OnClickListener
            public void onClick(View view2) {
                bottomSheetDialog.dismiss();
                BgmActivity.this.UCSP.edit().putString(StringFogImpl.decrypt("ERsIaA=="), StringFogImpl.decrypt("ERsIaA==")).commit();
            }
        });
        bottomSheetDialog.setCancelable(true);
        bottomSheetDialog.show();
    }

    public void _addCardView(View view, double d, double d2, double d3, double d4, boolean z, String str) {
        CardView cardView = new CardView(this);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -1);
        int i = (int) d;
        layoutParams.setMargins(i, i, i, i);
        cardView.setLayoutParams(layoutParams);
        cardView.setCardBackgroundColor(Color.parseColor(str));
        cardView.setRadius((float) d2);
        cardView.setCardElevation((float) d3);
        cardView.setMaxCardElevation((float) d4);
        cardView.setPreventCornerOverlap(z);
        if (view.getParent() instanceof LinearLayout) {
            ViewGroup viewGroup = (ViewGroup) view.getParent();
            viewGroup.removeView(view);
            viewGroup.removeAllViews();
            viewGroup.addView(cardView);
            cardView.addView(view);
        }
    }

    public void _interstitalAds() {
        InterstitialAd.load(this, getApplicationContext().getResources().getString(R.string.interstitaluidOnly), new AdRequest.Builder().build(), new InterstitialAdLoadCallback() { // from class: com.bgm.gfx.BgmActivity.138
            @Override // com.google.android.gms.ads.AdLoadCallback
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                BgmActivity.this.No_loading = StringFogImpl.decrypt("Gh8=");
                BgmActivity.this.ADD_LOADED = true;
                BgmActivity.this.mInterstitialAd = interstitialAd;
                BgmActivity.this.mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() { // from class: com.bgm.gfx.BgmActivity.138.1
                    @Override // com.google.android.gms.ads.FullScreenContentCallback
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                    }

                    @Override // com.google.android.gms.ads.FullScreenContentCallback
                    public void onAdDismissedFullScreenContent() {
                        BgmActivity.this.ADD_LOADED = false;
                        BgmActivity.this._interstitalAds();
                    }

                    @Override // com.google.android.gms.ads.FullScreenContentCallback
                    public void onAdShowedFullScreenContent() {
                        BgmActivity.this.mInterstitialAd = null;
                    }
                });
            }

            @Override // com.google.android.gms.ads.AdLoadCallback
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                BgmActivity.this._interstitalAds();
                BgmActivity.this.No_loading = StringFogImpl.decrypt("Gh8=");
                BgmActivity.this.ADD_LOADED = false;
                BgmActivity.this.mInterstitialAd = null;
            }
        });
    }

    public void _rewarded_video() {
        RewardedAd.load(this, getApplicationContext().getResources().getString(R.string.rewardedOnly), new AdRequest.Builder().build(), new RewardedAdLoadCallback() { // from class: com.bgm.gfx.BgmActivity.139
            @Override // com.google.android.gms.ads.AdLoadCallback
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                BgmActivity.this.mRewardedAd = null;
            }

            @Override // com.google.android.gms.ads.AdLoadCallback
            public void onAdLoaded(@NonNull RewardedAd rewardedAd) {
                BgmActivity.this.mRewardedAd = rewardedAd;
                BgmActivity.this.mRewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() { // from class: com.bgm.gfx.BgmActivity.139.1
                    @Override // com.google.android.gms.ads.FullScreenContentCallback
                    public void onAdShowedFullScreenContent() {
                    }

                    @Override // com.google.android.gms.ads.FullScreenContentCallback
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                        if (!BgmActivity.this.ADD_LOADED || BgmActivity.this.mInterstitialAd == null) {
                            return;
                        }
                        BgmActivity.this.mInterstitialAd.show(BgmActivity.this);
                    }

                    @Override // com.google.android.gms.ads.FullScreenContentCallback
                    public void onAdDismissedFullScreenContent() {
                        BgmActivity.this.mRewardedAd = null;
                    }
                });
            }
        });
    }

    public void _askPermission(View view) {
        try {
            this.i2.addFlags(3);
            this.i2.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7egl9fRsLAmJ7ABkDY2wKABRofQ=="));
            this.muri = Uri.parse(this.URI_PERMISION);
            this.i2.putExtra(StringFogImpl.decrypt("NDoiX1c8MGhdSjoiL0ldJ3ojVUwnNWhkdhwAD2x0CgEUZA=="), this.muri);
            startActivityForResult(this.i2, this.NEW_FOLDER_REQUEST_CODE);
        } catch (Exception unused) {
            SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0dBRISyE1NFkYFCQ2"));
        }
    }

    public void _permission_A13() {
        try {
            this.muri = Uri.parse(this.URI_PERMISION);
            try {
                this.uri2 = Uri.parse(this.sp.getString(StringFogImpl.decrypt("ER0UaHsBCwBidBERFHJtBx13"), ""));
                this.URI_PERMISSION_VER = StringFogImpl.decrypt("ER0UaHsBCwBidBERFHJtBx13");
                this.mfile = DocumentFile.fromTreeUri(this, this.uri2);
                AnonymousClass140 anonymousClass140 = new AnonymousClass140();
                this.t = anonymousClass140;
                this._timer.schedule(anonymousClass140, 500L);
            } catch (Exception unused) {
                final AlertDialog create = new AlertDialog.Builder(this).create();
                View inflate = getLayoutInflater().inflate(R.layout.custom, (ViewGroup) null);
                create.setView(inflate);
                create.requestWindowFeature(1);
                create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear3);
                Button button = (Button) inflate.findViewById(R.id.button1);
                Button button2 = (Button) inflate.findViewById(R.id.button2);
                GradientDrawable gradientDrawable = new GradientDrawable();
                gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dmwFFH0TEg==")));
                gradientDrawable.setCornerRadius(25.0f);
                ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                GradientDrawable gradientDrawable2 = new GradientDrawable();
                gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dmwFFH0TEg==")));
                gradientDrawable2.setCornerRadius(20.0f);
                ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                button2.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.141
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        CuteToast.ct((Context) BgmActivity.this, (CharSequence) StringFogImpl.decrypt("EgYHY2x1BAN/dRwHFWR3Gw=="), 0, CuteToast.NORMAL, true).show();
                        BgmActivity bgmActivity = BgmActivity.this;
                        bgmActivity._askPermission(bgmActivity.linear7);
                        create.dismiss();
                    }
                });
                button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.142
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view) {
                        create.dismiss();
                        BgmActivity.this.finishAffinity();
                    }
                });
                create.show();
                create.setCancelable(false);
                GradientDrawable gradientDrawable3 = new GradientDrawable();
                int i = (int) getApplicationContext().getResources().getDisplayMetrics().density;
                gradientDrawable3.setColor(-14805699);
                gradientDrawable3.setCornerRadius(i * 12);
                button2.setElevation(i * 5);
                button2.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-2039584}), gradientDrawable3, null));
                button2.setClickable(true);
                GradientDrawable gradientDrawable4 = new GradientDrawable();
                int i2 = (int) getApplicationContext().getResources().getDisplayMetrics().density;
                gradientDrawable4.setColor(ViewCompat.MEASURED_SIZE_MASK);
                gradientDrawable4.setCornerRadius(i2 * 12);
                gradientDrawable4.setStroke(i2 * 3, -14805699);
                button.setElevation(i2 * 5);
                button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable4, null));
                button.setClickable(true);
                GradientDrawable gradientDrawable5 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dmUjHA1mMA==")), Color.parseColor(StringFogImpl.decrypt("dmUjHA1mMA=="))});
                gradientDrawable5.setCornerRadii(new float[]{25.0f, 25.0f, 25.0f, 25.0f, 0.0f, 0.0f, 0.0f, 0.0f});
                gradientDrawable5.setStroke(0, Color.parseColor(StringFogImpl.decrypt("dmR2HQhlZA==")));
                linearLayout2.setElevation(5.0f);
                linearLayout2.setBackground(gradientDrawable5);
            }
        } catch (Exception unused2) {
            SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp0dBRISyE1NFkYFCQ2"));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$140  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass140 extends TimerTask {
        AnonymousClass140() {
        }

        @Override // java.util.TimerTask, java.lang.Runnable
        public void run() {
            BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.140.1
                @Override // java.lang.Runnable
                public void run() {
                    try {
                        if (BgmActivity.this.mfile.canWrite() && BgmActivity.this.mfile.canRead()) {
                            return;
                        }
                        try {
                            final AlertDialog create = new AlertDialog.Builder(BgmActivity.this).create();
                            View inflate = BgmActivity.this.getLayoutInflater().inflate(R.layout.custom, (ViewGroup) null);
                            create.setView(inflate);
                            create.requestWindowFeature(1);
                            create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                            LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                            LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear3);
                            Button button = (Button) inflate.findViewById(R.id.button1);
                            Button button2 = (Button) inflate.findViewById(R.id.button2);
                            GradientDrawable gradientDrawable = new GradientDrawable();
                            gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dmwFFH0TEg==")));
                            gradientDrawable.setCornerRadius(25.0f);
                            ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                            GradientDrawable gradientDrawable2 = new GradientDrawable();
                            gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dmwFFH0TEg==")));
                            gradientDrawable2.setCornerRadius(20.0f);
                            ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                            button2.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.140.1.1
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    CuteToast.ct((Context) BgmActivity.this, (CharSequence) StringFogImpl.decrypt("EgYHY2x1BAN/dRwHFWR3Gw=="), 0, CuteToast.NORMAL, true).show();
                                    BgmActivity.this._askPermission(BgmActivity.this.linear7);
                                    create.dismiss();
                                }
                            });
                            button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.140.1.2
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    create.dismiss();
                                    BgmActivity.this.finishAffinity();
                                }
                            });
                            create.show();
                            create.setCancelable(false);
                            GradientDrawable gradientDrawable3 = new GradientDrawable();
                            int i = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                            gradientDrawable3.setColor(-14805699);
                            gradientDrawable3.setCornerRadius(i * 12);
                            button2.setElevation(i * 5);
                            button2.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-2039584}), gradientDrawable3, null));
                            button2.setClickable(true);
                            GradientDrawable gradientDrawable4 = new GradientDrawable();
                            int i2 = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                            gradientDrawable4.setColor(ViewCompat.MEASURED_SIZE_MASK);
                            gradientDrawable4.setCornerRadius(i2 * 12);
                            gradientDrawable4.setStroke(i2 * 3, -14805699);
                            button.setElevation(i2 * 5);
                            button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable4, null));
                            button.setClickable(true);
                            GradientDrawable gradientDrawable5 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dmUjHA1mMA==")), Color.parseColor(StringFogImpl.decrypt("dmUjHA1mMA=="))});
                            gradientDrawable5.setCornerRadii(new float[]{25.0f, 25.0f, 25.0f, 25.0f, 0.0f, 0.0f, 0.0f, 0.0f});
                            gradientDrawable5.setStroke(0, Color.parseColor(StringFogImpl.decrypt("dmR2HQhlZA==")));
                            linearLayout2.setElevation(5.0f);
                            linearLayout2.setBackground(gradientDrawable5);
                        } catch (Exception unused) {
                            BgmActivity.this._askPermission(BgmActivity.this.linear7);
                        }
                    } catch (Exception unused2) {
                        final AlertDialog create2 = new AlertDialog.Builder(BgmActivity.this).create();
                        View inflate2 = BgmActivity.this.getLayoutInflater().inflate(R.layout.custom, (ViewGroup) null);
                        create2.setView(inflate2);
                        create2.requestWindowFeature(1);
                        create2.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                        LinearLayout linearLayout3 = (LinearLayout) inflate2.findViewById(R.id.linear_bg);
                        LinearLayout linearLayout4 = (LinearLayout) inflate2.findViewById(R.id.linear3);
                        Button button3 = (Button) inflate2.findViewById(R.id.button1);
                        Button button4 = (Button) inflate2.findViewById(R.id.button2);
                        GradientDrawable gradientDrawable6 = new GradientDrawable();
                        gradientDrawable6.setColor(Color.parseColor(StringFogImpl.decrypt("dmwFFH0TEg==")));
                        gradientDrawable6.setCornerRadius(25.0f);
                        ((LinearLayout) inflate2.findViewById(R.id.linear_content)).setBackground(gradientDrawable6);
                        GradientDrawable gradientDrawable7 = new GradientDrawable();
                        gradientDrawable7.setColor(Color.parseColor(StringFogImpl.decrypt("dmwFFH0TEg==")));
                        gradientDrawable7.setCornerRadius(20.0f);
                        ((ImageView) inflate2.findViewById(R.id.imageview1)).setElevation(5.0f);
                        button4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.140.1.3
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                CuteToast.ct((Context) BgmActivity.this, (CharSequence) StringFogImpl.decrypt("EgYHY2x1BAN/dRwHFWR3Gw=="), 0, CuteToast.NORMAL, true).show();
                                BgmActivity.this._askPermission(BgmActivity.this.linear7);
                                create2.dismiss();
                            }
                        });
                        button3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.140.1.4
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                create2.dismiss();
                                BgmActivity.this.finishAffinity();
                            }
                        });
                        create2.show();
                        create2.setCancelable(false);
                        GradientDrawable gradientDrawable8 = new GradientDrawable();
                        int i3 = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                        gradientDrawable8.setColor(-14805699);
                        gradientDrawable8.setCornerRadius(i3 * 12);
                        button4.setElevation(i3 * 5);
                        button4.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-2039584}), gradientDrawable8, null));
                        button4.setClickable(true);
                        GradientDrawable gradientDrawable9 = new GradientDrawable();
                        int i4 = (int) BgmActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                        gradientDrawable9.setColor(ViewCompat.MEASURED_SIZE_MASK);
                        gradientDrawable9.setCornerRadius(i4 * 12);
                        gradientDrawable9.setStroke(i4 * 3, -14805699);
                        button3.setElevation(i4 * 5);
                        button3.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable9, null));
                        button3.setClickable(true);
                        GradientDrawable gradientDrawable10 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dmUjHA1mMA==")), Color.parseColor(StringFogImpl.decrypt("dmUjHA1mMA=="))});
                        gradientDrawable10.setCornerRadii(new float[]{25.0f, 25.0f, 25.0f, 25.0f, 0.0f, 0.0f, 0.0f, 0.0f});
                        gradientDrawable10.setStroke(0, Color.parseColor(StringFogImpl.decrypt("dmR2HQhlZA==")));
                        linearLayout4.setElevation(5.0f);
                        linearLayout4.setBackground(gradientDrawable10);
                    }
                }
            });
        }
    }

    public void _activity_always_screen_on() {
        getWindow().addFlags(128);
    }

    public void _Delete(String str) {
        try {
            try {
                Uri parse = Uri.parse(this.sp.getString(this.URI_PERMISSION_VER, "").concat(str.replace(StringFogImpl.decrypt("eg=="), StringFogImpl.decrypt("cGYA"))));
                this.uri9 = parse;
                this.New = DocumentFile.fromTreeUri(this, parse);
            } catch (Exception unused) {
                SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("e3po"));
            }
            AnonymousClass143 anonymousClass143 = new AnonymousClass143();
            this.t = anonymousClass143;
            this._timer.schedule(anonymousClass143, 100L);
        } catch (Exception unused2) {
            SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("e3po"));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.BgmActivity$143  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass143 extends TimerTask {
        AnonymousClass143() {
        }

        /* renamed from: com.bgm.gfx.BgmActivity$143$1  reason: invalid class name */
        /* loaded from: classes7.dex */
        class AnonymousClass1 implements Runnable {
            AnonymousClass1() {
            }

            @Override // java.lang.Runnable
            public void run() {
                if (BgmActivity.this.New.exists()) {
                    BgmActivity.this.t = new TimerTask() { // from class: com.bgm.gfx.BgmActivity.143.1.1
                        @Override // java.util.TimerTask, java.lang.Runnable
                        public void run() {
                            BgmActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BgmActivity.143.1.1.1
                                @Override // java.lang.Runnable
                                public void run() {
                                    try {
                                        DocumentsContract.deleteDocument(BgmActivity.this.getApplicationContext().getContentResolver(), BgmActivity.this.uri9);
                                    } catch (FileNotFoundException unused) {
                                    } catch (Exception unused2) {
                                        SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("e3po"));
                                    }
                                }
                            });
                        }
                    };
                    BgmActivity.this._timer.schedule(BgmActivity.this.t, 200L);
                }
            }
        }

        @Override // java.util.TimerTask, java.lang.Runnable
        public void run() {
            BgmActivity.this.runOnUiThread(new AnonymousClass1());
        }
    }

    private void showFloatingWindow2() {
        View inflate = LayoutInflater.from(this).inflate(R.layout.fps, (ViewGroup) null);
        this.aaV = inflate;
        inflate.setOnTouchListener(new FloatingOnTouchListener2(this, null));
        LinearLayout linearLayout = (LinearLayout) this.aaV.findViewById(R.id.linear1);
        this.aa.addView(this.aaV, this.aaLP);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes7.dex */
    public class FloatingOnTouchListener2 implements View.OnTouchListener {
        private int x;
        private int y;

        private FloatingOnTouchListener2() {
        }

        /* synthetic */ FloatingOnTouchListener2(BgmActivity bgmActivity, FloatingOnTouchListener2 floatingOnTouchListener2) {
            this();
        }

        @Override // android.view.View.OnTouchListener
        public boolean onTouch(View view, MotionEvent motionEvent) {
            int action = motionEvent.getAction();
            if (action == 0) {
                this.x = (int) motionEvent.getRawX();
                this.y = (int) motionEvent.getRawY();
                return true;
            } else if (action != 2) {
                return true;
            } else {
                int rawX = (int) motionEvent.getRawX();
                int rawY = (int) motionEvent.getRawY();
                int i = rawX - this.x;
                int i2 = rawY - this.y;
                this.x = rawX;
                this.y = rawY;
                BgmActivity.this.aaLP.x += i;
                BgmActivity.this.aaLP.y += i2;
                BgmActivity.this.aa.updateViewLayout(view, BgmActivity.this.aaLP);
                return true;
            }
        }
    }

    public void closes2() {
        try {
            this.aa.removeView(this.aaV);
            _cancelNotification();
            this.floatingWindowIsOn = false;
        } catch (Exception unused) {
        }
    }

    public void _floating(double d, double d2) {
        this.aa = (WindowManager) getSystemService(StringFogImpl.decrypt("Ij0oSVci"));
        this.aaLP = new WindowManager.LayoutParams();
        if (Build.VERSION.SDK_INT >= 26) {
            this.aaLP.type = 2038;
        } else {
            this.aaLP.type = 2002;
        }
        this.aaLP.format = 1;
        this.aaLP.gravity = 51;
        this.aaLP.flags = 40;
        this.aaLP.width = (int) d;
        this.aaLP.height = (int) d2;
        this.aaLP.x = 0;
        this.aaLP.y = 0;
    }

    public void _showFloatingWindow() {
        showFloatingWindow2();
        _Notification_Permission();
    }

    public void _closeFloatingWindow() {
        closes2();
    }

    public void _checkPermission() {
        String decrypt = StringFogImpl.decrypt("NDoiX1c8MGheXSEgL0NfJnonTkw8OygDdRQaB2p9ChsQaGoZFR9yaBAGC2RrBh0JYw==");
        Intent intent = new Intent(decrypt, Uri.parse(StringFogImpl.decrypt("JTUlRlkyMXw=") + getPackageName()));
        this.intent = intent;
        startActivity(intent);
    }

    public void _cancelNotification() {
        try {
            NotificationManager notificationManager = (NotificationManager) getSystemService(StringFogImpl.decrypt("OzsyRF48NydZUTo6"));
            notificationManager.cancel(1);
            notificationManager.cancelAll();
        } catch (Exception unused) {
            SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("EAYUYmp1BgN+bBQGEg15BQRm3afP/w=="));
        }
    }

    public void _Notification_Permission() {
        if (NotificationManagerCompat.from(this).areNotificationsEnabled()) {
            _notification();
            return;
        }
        _closeFloatingWindow();
        this.switch53.setChecked(false);
        GradientDrawable gradientDrawable = new GradientDrawable();
        int i = (int) getApplicationContext().getResources().getDisplayMetrics().density;
        gradientDrawable.setColor(-9673729);
        gradientDrawable.setCornerRadius(i * 360);
        gradientDrawable.setStroke(i * 1, 805306368);
        this.switch53.setBackground(gradientDrawable);
        CuteToast.ct((Context) this, (CharSequence) StringFogImpl.decrypt("EgYHY2x1BAN/dRwHFWR3Gw=="), 0, CuteToast.NORMAL, true).show();
        Intent intent = new Intent();
        intent.setAction(StringFogImpl.decrypt("NDoiX1c8MGheXSEgL0NfJnoHfWgKGgl5cRMdBWxsHBsIcmsQABJkdhIH"));
        intent.putExtra(StringFogImpl.decrypt("NDoiX1c8MGhdSjoiL0ldJ3ojVUwnNWhsaAULFmx7HhUBaA=="), getApplicationContext().getPackageName());
        startActivity(intent);
    }

    public void _notification2(String str, String str2, double d) {
        NotificationManager notificationManager = (NotificationManager) getSystemService(StringFogImpl.decrypt("OzsyRF48NydZUTo6"));
        String decrypt = StringFogImpl.decrypt("Jj8jWVs9OD9OUDQ6KEhU");
        String decrypt2 = StringFogImpl.decrypt("Bj8jWVs9OD8=");
        if (Build.VERSION.SDK_INT >= 26) {
            notificationManager.createNotificationChannel(new NotificationChannel(decrypt, decrypt2, 4));
        }
        NotificationCompat.Builder contentText = new NotificationCompat.Builder(this, decrypt).setSmallIcon(R.drawable.app_icon).setTicker("").setContentTitle(str).setContentText(str2);
        if (d != 101.0d) {
            contentText.setProgress(100, (int) d, false);
        }
        notificationManager.notify(0, contentText.build());
    }

    public void _notification() {
        try {
            if (Settings.canDrawOverlays(this)) {
                final PendingIntent activity = PendingIntent.getActivity(this, 0, new Intent(this, NotificationActivity.class), 335544320);
                final Timer timer = new Timer();
                timer.scheduleAtFixedRate(new TimerTask() { // from class: com.bgm.gfx.BgmActivity.144
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        if (!BgmActivity.this.floatingWindowIsOn) {
                            NotificationManager notificationManager = (NotificationManager) BgmActivity.this.getSystemService(StringFogImpl.decrypt("OzsyRF48NydZUTo6"));
                            if (notificationManager != null) {
                                notificationManager.cancelAll();
                            }
                            timer.cancel();
                            return;
                        }
                        String str = BgmiActivity.fpsValue;
                        NotificationCompat.Builder largeIcon = new NotificationCompat.Builder(BgmActivity.this, StringFogImpl.decrypt("PDA=")).setSmallIcon(R.drawable.app_icon).setContentTitle(StringFogImpl.decrypt("EwQVDXUaGg95dwd0A2N5FxgDaQ==")).setLargeIcon(BitmapFactory.decodeResource(BgmActivity.this.getResources(), R.drawable.logo));
                        NotificationCompat.Builder onlyAlertOnce = largeIcon.setContentText(StringFogImpl.decrypt("FiE0X107IGZraAZ0fA0=") + str).setContentIntent(activity).setOngoing(true).setPriority(1).setDefaults(7).setOnlyAlertOnce(true);
                        NotificationManager notificationManager2 = (NotificationManager) BgmActivity.this.getSystemService(StringFogImpl.decrypt("OzsyRF48NydZUTo6"));
                        if (Build.VERSION.SDK_INT >= 26) {
                            NotificationChannel notificationChannel = new NotificationChannel(StringFogImpl.decrypt("PDA="), StringFogImpl.decrypt("FjwnQ1YwOGZjWTgx"), 4);
                            notificationChannel.setDescription(StringFogImpl.decrypt("FjwnQ1YwOGZpXSY3NERIIT0pQw=="));
                            notificationChannel.setLockscreenVisibility(1);
                            notificationManager2.createNotificationChannel(notificationChannel);
                        }
                        if (notificationManager2 != null) {
                            try {
                                notificationManager2.notify(1, onlyAlertOnce.build());
                                BgmActivity.this.NOTI = StringFogImpl.decrypt("LDE1");
                            } catch (Exception unused) {
                                BgmActivity.this.NOTI = StringFogImpl.decrypt("ZQ==");
                            }
                        }
                    }
                }, 0L, 1000L);
                this.floatingWindowIsOn = true;
            }
        } catch (Exception e) {
            SketchwareUtil.showMessage(getApplicationContext(), e.getMessage());
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:25:0x037d A[Catch: Exception -> 0x0958, TRY_ENTER, TryCatch #0 {Exception -> 0x0958, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08c7, B:75:0x08df, B:79:0x0902, B:76:0x08e5, B:78:0x08fd, B:80:0x091c, B:82:0x0934, B:83:0x093a, B:85:0x0952, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:26:0x038f  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x03cc A[Catch: Exception -> 0x0958, TryCatch #0 {Exception -> 0x0958, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08c7, B:75:0x08df, B:79:0x0902, B:76:0x08e5, B:78:0x08fd, B:80:0x091c, B:82:0x0934, B:83:0x093a, B:85:0x0952, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:30:0x03ea A[Catch: Exception -> 0x0958, TryCatch #0 {Exception -> 0x0958, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08c7, B:75:0x08df, B:79:0x0902, B:76:0x08e5, B:78:0x08fd, B:80:0x091c, B:82:0x0934, B:83:0x093a, B:85:0x0952, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0560 A[Catch: Exception -> 0x0958, TryCatch #0 {Exception -> 0x0958, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08c7, B:75:0x08df, B:79:0x0902, B:76:0x08e5, B:78:0x08fd, B:80:0x091c, B:82:0x0934, B:83:0x093a, B:85:0x0952, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0585 A[Catch: Exception -> 0x0958, TryCatch #0 {Exception -> 0x0958, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08c7, B:75:0x08df, B:79:0x0902, B:76:0x08e5, B:78:0x08fd, B:80:0x091c, B:82:0x0934, B:83:0x093a, B:85:0x0952, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:46:0x065d A[Catch: Exception -> 0x0958, TryCatch #0 {Exception -> 0x0958, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08c7, B:75:0x08df, B:79:0x0902, B:76:0x08e5, B:78:0x08fd, B:80:0x091c, B:82:0x0934, B:83:0x093a, B:85:0x0952, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0746 A[Catch: Exception -> 0x0958, TryCatch #0 {Exception -> 0x0958, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08c7, B:75:0x08df, B:79:0x0902, B:76:0x08e5, B:78:0x08fd, B:80:0x091c, B:82:0x0934, B:83:0x093a, B:85:0x0952, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:52:0x07e7 A[Catch: Exception -> 0x0958, TryCatch #0 {Exception -> 0x0958, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08c7, B:75:0x08df, B:79:0x0902, B:76:0x08e5, B:78:0x08fd, B:80:0x091c, B:82:0x0934, B:83:0x093a, B:85:0x0952, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:58:0x0826 A[Catch: Exception -> 0x0958, TryCatch #0 {Exception -> 0x0958, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08c7, B:75:0x08df, B:79:0x0902, B:76:0x08e5, B:78:0x08fd, B:80:0x091c, B:82:0x0934, B:83:0x093a, B:85:0x0952, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:69:0x0899 A[Catch: Exception -> 0x0958, TryCatch #0 {Exception -> 0x0958, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08c7, B:75:0x08df, B:79:0x0902, B:76:0x08e5, B:78:0x08fd, B:80:0x091c, B:82:0x0934, B:83:0x093a, B:85:0x0952, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:92:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    public void _myUpadate(String str) {
        String str2;
        String obj;
        String str3;
        String str4;
        String str5;
        String obj2;
        String str6;
        double d;
        String str7;
        String str8 = null;
        String str9;
        try {
            if (this.sketchify_time != 0.0d) {
                return;
            }
            StringFogImpl.decrypt("ZQ==");
            StringFogImpl.decrypt("ZQ==");
            StringFogImpl.decrypt("ZQ==");
            StringFogImpl.decrypt("ZQ==");
            StringFogImpl.decrypt("ZQ==");
            String str10 = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            this.SketchifyMap = (HashMap) new Gson().fromJson(str, new TypeToken<HashMap<String, Object>>() { // from class: com.bgm.gfx.BgmActivity.145
            }.getType());
            double d2 = this.sketchify_load;
            if (d2 == 0.0d) {
                this.sketchify_load = d2 + 1.0d;
                this.UCSP.edit().putString(StringFogImpl.decrypt("MT0nQVcyGzZZUTo6"), this.SketchifyMap.get(StringFogImpl.decrypt("MT0nQVcyGzZZUTo6")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("JjE0W10n"), this.SketchifyMap.get(StringFogImpl.decrypt("JjE0W10n")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("ACYq"), this.SketchifyMap.get(StringFogImpl.decrypt("OiQjQ3Q8Oi1oQCEmJw==")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("ACYqHA=="), this.SketchifyMap.get(StringFogImpl.decrypt("OiQjQ3Q8Oi1gWTw6")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("PCcFTFY2MSpMWjkx"), this.SketchifyMap.get(StringFogImpl.decrypt("PCcFTFY2MSpMWjkx")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNEw="), this.SketchifyMap.get(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNEw=")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KG5UPDct"), this.SketchifyMap.get(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KG5UPDct")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KA=="), this.SketchifyMap.get(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KA==")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("OzExe10nJy9CVg=="), this.SketchifyMap.get(StringFogImpl.decrypt("OzExe10nJy9CVg==")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("PCcJQ10BPStI"), this.SketchifyMap.get(StringFogImpl.decrypt("PCcJQ10BPStI")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNEx7OT0lRg=="), this.SketchifyMap.get(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNEx7OT0lRg==")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("JjE0W10n"), this.SketchifyMap.get(StringFogImpl.decrypt("JjE0W10n")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("NDgjX0waJDJEVzs="), this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("PCcJQ10BPStIczAt"), this.SketchifyMap.get(StringFogImpl.decrypt("PCcJQ10BPStIczAt")).toString()).commit();
            }
            String obj3 = this.SketchifyMap.get(StringFogImpl.decrypt("MT0nQVcyAC9ZVDA=")).toString();
            String obj4 = this.SketchifyMap.get(StringFogImpl.decrypt("MT0nQVcyBzNPTDwgKkg=")).toString();
            String obj5 = this.SketchifyMap.get(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNExsLSA=")).toString();
            String obj6 = this.SketchifyMap.get(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KHlAIQ==")).toString();
            if (this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyGzZZUTo6"), "").equals(StringFogImpl.decrypt("IjU0Q1E7Mw=="))) {
                str4 = StringFogImpl.decrypt("dhYCHQBkFw==");
                obj = StringFogImpl.decrypt("dhIAa34TEg==");
                str7 = StringFogImpl.decrypt("dmZ3HwlnZQ==");
                obj2 = StringFogImpl.decrypt("dhIAa34TEg==");
                str2 = "PCcJQ10BPStIczAt";
            } else {
                str2 = "PCcJQ10BPStIczAt";
                if (this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyGzZZUTo6"), "").equals(StringFogImpl.decrypt("ICQiTEww"))) {
                    str4 = StringFogImpl.decrypt("dmR2FQwTEg==");
                    obj = StringFogImpl.decrypt("dhIAa34TEg==");
                    str7 = StringFogImpl.decrypt("dmZ3HwlnZQ==");
                    obj2 = StringFogImpl.decrypt("dhIAa34TEg==");
                } else if (this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyGzZZUTo6"), "").equals(StringFogImpl.decrypt("ODE1XlkyMQ=="))) {
                    str4 = StringFogImpl.decrypt("dmR2bwxtbQ==");
                    obj = StringFogImpl.decrypt("dhIAa34TEg==");
                    str7 = StringFogImpl.decrypt("dmZ3HwlnZQ==");
                    obj2 = StringFogImpl.decrypt("dhIAa34TEg==");
                } else {
                    String obj7 = this.SketchifyMap.get(StringFogImpl.decrypt("NiE1WVc4EC9MVDozB05bMDoy")).toString();
                    obj = this.SketchifyMap.get(StringFogImpl.decrypt("NiE1WVc4EC9MVDozBExbPg==")).toString();
                    double parseDouble = Double.parseDouble(this.SketchifyMap.get(StringFogImpl.decrypt("NiE1WVc4EC9MVDozFEJNOzA=")).toString());
                    String obj8 = this.SketchifyMap.get(StringFogImpl.decrypt("NiE1WVc4EC9MVDozC0xROwA+WXs6OClf")).toString();
                    str3 = obj6;
                    str4 = obj7;
                    str5 = str10;
                    obj2 = this.SketchifyMap.get(StringFogImpl.decrypt("NiE1WVc4EC9MVDozBFlWASwyblc5OzQ=")).toString();
                    str6 = obj5;
                    d = parseDouble;
                    str7 = obj8;
                    if (this.SketchifyMap.containsKey(StringFogImpl.decrypt("NDgjX0waJDJEVzs="))) {
                        str9 = str6;
                        str8 = "ISYzSA==";
                        this.SketchifyMap.put(StringFogImpl.decrypt("NDgjX0waJDJEVzs="), StringFogImpl.decrypt("MT0nQVcy"));
                    } else {
                        str8 = "ISYzSA==";
                        str9 = str6;
                    }
                    LinearLayout linearLayout = new LinearLayout(this);
                    linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2, 0.0f));
                    linearLayout.setPadding(0, 0, 0, 0);
                    linearLayout.setOrientation(1);
                    linearLayout.setGravity(17);
                    if (!this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("JjwjSEw="))) {
                        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
                        this.sketchifySheet = bottomSheetDialog;
                        bottomSheetDialog.setContentView(linearLayout);
                        this.sketchifySheet.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(17170445);
                    } else if (this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("MT0nQVcy"))) {
                        AlertDialog create = new AlertDialog.Builder(this).create();
                        this.sketchifyDialog = create;
                        create.setView(linearLayout);
                        this.sketchifyDialog.getWindow().setBackgroundDrawableResource(17170445);
                    }
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(str4));
                    gradientDrawable.setCornerRadius(100.0f);
                    LinearLayout linearLayout2 = new LinearLayout(this);
                    linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(175, 175, 0.0f));
                    linearLayout2.setPadding(0, 0, 0, 0);
                    linearLayout2.setOrientation(1);
                    linearLayout2.setGravity(17);
                    linearLayout2.setBackground(gradientDrawable);
                    linearLayout.addView(linearLayout2);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(obj));
                    float f = (float) d;
                    gradientDrawable2.setCornerRadius(f);
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                    layoutParams.setMargins(40, 0, 40, 0);
                    LinearLayout linearLayout3 = new LinearLayout(this);
                    linearLayout3.setLayoutParams(new LinearLayout.LayoutParams(-1, -2, 0.0f));
                    linearLayout3.setPadding(45, 140, 45, 45);
                    linearLayout3.setLayoutParams(layoutParams);
                    linearLayout3.setOrientation(1);
                    linearLayout3.setGravity(17);
                    linearLayout3.setBackground(gradientDrawable2);
                    linearLayout.addView(linearLayout3);
                    linearLayout3.setTranslationY(-57.5f);
                    TextView textView = new TextView(this);
                    textView.setLayoutParams(new LinearLayout.LayoutParams(-2, -2, 0.0f));
                    textView.setPadding(0, 0, 0, 0);
                    textView.setGravity(17);
                    textView.setText(obj3);
                    textView.setTextSize(16.0f);
                    textView.setTypeface(null, 1);
                    textView.setTextColor(Color.parseColor(str7));
                    textView.setSingleLine(true);
                    linearLayout3.addView(textView);
                    LinearLayout linearLayout4 = new LinearLayout(this);
                    linearLayout4.setLayoutParams(new LinearLayout.LayoutParams(-1, 15, 0.0f));
                    linearLayout4.setPadding(10, 10, 10, 10);
                    linearLayout4.setOrientation(0);
                    linearLayout4.setGravity(17);
                    linearLayout3.addView(linearLayout4);
                    TextView textView2 = new TextView(this);
                    textView2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2, 0.0f));
                    textView2.setPadding(0, 20, 0, 20);
                    textView2.setGravity(17);
                    textView2.setText(obj4);
                    textView2.setTextSize(14.0f);
                    textView2.setTypeface(textView2.getTypeface(), 1);
                    textView2.setTextColor(Color.parseColor(str7));
                    linearLayout3.addView(textView2);
                    ImageView imageView = new ImageView(this);
                    imageView.setLayoutParams(new LinearLayout.LayoutParams(90, 90, 0.0f));
                    imageView.setPadding(0, 0, 0, 0);
                    if (!this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyGzZZUTo6"), "").equals(StringFogImpl.decrypt("NiE1WVc4"))) {
                        Glide.with(getApplicationContext()).load(Uri.parse(this.SketchifyMap.get(StringFogImpl.decrypt("NiE1WVc4EC9MVDozD05XOw==")).toString())).into(imageView);
                    } else {
                        if (this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyGzZZUTo6"), "").equals(StringFogImpl.decrypt("ODE1XlkyMQ=="))) {
                            Glide.with(getApplicationContext()).load(Uri.parse(StringFogImpl.decrypt("PSAyXUtve2lFUSExJUVfMyxoTlc4eyRKVQozIFVnMTUyTBccNylDS3o3LgNIOzM="))).into(imageView);
                        } else if (this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyGzZZUTo6"), "").equals(StringFogImpl.decrypt("IjU0Q1E7Mw=="))) {
                            Glide.with(getApplicationContext()).load(Uri.parse(StringFogImpl.decrypt("PSAyXUtve2lFUSExJUVfMyxoTlc4eyRKVQozIFVnMTUyTBccNylDS3o1KgNIOzM="))).into(imageView);
                        } else {
                            Glide.with(getApplicationContext()).load(Uri.parse(StringFogImpl.decrypt("PSAyXUtve2lFUSExJUVfMyxoTlc4eyRKVQozIFVnMTUyTBccNylDS3omLQNIOzM="))).into(imageView);
                        }
                        imageView.setImageTintList(new ColorStateList(new int[][]{new int[]{-16842919}, new int[]{16842919}}, new int[]{Color.parseColor(StringFogImpl.decrypt("dhIAa34TEg==")), Color.parseColor(StringFogImpl.decrypt("dhIAa34TEg=="))}));
                    }
                    linearLayout2.addView(imageView);
                    linearLayout2.setElevation(5.0f);
                    linearLayout2.setTranslationY(30.0f);
                    if (this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNEw="), "").equals(StringFogImpl.decrypt(str8))) {
                        LinearLayout linearLayout5 = new LinearLayout(this);
                        linearLayout5.setLayoutParams(new LinearLayout.LayoutParams(-1, 50, 0.0f));
                        linearLayout5.setPadding(8, 8, 8, 8);
                        linearLayout5.setOrientation(0);
                        linearLayout3.addView(linearLayout5);
                        TextView textView3 = new TextView(this);
                        textView3.setLayoutParams(new LinearLayout.LayoutParams(-1, 100, 1.0f));
                        textView3.setPadding(16, 8, 16, 8);
                        textView3.setText(str9);
                        textView3.setTextSize(14.0f);
                        textView3.setTextColor(Color.parseColor(str7));
                        textView3.setGravity(17);
                        linearLayout3.addView(textView3);
                        GradientDrawable gradientDrawable3 = new GradientDrawable();
                        gradientDrawable3.setColor(Color.parseColor(obj));
                        gradientDrawable3.setCornerRadius(f);
                        gradientDrawable3.setStroke(0, Color.parseColor(str4));
                        textView3.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{Color.parseColor(StringFogImpl.decrypt("dmRyFQsTEQ=="))}), gradientDrawable3, null));
                        GradientDrawable gradientDrawable4 = new GradientDrawable();
                        int i = (int) getApplicationContext().getResources().getDisplayMetrics().density;
                        gradientDrawable4.setColor(-1);
                        gradientDrawable4.setCornerRadius(i * 50);
                        int i2 = i * 1;
                        gradientDrawable4.setStroke(i2, -5194043);
                        textView3.setElevation(i2);
                        textView3.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-2039584}), gradientDrawable4, null));
                        textView3.setClickable(true);
                        textView3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.146
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                if (!BgmActivity.this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNEx7OT0lRg=="), "").equals(StringFogImpl.decrypt("MCwvWQ=="))) {
                                    if (BgmActivity.this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNEx7OT0lRg=="), "").equals(StringFogImpl.decrypt("NyYpWkswJg=="))) {
                                        if (!BgmActivity.this.UCSP.getString(StringFogImpl.decrypt("PCcFTFY2MSpMWjkx"), "").equals(StringFogImpl.decrypt("ISYzSA=="))) {
                                            if (BgmActivity.this.UCSP.getString(StringFogImpl.decrypt("PCcFTFY2MSpMWjkx"), "").equals(StringFogImpl.decrypt("MzUqXl0="))) {
                                                try {
                                                    BgmActivity.this.startActivity(new Intent(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="), Uri.parse(BgmActivity.this.UCSP.getString(StringFogImpl.decrypt("ACYq"), ""))));
                                                    BgmActivity.this.finishAffinity();
                                                    return;
                                                } catch (Exception e) {
                                                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), e.toString());
                                                    return;
                                                }
                                            }
                                            SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("dQ8FbHYWEQpw"));
                                            return;
                                        }
                                        try {
                                            BgmActivity.this.startActivity(new Intent(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="), Uri.parse(BgmActivity.this.UCSP.getString(StringFogImpl.decrypt("ACYq"), ""))));
                                            return;
                                        } catch (Exception e2) {
                                            SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), e2.toString());
                                            return;
                                        }
                                    } else if (BgmActivity.this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNEx7OT0lRg=="), "").equals(StringFogImpl.decrypt("MT01QFEmJw=="))) {
                                        try {
                                            if (!BgmActivity.this.UCSP.getString(StringFogImpl.decrypt("NDgjX0waJDJEVzs="), "").equals(StringFogImpl.decrypt("MT0nQVcy"))) {
                                                if (BgmActivity.this.UCSP.getString(StringFogImpl.decrypt("NDgjX0waJDJEVzs="), "").equals(StringFogImpl.decrypt("JjwjSEw="))) {
                                                    BgmActivity.this.sketchifySheet.dismiss();
                                                }
                                            } else {
                                                BgmActivity.this.sketchifyDialog.dismiss();
                                            }
                                            return;
                                        } catch (Exception unused) {
                                            return;
                                        }
                                    } else {
                                        SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("dQ8CZGsYHRV+ZQ=="));
                                        return;
                                    }
                                }
                                BgmActivity.this.finishAffinity();
                            }
                        });
                    }
                    if (this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KA=="), "").equals(StringFogImpl.decrypt(str8))) {
                        LinearLayout linearLayout6 = new LinearLayout(this);
                        linearLayout6.setLayoutParams(new LinearLayout.LayoutParams(-1, 30, 0.0f));
                        linearLayout6.setPadding(8, 8, 8, 8);
                        linearLayout6.setOrientation(0);
                        linearLayout3.addView(linearLayout6);
                        TextView textView4 = new TextView(this);
                        textView4.setLayoutParams(new LinearLayout.LayoutParams(-1, 100, 0.0f));
                        textView4.setPadding(16, 8, 16, 8);
                        textView4.setText(str3);
                        textView4.setTextSize(14.0f);
                        textView4.setTextColor(Color.parseColor(obj2));
                        textView4.setGravity(17);
                        linearLayout3.addView(textView4);
                        GradientDrawable gradientDrawable5 = new GradientDrawable();
                        gradientDrawable5.setColor(Color.parseColor(str4));
                        gradientDrawable5.setCornerRadius(f);
                        gradientDrawable5.setStroke(0, Color.parseColor(str4));
                        textView4.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{Color.parseColor(StringFogImpl.decrypt("dhEDaH0QEQ=="))}), gradientDrawable5, null));
                        textView4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BgmActivity.147
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                if (!BgmActivity.this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KG5UPDct"), "").equals(StringFogImpl.decrypt("MCwvWQ=="))) {
                                    if (BgmActivity.this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KG5UPDct"), "").equals(StringFogImpl.decrypt("NyYpWkswJg=="))) {
                                        if (!BgmActivity.this.UCSP.getString(StringFogImpl.decrypt("PCcFTFY2MSpMWjkx"), "").equals(StringFogImpl.decrypt("ISYzSA=="))) {
                                            if (BgmActivity.this.UCSP.getString(StringFogImpl.decrypt("PCcFTFY2MSpMWjkx"), "").equals(StringFogImpl.decrypt("MzUqXl0="))) {
                                                try {
                                                    BgmActivity.this.startActivity(new Intent(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="), Uri.parse(BgmActivity.this.UCSP.getString(StringFogImpl.decrypt("ACYqHA=="), ""))));
                                                    return;
                                                } catch (Exception e) {
                                                    SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), e.toString());
                                                    return;
                                                }
                                            }
                                            SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("DhcHY3sQGBs="));
                                            return;
                                        }
                                        try {
                                            BgmActivity.this.startActivity(new Intent(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="), Uri.parse(BgmActivity.this.UCSP.getString(StringFogImpl.decrypt("ACYqHA=="), ""))));
                                            BgmActivity.this.finishAffinity();
                                            return;
                                        } catch (Exception e2) {
                                            SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), e2.toString());
                                            return;
                                        }
                                    } else if (BgmActivity.this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KG5UPDct"), "").equals(StringFogImpl.decrypt("MT01QFEmJw=="))) {
                                        try {
                                            if (!BgmActivity.this.UCSP.getString(StringFogImpl.decrypt("NDgjX0waJDJEVzs="), "").equals(StringFogImpl.decrypt("MT0nQVcy"))) {
                                                if (BgmActivity.this.UCSP.getString(StringFogImpl.decrypt("NDgjX0waJDJEVzs="), "").equals(StringFogImpl.decrypt("JjwjSEw="))) {
                                                    BgmActivity.this.sketchifySheet.dismiss();
                                                }
                                            } else {
                                                BgmActivity.this.sketchifyDialog.dismiss();
                                            }
                                            return;
                                        } catch (Exception unused) {
                                            return;
                                        }
                                    } else {
                                        SketchwareUtil.showMessage(BgmActivity.this.getApplicationContext(), StringFogImpl.decrypt("dQ8CZGsYHRV+ZQ=="));
                                        return;
                                    }
                                }
                                BgmActivity.this.finishAffinity();
                            }
                        });
                    }
                    if (!this.UCSP.getString(StringFogImpl.decrypt("PCcFTFY2MSpMWjkx"), "").equals(StringFogImpl.decrypt("MzUqXl0="))) {
                        if (this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("JjwjSEw="))) {
                            this.sketchifySheet.setCancelable(false);
                        } else if (this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("MT0nQVcy"))) {
                            this.sketchifyDialog.setCancelable(false);
                        }
                    } else if (this.UCSP.getString(StringFogImpl.decrypt("PCcFTFY2MSpMWjkx"), "").equals(StringFogImpl.decrypt(str8))) {
                        if (this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("JjwjSEw="))) {
                            this.sketchifySheet.setCancelable(true);
                        } else if (this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("MT0nQVcy"))) {
                            this.sketchifyDialog.setCancelable(true);
                        }
                    } else {
                        SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("dQ8FbHYWEQpw"));
                    }
                    if (this.UCSP.getString(StringFogImpl.decrypt("OzExe10nJy9CVg=="), "").equals(str5)) {
                        if (this.UCSP.getString(StringFogImpl.decrypt("PCcJQ10BPStI"), "").equals(StringFogImpl.decrypt(str8))) {
                            if (this.UCSP.getString(this.packageName, "").equals(this.UCSP.getString(StringFogImpl.decrypt(str2), ""))) {
                                return;
                            }
                            if (this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("JjwjSEw="))) {
                                this.sketchifySheet.show();
                            } else if (this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("MT0nQVcy"))) {
                                this.sketchifyDialog.show();
                            }
                            this.UCSP.edit().putString(this.packageName, this.UCSP.getString(StringFogImpl.decrypt(str2), "")).commit();
                            return;
                        } else if (this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("JjwjSEw="))) {
                            this.sketchifySheet.show();
                            return;
                        } else if (this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("MT0nQVcy"))) {
                            this.sketchifyDialog.show();
                            return;
                        } else {
                            return;
                        }
                    }
                    return;
                }
            }
            str6 = obj5;
            str5 = str10;
            str3 = obj6;
            d = 60.0d;
            if (this.SketchifyMap.containsKey(StringFogImpl.decrypt("NDgjX0waJDJEVzs="))) {
            }
            LinearLayout linearLayout7 = new LinearLayout(this);
            linearLayout7.setLayoutParams(new LinearLayout.LayoutParams(-1, -2, 0.0f));
            linearLayout7.setPadding(0, 0, 0, 0);
            linearLayout7.setOrientation(1);
            linearLayout7.setGravity(17);
            if (!this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("JjwjSEw="))) {
            }
            GradientDrawable gradientDrawable6 = new GradientDrawable();
            gradientDrawable6.setColor(Color.parseColor(str4));
            gradientDrawable6.setCornerRadius(100.0f);
            LinearLayout linearLayout22 = new LinearLayout(this);
            linearLayout22.setLayoutParams(new LinearLayout.LayoutParams(175, 175, 0.0f));
            linearLayout22.setPadding(0, 0, 0, 0);
            linearLayout22.setOrientation(1);
            linearLayout22.setGravity(17);
            linearLayout22.setBackground(gradientDrawable6);
            linearLayout7.addView(linearLayout22);
            GradientDrawable gradientDrawable22 = new GradientDrawable();
            gradientDrawable22.setColor(Color.parseColor(obj));
            float f2 = (float) d;
            gradientDrawable22.setCornerRadius(f2);
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams2.setMargins(40, 0, 40, 0);
            LinearLayout linearLayout32 = new LinearLayout(this);
            linearLayout32.setLayoutParams(new LinearLayout.LayoutParams(-1, -2, 0.0f));
            linearLayout32.setPadding(45, 140, 45, 45);
            linearLayout32.setLayoutParams(layoutParams2);
            linearLayout32.setOrientation(1);
            linearLayout32.setGravity(17);
            linearLayout32.setBackground(gradientDrawable22);
            linearLayout7.addView(linearLayout32);
            linearLayout32.setTranslationY(-57.5f);
            TextView textView5 = new TextView(this);
            textView5.setLayoutParams(new LinearLayout.LayoutParams(-2, -2, 0.0f));
            textView5.setPadding(0, 0, 0, 0);
            textView5.setGravity(17);
            textView5.setText(obj3);
            textView5.setTextSize(16.0f);
            textView5.setTypeface(null, 1);
            textView5.setTextColor(Color.parseColor(str7));
            textView5.setSingleLine(true);
            linearLayout32.addView(textView5);
            LinearLayout linearLayout42 = new LinearLayout(this);
            linearLayout42.setLayoutParams(new LinearLayout.LayoutParams(-1, 15, 0.0f));
            linearLayout42.setPadding(10, 10, 10, 10);
            linearLayout42.setOrientation(0);
            linearLayout42.setGravity(17);
            linearLayout32.addView(linearLayout42);
            TextView textView22 = new TextView(this);
            textView22.setLayoutParams(new LinearLayout.LayoutParams(-1, -2, 0.0f));
            textView22.setPadding(0, 20, 0, 20);
            textView22.setGravity(17);
            textView22.setText(obj4);
            textView22.setTextSize(14.0f);
            textView22.setTypeface(textView22.getTypeface(), 1);
            textView22.setTextColor(Color.parseColor(str7));
            linearLayout32.addView(textView22);
            ImageView imageView2 = new ImageView(this);
            imageView2.setLayoutParams(new LinearLayout.LayoutParams(90, 90, 0.0f));
            imageView2.setPadding(0, 0, 0, 0);
            if (!this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyGzZZUTo6"), "").equals(StringFogImpl.decrypt("NiE1WVc4"))) {
            }
            linearLayout22.addView(imageView2);
            linearLayout22.setElevation(5.0f);
            linearLayout22.setTranslationY(30.0f);
            if (this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNEw="), "").equals(StringFogImpl.decrypt(str8))) {
            }
            if (this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KA=="), "").equals(StringFogImpl.decrypt(str8))) {
            }
            if (!this.UCSP.getString(StringFogImpl.decrypt("PCcFTFY2MSpMWjkx"), "").equals(StringFogImpl.decrypt("MzUqXl0="))) {
            }
            if (this.UCSP.getString(StringFogImpl.decrypt("OzExe10nJy9CVg=="), "").equals(str5)) {
            }
        } catch (Exception e) {
            SketchwareUtil.showMessage(getApplicationContext(), e.toString());
        }
    }

    @Deprecated
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, 0).show();
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    @Deprecated
    public int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList<Double> arrayList = new ArrayList<>();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf(checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int i) {
        return TypedValue.applyDimension(1, i, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
