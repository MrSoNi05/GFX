package com.bgm.gfx;

import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.github.megatronking.stringfog.xor.StringFogImpl;
import com.google.firebase.FirebaseApp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

/* loaded from: classes7.dex */
public class ColourGameActivity extends AppCompatActivity {
    private Button button1;
    private ImageView imageview1;
    private ImageView imageview10;
    private ImageView imageview11;
    private ImageView imageview12;
    private ImageView imageview13;
    private ImageView imageview14;
    private ImageView imageview15;
    private ImageView imageview16;
    private ImageView imageview2;
    private ImageView imageview3;
    private ImageView imageview4;
    private ImageView imageview5;
    private ImageView imageview6;
    private ImageView imageview7;
    private ImageView imageview8;
    private ImageView imageview9;
    private LinearLayout linear_1;
    private LinearLayout linear_10;
    private LinearLayout linear_11;
    private LinearLayout linear_12;
    private LinearLayout linear_13;
    private LinearLayout linear_14;
    private LinearLayout linear_15;
    private LinearLayout linear_16;
    private LinearLayout linear_2;
    private LinearLayout linear_3;
    private LinearLayout linear_4;
    private LinearLayout linear_5;
    private LinearLayout linear_6;
    private LinearLayout linear_7;
    private LinearLayout linear_8;
    private LinearLayout linear_9;
    private LinearLayout linear_box_1;
    private LinearLayout linear_box_2;
    private LinearLayout linear_box_3;
    private LinearLayout linear_box_4;
    private LinearLayout linear_main;
    private LinearLayout linear_score;
    private TextView textview1;
    private TextView textview2;
    private TextView textview3;
    private TextView textview5;
    private TextView textview_correct;
    private TextView textview_incorrect;
    private TimerTask timer;
    private Timer _timer = new Timer();
    private HashMap<String, Object> colours = new HashMap<>();
    private String Color_1 = "";
    private String Color_2 = "";
    private double position = 0.0d;
    private double Different_box = 0.0d;
    private double box_number = 0.0d;
    private double correct = 0.0d;
    private double incorrect = 0.0d;
    private String Green = "";
    private String Red = "";
    private ArrayList<HashMap<String, Object>> colors_list = new ArrayList<>();

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.colour_game);
        initialize(bundle);
          //   FirebaseApp.initializeApp(String.valueOf(this));
        initializeLogic();
    }

    private void initialize(Bundle bundle) {
        this.linear_main = (LinearLayout) findViewById(R.id.linear_main);
        this.linear_score = (LinearLayout) findViewById(R.id.linear_score);
        this.textview3 = (TextView) findViewById(R.id.textview3);
        this.linear_box_1 = (LinearLayout) findViewById(R.id.linear_box_1);
        this.linear_box_2 = (LinearLayout) findViewById(R.id.linear_box_2);
        this.linear_box_3 = (LinearLayout) findViewById(R.id.linear_box_3);
        this.linear_box_4 = (LinearLayout) findViewById(R.id.linear_box_4);
        this.button1 = (Button) findViewById(R.id.button1);
        this.textview5 = (TextView) findViewById(R.id.textview5);
        this.textview1 = (TextView) findViewById(R.id.textview1);
        this.textview_correct = (TextView) findViewById(R.id.textview_correct);
        this.textview2 = (TextView) findViewById(R.id.textview2);
        this.textview_incorrect = (TextView) findViewById(R.id.textview_incorrect);
        this.linear_1 = (LinearLayout) findViewById(R.id.linear_1);
        this.linear_2 = (LinearLayout) findViewById(R.id.linear_2);
        this.linear_3 = (LinearLayout) findViewById(R.id.linear_3);
        this.linear_4 = (LinearLayout) findViewById(R.id.linear_4);
        this.imageview1 = (ImageView) findViewById(R.id.imageview1);
        this.imageview2 = (ImageView) findViewById(R.id.imageview2);
        this.imageview3 = (ImageView) findViewById(R.id.imageview3);
        this.imageview4 = (ImageView) findViewById(R.id.imageview4);
        this.linear_5 = (LinearLayout) findViewById(R.id.linear_5);
        this.linear_6 = (LinearLayout) findViewById(R.id.linear_6);
        this.linear_7 = (LinearLayout) findViewById(R.id.linear_7);
        this.linear_8 = (LinearLayout) findViewById(R.id.linear_8);
        this.imageview5 = (ImageView) findViewById(R.id.imageview5);
        this.imageview6 = (ImageView) findViewById(R.id.imageview6);
        this.imageview7 = (ImageView) findViewById(R.id.imageview7);
        this.imageview8 = (ImageView) findViewById(R.id.imageview8);
        this.linear_9 = (LinearLayout) findViewById(R.id.linear_9);
        this.linear_10 = (LinearLayout) findViewById(R.id.linear_10);
        this.linear_11 = (LinearLayout) findViewById(R.id.linear_11);
        this.linear_12 = (LinearLayout) findViewById(R.id.linear_12);
        this.imageview9 = (ImageView) findViewById(R.id.imageview9);
        this.imageview10 = (ImageView) findViewById(R.id.imageview10);
        this.imageview11 = (ImageView) findViewById(R.id.imageview11);
        this.imageview12 = (ImageView) findViewById(R.id.imageview12);
        this.linear_13 = (LinearLayout) findViewById(R.id.linear_13);
        this.linear_14 = (LinearLayout) findViewById(R.id.linear_14);
        this.linear_15 = (LinearLayout) findViewById(R.id.linear_15);
        this.linear_16 = (LinearLayout) findViewById(R.id.linear_16);
        this.imageview13 = (ImageView) findViewById(R.id.imageview13);
        this.imageview14 = (ImageView) findViewById(R.id.imageview14);
        this.imageview15 = (ImageView) findViewById(R.id.imageview15);
        this.imageview16 = (ImageView) findViewById(R.id.imageview16);
        this.button1.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.ColourGameActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                ColourGameActivity.this._restart();
                ColourGameActivity.this.button1.setVisibility(4);
                ColourGameActivity.this.textview3.setVisibility(0);
            }
        });
        this.linear_1.setOnClickListener(new AnonymousClass2());
        this.linear_2.setOnClickListener(new AnonymousClass3());
        this.linear_3.setOnClickListener(new AnonymousClass4());
        this.linear_4.setOnClickListener(new AnonymousClass5());
        this.linear_5.setOnClickListener(new AnonymousClass6());
        this.linear_6.setOnClickListener(new AnonymousClass7());
        this.linear_7.setOnClickListener(new AnonymousClass8());
        this.linear_8.setOnClickListener(new AnonymousClass9());
        this.linear_9.setOnClickListener(new AnonymousClass10());
        this.linear_10.setOnClickListener(new AnonymousClass11());
        this.linear_11.setOnClickListener(new AnonymousClass12());
        this.linear_12.setOnClickListener(new AnonymousClass13());
        this.linear_13.setOnClickListener(new AnonymousClass14());
        this.linear_14.setOnClickListener(new AnonymousClass15());
        this.linear_15.setOnClickListener(new AnonymousClass16());
        this.linear_16.setOnClickListener(new AnonymousClass17());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.ColourGameActivity$2  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass2 implements View.OnClickListener {
        AnonymousClass2() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ColourGameActivity.this.box_number = 1.0d;
            if (ColourGameActivity.this.box_number == ColourGameActivity.this.Different_box) {
                ColourGameActivity.this.correct += 1.0d;
                ColourGameActivity.this.textview_correct.setText(String.valueOf((long) ColourGameActivity.this.correct));
                ColourGameActivity.this._correct_image();
            } else {
                ColourGameActivity.this.incorrect += 1.0d;
                ColourGameActivity.this.textview_incorrect.setText(String.valueOf((long) ColourGameActivity.this.incorrect));
                ColourGameActivity.this._correct_image();
                ColourGameActivity.this._wrong_image();
            }
            ColourGameActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.ColourGameActivity.2.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    ColourGameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.ColourGameActivity.2.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ColourGameActivity.this._restart();
                        }
                    });
                }
            };
            ColourGameActivity.this._timer.schedule(ColourGameActivity.this.timer, 3000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.ColourGameActivity$3  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass3 implements View.OnClickListener {
        AnonymousClass3() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ColourGameActivity.this.box_number = 2.0d;
            if (ColourGameActivity.this.box_number == ColourGameActivity.this.Different_box) {
                ColourGameActivity.this.correct += 1.0d;
                ColourGameActivity.this.textview_correct.setText(String.valueOf((long) ColourGameActivity.this.correct));
                ColourGameActivity.this._correct_image();
            } else {
                ColourGameActivity.this.incorrect += 1.0d;
                ColourGameActivity.this.textview_incorrect.setText(String.valueOf((long) ColourGameActivity.this.incorrect));
                ColourGameActivity.this._correct_image();
                ColourGameActivity.this._wrong_image();
            }
            ColourGameActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.ColourGameActivity.3.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    ColourGameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.ColourGameActivity.3.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ColourGameActivity.this._restart();
                        }
                    });
                }
            };
            ColourGameActivity.this._timer.schedule(ColourGameActivity.this.timer, 3000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.ColourGameActivity$4  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass4 implements View.OnClickListener {
        AnonymousClass4() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ColourGameActivity.this.box_number = 3.0d;
            if (ColourGameActivity.this.box_number == ColourGameActivity.this.Different_box) {
                ColourGameActivity.this.correct += 1.0d;
                ColourGameActivity.this.textview_correct.setText(String.valueOf((long) ColourGameActivity.this.correct));
                ColourGameActivity.this._correct_image();
            } else {
                ColourGameActivity.this.incorrect += 1.0d;
                ColourGameActivity.this.textview_incorrect.setText(String.valueOf((long) ColourGameActivity.this.incorrect));
                ColourGameActivity.this._correct_image();
                ColourGameActivity.this._wrong_image();
            }
            ColourGameActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.ColourGameActivity.4.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    ColourGameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.ColourGameActivity.4.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ColourGameActivity.this._restart();
                        }
                    });
                }
            };
            ColourGameActivity.this._timer.schedule(ColourGameActivity.this.timer, 3000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.ColourGameActivity$5  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass5 implements View.OnClickListener {
        AnonymousClass5() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ColourGameActivity.this.box_number = 4.0d;
            if (ColourGameActivity.this.box_number == ColourGameActivity.this.Different_box) {
                ColourGameActivity.this.correct += 1.0d;
                ColourGameActivity.this.textview_correct.setText(String.valueOf((long) ColourGameActivity.this.correct));
                ColourGameActivity.this._correct_image();
            } else {
                ColourGameActivity.this.incorrect += 1.0d;
                ColourGameActivity.this.textview_incorrect.setText(String.valueOf((long) ColourGameActivity.this.incorrect));
                ColourGameActivity.this._correct_image();
                ColourGameActivity.this._wrong_image();
            }
            ColourGameActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.ColourGameActivity.5.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    ColourGameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.ColourGameActivity.5.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ColourGameActivity.this._restart();
                        }
                    });
                }
            };
            ColourGameActivity.this._timer.schedule(ColourGameActivity.this.timer, 3000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.ColourGameActivity$6  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass6 implements View.OnClickListener {
        AnonymousClass6() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ColourGameActivity.this.box_number = 5.0d;
            if (ColourGameActivity.this.box_number == ColourGameActivity.this.Different_box) {
                ColourGameActivity.this.correct += 1.0d;
                ColourGameActivity.this.textview_correct.setText(String.valueOf((long) ColourGameActivity.this.correct));
                ColourGameActivity.this._correct_image();
            } else {
                ColourGameActivity.this.incorrect += 1.0d;
                ColourGameActivity.this.textview_incorrect.setText(String.valueOf((long) ColourGameActivity.this.incorrect));
                ColourGameActivity.this._correct_image();
                ColourGameActivity.this._wrong_image();
            }
            ColourGameActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.ColourGameActivity.6.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    ColourGameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.ColourGameActivity.6.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ColourGameActivity.this._restart();
                        }
                    });
                }
            };
            ColourGameActivity.this._timer.schedule(ColourGameActivity.this.timer, 3000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.ColourGameActivity$7  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass7 implements View.OnClickListener {
        AnonymousClass7() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ColourGameActivity.this.box_number = 6.0d;
            if (ColourGameActivity.this.box_number == ColourGameActivity.this.Different_box) {
                ColourGameActivity.this.correct += 1.0d;
                ColourGameActivity.this.textview_correct.setText(String.valueOf((long) ColourGameActivity.this.correct));
                ColourGameActivity.this._correct_image();
            } else {
                ColourGameActivity.this.incorrect += 1.0d;
                ColourGameActivity.this.textview_incorrect.setText(String.valueOf((long) ColourGameActivity.this.incorrect));
                ColourGameActivity.this._correct_image();
                ColourGameActivity.this._wrong_image();
            }
            ColourGameActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.ColourGameActivity.7.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    ColourGameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.ColourGameActivity.7.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ColourGameActivity.this._restart();
                        }
                    });
                }
            };
            ColourGameActivity.this._timer.schedule(ColourGameActivity.this.timer, 3000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.ColourGameActivity$8  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass8 implements View.OnClickListener {
        AnonymousClass8() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ColourGameActivity.this.box_number = 7.0d;
            if (ColourGameActivity.this.box_number == ColourGameActivity.this.Different_box) {
                ColourGameActivity.this.correct += 1.0d;
                ColourGameActivity.this.textview_correct.setText(String.valueOf((long) ColourGameActivity.this.correct));
                ColourGameActivity.this._correct_image();
            } else {
                ColourGameActivity.this.incorrect += 1.0d;
                ColourGameActivity.this.textview_incorrect.setText(String.valueOf((long) ColourGameActivity.this.incorrect));
                ColourGameActivity.this._correct_image();
                ColourGameActivity.this._wrong_image();
            }
            ColourGameActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.ColourGameActivity.8.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    ColourGameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.ColourGameActivity.8.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ColourGameActivity.this._restart();
                        }
                    });
                }
            };
            ColourGameActivity.this._timer.schedule(ColourGameActivity.this.timer, 3000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.ColourGameActivity$9  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass9 implements View.OnClickListener {
        AnonymousClass9() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ColourGameActivity.this.box_number = 8.0d;
            if (ColourGameActivity.this.box_number == ColourGameActivity.this.Different_box) {
                ColourGameActivity.this.correct += 1.0d;
                ColourGameActivity.this.textview_correct.setText(String.valueOf((long) ColourGameActivity.this.correct));
                ColourGameActivity.this._correct_image();
            } else {
                ColourGameActivity.this.incorrect += 1.0d;
                ColourGameActivity.this.textview_incorrect.setText(String.valueOf((long) ColourGameActivity.this.incorrect));
                ColourGameActivity.this._correct_image();
                ColourGameActivity.this._wrong_image();
            }
            ColourGameActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.ColourGameActivity.9.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    ColourGameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.ColourGameActivity.9.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ColourGameActivity.this._restart();
                        }
                    });
                }
            };
            ColourGameActivity.this._timer.schedule(ColourGameActivity.this.timer, 3000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.ColourGameActivity$10  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass10 implements View.OnClickListener {
        AnonymousClass10() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ColourGameActivity.this.box_number = 9.0d;
            if (ColourGameActivity.this.box_number == ColourGameActivity.this.Different_box) {
                ColourGameActivity.this.correct += 1.0d;
                ColourGameActivity.this.textview_correct.setText(String.valueOf((long) ColourGameActivity.this.correct));
                ColourGameActivity.this._correct_image();
            } else {
                ColourGameActivity.this.incorrect += 1.0d;
                ColourGameActivity.this.textview_incorrect.setText(String.valueOf((long) ColourGameActivity.this.incorrect));
                ColourGameActivity.this._correct_image();
                ColourGameActivity.this._wrong_image();
            }
            ColourGameActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.ColourGameActivity.10.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    ColourGameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.ColourGameActivity.10.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ColourGameActivity.this._restart();
                        }
                    });
                }
            };
            ColourGameActivity.this._timer.schedule(ColourGameActivity.this.timer, 3000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.ColourGameActivity$11  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass11 implements View.OnClickListener {
        AnonymousClass11() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ColourGameActivity.this.box_number = 10.0d;
            if (ColourGameActivity.this.box_number == ColourGameActivity.this.Different_box) {
                ColourGameActivity.this.correct += 1.0d;
                ColourGameActivity.this.textview_correct.setText(String.valueOf((long) ColourGameActivity.this.correct));
                ColourGameActivity.this._correct_image();
            } else {
                ColourGameActivity.this.incorrect += 1.0d;
                ColourGameActivity.this.textview_incorrect.setText(String.valueOf((long) ColourGameActivity.this.incorrect));
                ColourGameActivity.this._correct_image();
                ColourGameActivity.this._wrong_image();
            }
            ColourGameActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.ColourGameActivity.11.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    ColourGameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.ColourGameActivity.11.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ColourGameActivity.this._restart();
                        }
                    });
                }
            };
            ColourGameActivity.this._timer.schedule(ColourGameActivity.this.timer, 3000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.ColourGameActivity$12  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass12 implements View.OnClickListener {
        AnonymousClass12() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ColourGameActivity.this.box_number = 11.0d;
            if (ColourGameActivity.this.box_number == ColourGameActivity.this.Different_box) {
                ColourGameActivity.this.correct += 1.0d;
                ColourGameActivity.this.textview_correct.setText(String.valueOf((long) ColourGameActivity.this.correct));
                ColourGameActivity.this._correct_image();
            } else {
                ColourGameActivity.this.incorrect += 1.0d;
                ColourGameActivity.this.textview_incorrect.setText(String.valueOf((long) ColourGameActivity.this.incorrect));
                ColourGameActivity.this._correct_image();
                ColourGameActivity.this._wrong_image();
            }
            ColourGameActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.ColourGameActivity.12.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    ColourGameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.ColourGameActivity.12.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ColourGameActivity.this._restart();
                        }
                    });
                }
            };
            ColourGameActivity.this._timer.schedule(ColourGameActivity.this.timer, 3000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.ColourGameActivity$13  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass13 implements View.OnClickListener {
        AnonymousClass13() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ColourGameActivity.this.box_number = 12.0d;
            if (ColourGameActivity.this.box_number == ColourGameActivity.this.Different_box) {
                ColourGameActivity.this.correct += 1.0d;
                ColourGameActivity.this.textview_correct.setText(String.valueOf((long) ColourGameActivity.this.correct));
                ColourGameActivity.this._correct_image();
            } else {
                ColourGameActivity.this.incorrect += 1.0d;
                ColourGameActivity.this.textview_incorrect.setText(String.valueOf((long) ColourGameActivity.this.incorrect));
                ColourGameActivity.this._correct_image();
                ColourGameActivity.this._wrong_image();
            }
            ColourGameActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.ColourGameActivity.13.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    ColourGameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.ColourGameActivity.13.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ColourGameActivity.this._restart();
                        }
                    });
                }
            };
            ColourGameActivity.this._timer.schedule(ColourGameActivity.this.timer, 3000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.ColourGameActivity$14  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass14 implements View.OnClickListener {
        AnonymousClass14() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ColourGameActivity.this.box_number = 13.0d;
            if (ColourGameActivity.this.box_number == ColourGameActivity.this.Different_box) {
                ColourGameActivity.this.correct += 1.0d;
                ColourGameActivity.this.textview_correct.setText(String.valueOf((long) ColourGameActivity.this.correct));
                ColourGameActivity.this._correct_image();
            } else {
                ColourGameActivity.this.incorrect += 1.0d;
                ColourGameActivity.this.textview_incorrect.setText(String.valueOf((long) ColourGameActivity.this.incorrect));
                ColourGameActivity.this._correct_image();
                ColourGameActivity.this._wrong_image();
            }
            ColourGameActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.ColourGameActivity.14.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    ColourGameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.ColourGameActivity.14.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ColourGameActivity.this._restart();
                        }
                    });
                }
            };
            ColourGameActivity.this._timer.schedule(ColourGameActivity.this.timer, 3000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.ColourGameActivity$15  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass15 implements View.OnClickListener {
        AnonymousClass15() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ColourGameActivity.this.box_number = 14.0d;
            if (ColourGameActivity.this.box_number == ColourGameActivity.this.Different_box) {
                ColourGameActivity.this.correct += 1.0d;
                ColourGameActivity.this.textview_correct.setText(String.valueOf((long) ColourGameActivity.this.correct));
                ColourGameActivity.this._correct_image();
            } else {
                ColourGameActivity.this.incorrect += 1.0d;
                ColourGameActivity.this.textview_incorrect.setText(String.valueOf((long) ColourGameActivity.this.incorrect));
                ColourGameActivity.this._correct_image();
                ColourGameActivity.this._wrong_image();
            }
            ColourGameActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.ColourGameActivity.15.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    ColourGameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.ColourGameActivity.15.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ColourGameActivity.this._restart();
                        }
                    });
                }
            };
            ColourGameActivity.this._timer.schedule(ColourGameActivity.this.timer, 3000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.ColourGameActivity$16  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass16 implements View.OnClickListener {
        AnonymousClass16() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ColourGameActivity.this.box_number = 15.0d;
            if (ColourGameActivity.this.box_number == ColourGameActivity.this.Different_box) {
                ColourGameActivity.this.correct += 1.0d;
                ColourGameActivity.this.textview_correct.setText(String.valueOf((long) ColourGameActivity.this.correct));
                ColourGameActivity.this._correct_image();
            } else {
                ColourGameActivity.this.incorrect += 1.0d;
                ColourGameActivity.this.textview_incorrect.setText(String.valueOf((long) ColourGameActivity.this.incorrect));
                ColourGameActivity.this._correct_image();
                ColourGameActivity.this._wrong_image();
            }
            ColourGameActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.ColourGameActivity.16.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    ColourGameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.ColourGameActivity.16.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ColourGameActivity.this._restart();
                        }
                    });
                }
            };
            ColourGameActivity.this._timer.schedule(ColourGameActivity.this.timer, 3000L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.ColourGameActivity$17  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass17 implements View.OnClickListener {
        AnonymousClass17() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            ColourGameActivity.this.box_number = 16.0d;
            if (ColourGameActivity.this.box_number == ColourGameActivity.this.Different_box) {
                ColourGameActivity.this.correct += 1.0d;
                ColourGameActivity.this.textview_correct.setText(String.valueOf((long) ColourGameActivity.this.correct));
                ColourGameActivity.this._correct_image();
            } else {
                ColourGameActivity.this.incorrect += 1.0d;
                ColourGameActivity.this.textview_incorrect.setText(String.valueOf((long) ColourGameActivity.this.incorrect));
                ColourGameActivity.this._correct_image();
                ColourGameActivity.this._wrong_image();
            }
            ColourGameActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.ColourGameActivity.17.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    ColourGameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.ColourGameActivity.17.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            ColourGameActivity.this._restart();
                        }
                    });
                }
            };
            ColourGameActivity.this._timer.schedule(ColourGameActivity.this.timer, 3000L);
        }
    }

    private void initializeLogic() {
        this.correct = 0.0d;
        this.incorrect = 0.0d;
        this.textview_correct.setText(String.valueOf((long) 0.0d));
        this.textview_incorrect.setText(String.valueOf((long) this.incorrect));
        this.imageview1.setVisibility(4);
        this.imageview2.setVisibility(4);
        this.imageview3.setVisibility(4);
        this.imageview4.setVisibility(4);
        this.imageview5.setVisibility(4);
        this.imageview6.setVisibility(4);
        this.imageview7.setVisibility(4);
        this.imageview8.setVisibility(4);
        this.imageview9.setVisibility(4);
        this.imageview10.setVisibility(4);
        this.imageview11.setVisibility(4);
        this.imageview12.setVisibility(4);
        this.imageview13.setVisibility(4);
        this.imageview14.setVisibility(4);
        this.imageview15.setVisibility(4);
        this.imageview16.setVisibility(4);
        this.textview3.setVisibility(4);
        _disable();
        _UI();
    }

    public void _Corner_Reduce(double d, double d2, double d3, String str, String str2, View view) {
        float f = (float) d3;
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(Color.parseColor(str2));
        gradientDrawable.setCornerRadius((float) d);
        gradientDrawable.setStroke((int) d2, Color.parseColor(str));
        view.setBackground(gradientDrawable);
        view.setElevation(f);
    }

    public void _colors() {
        this.colours.clear();
        this.colors_list.clear();
        HashMap<String, Object> hashMap = new HashMap<>();
        this.colours = hashMap;
        hashMap.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dhJyGQtmYg=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dhFzHgFmYQ=="));
        this.colors_list.add(this.colours);
        HashMap<String, Object> hashMap2 = new HashMap<>();
        this.colours = hashMap2;
        hashMap2.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dhF/HH1jZw=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dhEFGQhiFQ=="));
        this.colors_list.add(this.colours);
        HashMap<String, Object> hashMap3 = new HashMap<>();
        this.colours = hashMap3;
        hashMap3.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dm0FHw8XZA=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dhUEGQ8XFw=="));
        this.colors_list.add(this.colours);
        HashMap<String, Object> hashMap4 = new HashMap<>();
        this.colours = hashMap4;
        hashMap4.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dmJxHnkXYw=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dmEDHg0XZQ=="));
        this.colors_list.add(this.colours);
        HashMap<String, Object> hashMap5 = new HashMap<>();
        this.colours = hashMap5;
        hashMap5.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dmcAGAkXYQ=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dmEFG3oWZA=="));
        this.colors_list.add(this.colours);
        HashMap<String, Object> hashMap6 = new HashMap<>();
        this.colours = hashMap6;
        hashMap6.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dmZ3FA4TZw=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dmUDFQAQYQ=="));
        this.colors_list.add(this.colours);
        HashMap<String, Object> hashMap7 = new HashMap<>();
        this.colours = hashMap7;
        hashMap7.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dmR1bAETYA=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dmR1FHoQYQ=="));
        this.colors_list.add(this.colours);
        HashMap<String, Object> hashMap8 = new HashMap<>();
        this.colours = hashMap8;
        hashMap8.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dmR2b3sRYA=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dmZwbg4RFQ=="));
        this.colors_list.add(this.colours);
        HashMap<String, Object> hashMap9 = new HashMap<>();
        this.colours = hashMap9;
        hashMap9.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dmAFbH5gZA=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dmB1bAhhYw=="));
        this.colors_list.add(this.colours);
        HashMap<String, Object> hashMap10 = new HashMap<>();
        this.colours = hashMap10;
        hashMap10.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dmwEbgthFQ=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dm0FbntjYQ=="));
        this.colors_list.add(this.colours);
        HashMap<String, Object> hashMap11 = new HashMap<>();
        this.colours = hashMap11;
        hashMap11.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dhcCaXtmbQ=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dhByaAlgYg=="));
        this.colors_list.add(this.colours);
        HashMap<String, Object> hashMap12 = new HashMap<>();
        this.colours = hashMap12;
        hashMap12.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dhIAaHpmFg=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dhIAawliYg=="));
        this.colors_list.add(this.colours);
        HashMap<String, Object> hashMap13 = new HashMap<>();
        this.colours = hashMap13;
        hashMap13.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dhIAbgllYw=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dhIAbwtlZA=="));
        this.colors_list.add(this.colours);
        HashMap<String, Object> hashMap14 = new HashMap<>();
        this.colours = hashMap14;
        hashMap14.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dhIAFABlZA=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dhIAbA9nYg=="));
        this.colors_list.add(this.colours);
        HashMap<String, Object> hashMap15 = new HashMap<>();
        this.colours = hashMap15;
        hashMap15.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dhIAGA9nZg=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dhJyGAlkEQ=="));
        this.colors_list.add(this.colours);
        HashMap<String, Object> hashMap16 = new HashMap<>();
        this.colours = hashMap16;
        hashMap16.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dmN+GA1hbA=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dmICGXthZQ=="));
        this.colors_list.add(this.colours);
        HashMap<String, Object> hashMap17 = new HashMap<>();
        this.colours = hashMap17;
        hashMap17.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dm0DFH1sEQ=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dhYCb3wXEA=="));
        this.colors_list.add(this.colours);
        HashMap<String, Object> hashMap18 = new HashMap<>();
        this.colours = hashMap18;
        hashMap18.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dmJ2GnxtFg=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dmN+FAhsFw=="));
        this.colors_list.add(this.colours);
        HashMap<String, Object> hashMap19 = new HashMap<>();
        this.colours = hashMap19;
        hashMap19.put(StringFogImpl.decrypt("NjsqQkpk"), StringFogImpl.decrypt("dmR2FA5tbA=="));
        this.colours.put(StringFogImpl.decrypt("NjsqQkoKZg=="), StringFogImpl.decrypt("dmZwbA5sFQ=="));
        this.colors_list.add(this.colours);
    }

    public void _Set_Colors() {
        double random = SketchwareUtil.getRandom(0, 18);
        this.position = random;
        this.Color_1 = this.colors_list.get((int) random).get(StringFogImpl.decrypt("NjsqQkpk")).toString();
        this.Color_2 = this.colors_list.get((int) this.position).get(StringFogImpl.decrypt("NjsqQkoKZg==")).toString();
        this.Different_box = SketchwareUtil.getRandom(1, 16);
        _set_different_box_color();
        _set_other_box_color();
    }

    public void _set_different_box_color() {
        if (this.Different_box == 1.0d) {
            String str = this.Color_2;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str, str, this.linear_1);
        }
        if (this.Different_box == 2.0d) {
            String str2 = this.Color_2;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str2, str2, this.linear_2);
        }
        if (this.Different_box == 3.0d) {
            String str3 = this.Color_2;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str3, str3, this.linear_3);
        }
        if (this.Different_box == 4.0d) {
            String str4 = this.Color_2;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str4, str4, this.linear_4);
        }
        if (this.Different_box == 5.0d) {
            String str5 = this.Color_2;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str5, str5, this.linear_5);
        }
        if (this.Different_box == 6.0d) {
            String str6 = this.Color_2;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str6, str6, this.linear_6);
        }
        if (this.Different_box == 7.0d) {
            String str7 = this.Color_2;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str7, str7, this.linear_7);
        }
        if (this.Different_box == 8.0d) {
            String str8 = this.Color_2;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str8, str8, this.linear_8);
        }
        if (this.Different_box == 9.0d) {
            String str9 = this.Color_2;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str9, str9, this.linear_9);
        }
        if (this.Different_box == 10.0d) {
            String str10 = this.Color_2;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str10, str10, this.linear_10);
        }
        if (this.Different_box == 11.0d) {
            String str11 = this.Color_2;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str11, str11, this.linear_11);
        }
        if (this.Different_box == 12.0d) {
            String str12 = this.Color_2;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str12, str12, this.linear_12);
        }
        if (this.Different_box == 13.0d) {
            String str13 = this.Color_2;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str13, str13, this.linear_13);
        }
        if (this.Different_box == 14.0d) {
            String str14 = this.Color_2;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str14, str14, this.linear_14);
        }
        if (this.Different_box == 15.0d) {
            String str15 = this.Color_2;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str15, str15, this.linear_15);
        }
        if (this.Different_box == 16.0d) {
            String str16 = this.Color_2;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str16, str16, this.linear_16);
        }
    }

    public void _set_other_box_color() {
        if (this.Different_box == 1.0d) {
            String str = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str, str, this.linear_2);
            String str2 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str2, str2, this.linear_3);
            String str3 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str3, str3, this.linear_4);
            String str4 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str4, str4, this.linear_5);
            String str5 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str5, str5, this.linear_6);
            String str6 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str6, str6, this.linear_7);
            String str7 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str7, str7, this.linear_8);
            String str8 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str8, str8, this.linear_9);
            String str9 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str9, str9, this.linear_10);
            String str10 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str10, str10, this.linear_11);
            String str11 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str11, str11, this.linear_12);
            String str12 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str12, str12, this.linear_13);
            String str13 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str13, str13, this.linear_14);
            String str14 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str14, str14, this.linear_15);
            String str15 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str15, str15, this.linear_16);
        }
        if (this.Different_box == 2.0d) {
            String str16 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str16, str16, this.linear_1);
            String str17 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str17, str17, this.linear_3);
            String str18 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str18, str18, this.linear_4);
            String str19 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str19, str19, this.linear_5);
            String str20 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str20, str20, this.linear_6);
            String str21 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str21, str21, this.linear_7);
            String str22 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str22, str22, this.linear_8);
            String str23 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str23, str23, this.linear_9);
            String str24 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str24, str24, this.linear_10);
            String str25 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str25, str25, this.linear_11);
            String str26 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str26, str26, this.linear_12);
            String str27 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str27, str27, this.linear_13);
            String str28 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str28, str28, this.linear_14);
            String str29 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str29, str29, this.linear_15);
            String str30 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str30, str30, this.linear_16);
        }
        if (this.Different_box == 3.0d) {
            String str31 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str31, str31, this.linear_1);
            String str32 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str32, str32, this.linear_2);
            String str33 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str33, str33, this.linear_4);
            String str34 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str34, str34, this.linear_5);
            String str35 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str35, str35, this.linear_6);
            String str36 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str36, str36, this.linear_7);
            String str37 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str37, str37, this.linear_8);
            String str38 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str38, str38, this.linear_9);
            String str39 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str39, str39, this.linear_10);
            String str40 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str40, str40, this.linear_11);
            String str41 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str41, str41, this.linear_12);
            String str42 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str42, str42, this.linear_13);
            String str43 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str43, str43, this.linear_14);
            String str44 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str44, str44, this.linear_15);
            String str45 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str45, str45, this.linear_16);
        }
        if (this.Different_box == 4.0d) {
            String str46 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str46, str46, this.linear_1);
            String str47 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str47, str47, this.linear_2);
            String str48 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str48, str48, this.linear_3);
            String str49 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str49, str49, this.linear_5);
            String str50 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str50, str50, this.linear_6);
            String str51 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str51, str51, this.linear_7);
            String str52 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str52, str52, this.linear_8);
            String str53 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str53, str53, this.linear_9);
            String str54 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str54, str54, this.linear_10);
            String str55 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str55, str55, this.linear_11);
            String str56 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str56, str56, this.linear_12);
            String str57 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str57, str57, this.linear_13);
            String str58 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str58, str58, this.linear_14);
            String str59 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str59, str59, this.linear_15);
            String str60 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str60, str60, this.linear_16);
        }
        if (this.Different_box == 5.0d) {
            String str61 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str61, str61, this.linear_1);
            String str62 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str62, str62, this.linear_2);
            String str63 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str63, str63, this.linear_3);
            String str64 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str64, str64, this.linear_4);
            String str65 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str65, str65, this.linear_6);
            String str66 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str66, str66, this.linear_7);
            String str67 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str67, str67, this.linear_8);
            String str68 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str68, str68, this.linear_9);
            String str69 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str69, str69, this.linear_10);
            String str70 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str70, str70, this.linear_11);
            String str71 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str71, str71, this.linear_12);
            String str72 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str72, str72, this.linear_13);
            String str73 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str73, str73, this.linear_14);
            String str74 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str74, str74, this.linear_15);
            String str75 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str75, str75, this.linear_16);
        }
        if (this.Different_box == 6.0d) {
            String str76 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str76, str76, this.linear_1);
            String str77 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str77, str77, this.linear_2);
            String str78 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str78, str78, this.linear_3);
            String str79 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str79, str79, this.linear_4);
            String str80 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str80, str80, this.linear_5);
            String str81 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str81, str81, this.linear_7);
            String str82 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str82, str82, this.linear_8);
            String str83 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str83, str83, this.linear_9);
            String str84 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str84, str84, this.linear_10);
            String str85 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str85, str85, this.linear_11);
            String str86 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str86, str86, this.linear_12);
            String str87 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str87, str87, this.linear_13);
            String str88 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str88, str88, this.linear_14);
            String str89 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str89, str89, this.linear_15);
            String str90 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str90, str90, this.linear_16);
        }
        if (this.Different_box == 7.0d) {
            String str91 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str91, str91, this.linear_1);
            String str92 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str92, str92, this.linear_2);
            String str93 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str93, str93, this.linear_3);
            String str94 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str94, str94, this.linear_4);
            String str95 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str95, str95, this.linear_5);
            String str96 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str96, str96, this.linear_6);
            String str97 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str97, str97, this.linear_8);
            String str98 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str98, str98, this.linear_9);
            String str99 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str99, str99, this.linear_10);
            String str100 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str100, str100, this.linear_11);
            String str101 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str101, str101, this.linear_12);
            String str102 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str102, str102, this.linear_13);
            String str103 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str103, str103, this.linear_14);
            String str104 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str104, str104, this.linear_15);
            String str105 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str105, str105, this.linear_16);
        }
        if (this.Different_box == 8.0d) {
            String str106 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str106, str106, this.linear_1);
            String str107 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str107, str107, this.linear_2);
            String str108 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str108, str108, this.linear_3);
            String str109 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str109, str109, this.linear_4);
            String str110 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str110, str110, this.linear_5);
            String str111 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str111, str111, this.linear_6);
            String str112 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str112, str112, this.linear_7);
            String str113 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str113, str113, this.linear_9);
            String str114 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str114, str114, this.linear_10);
            String str115 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str115, str115, this.linear_11);
            String str116 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str116, str116, this.linear_12);
            String str117 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str117, str117, this.linear_13);
            String str118 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str118, str118, this.linear_14);
            String str119 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str119, str119, this.linear_15);
            String str120 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str120, str120, this.linear_16);
        }
        if (this.Different_box == 9.0d) {
            String str121 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str121, str121, this.linear_1);
            String str122 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str122, str122, this.linear_2);
            String str123 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str123, str123, this.linear_3);
            String str124 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str124, str124, this.linear_4);
            String str125 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str125, str125, this.linear_5);
            String str126 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str126, str126, this.linear_6);
            String str127 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str127, str127, this.linear_7);
            String str128 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str128, str128, this.linear_8);
            String str129 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str129, str129, this.linear_10);
            String str130 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str130, str130, this.linear_11);
            String str131 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str131, str131, this.linear_12);
            String str132 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str132, str132, this.linear_13);
            String str133 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str133, str133, this.linear_14);
            String str134 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str134, str134, this.linear_15);
            String str135 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str135, str135, this.linear_16);
        }
        if (this.Different_box == 10.0d) {
            String str136 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str136, str136, this.linear_1);
            String str137 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str137, str137, this.linear_2);
            String str138 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str138, str138, this.linear_3);
            String str139 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str139, str139, this.linear_4);
            String str140 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str140, str140, this.linear_5);
            String str141 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str141, str141, this.linear_6);
            String str142 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str142, str142, this.linear_7);
            String str143 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str143, str143, this.linear_8);
            String str144 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str144, str144, this.linear_9);
            String str145 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str145, str145, this.linear_11);
            String str146 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str146, str146, this.linear_12);
            String str147 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str147, str147, this.linear_13);
            String str148 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str148, str148, this.linear_14);
            String str149 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str149, str149, this.linear_15);
            String str150 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str150, str150, this.linear_16);
        }
        if (this.Different_box == 11.0d) {
            String str151 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str151, str151, this.linear_1);
            String str152 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str152, str152, this.linear_2);
            String str153 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str153, str153, this.linear_3);
            String str154 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str154, str154, this.linear_4);
            String str155 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str155, str155, this.linear_5);
            String str156 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str156, str156, this.linear_6);
            String str157 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str157, str157, this.linear_7);
            String str158 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str158, str158, this.linear_8);
            String str159 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str159, str159, this.linear_9);
            String str160 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str160, str160, this.linear_10);
            String str161 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str161, str161, this.linear_12);
            String str162 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str162, str162, this.linear_13);
            String str163 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str163, str163, this.linear_14);
            String str164 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str164, str164, this.linear_15);
            String str165 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str165, str165, this.linear_16);
        }
        if (this.Different_box == 12.0d) {
            String str166 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str166, str166, this.linear_1);
            String str167 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str167, str167, this.linear_2);
            String str168 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str168, str168, this.linear_3);
            String str169 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str169, str169, this.linear_4);
            String str170 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str170, str170, this.linear_5);
            String str171 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str171, str171, this.linear_6);
            String str172 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str172, str172, this.linear_7);
            String str173 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str173, str173, this.linear_8);
            String str174 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str174, str174, this.linear_9);
            String str175 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str175, str175, this.linear_10);
            String str176 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str176, str176, this.linear_11);
            String str177 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str177, str177, this.linear_13);
            String str178 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str178, str178, this.linear_14);
            String str179 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str179, str179, this.linear_15);
            String str180 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str180, str180, this.linear_16);
        }
        if (this.Different_box == 13.0d) {
            String str181 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str181, str181, this.linear_1);
            String str182 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str182, str182, this.linear_2);
            String str183 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str183, str183, this.linear_3);
            String str184 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str184, str184, this.linear_4);
            String str185 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str185, str185, this.linear_5);
            String str186 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str186, str186, this.linear_6);
            String str187 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str187, str187, this.linear_7);
            String str188 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str188, str188, this.linear_8);
            String str189 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str189, str189, this.linear_9);
            String str190 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str190, str190, this.linear_10);
            String str191 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str191, str191, this.linear_11);
            String str192 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str192, str192, this.linear_12);
            String str193 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str193, str193, this.linear_14);
            String str194 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str194, str194, this.linear_15);
            String str195 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str195, str195, this.linear_16);
        }
        if (this.Different_box == 14.0d) {
            String str196 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str196, str196, this.linear_1);
            String str197 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str197, str197, this.linear_2);
            String str198 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str198, str198, this.linear_3);
            String str199 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str199, str199, this.linear_4);
            String str200 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str200, str200, this.linear_5);
            String str201 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str201, str201, this.linear_6);
            String str202 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str202, str202, this.linear_7);
            String str203 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str203, str203, this.linear_8);
            String str204 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str204, str204, this.linear_9);
            String str205 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str205, str205, this.linear_10);
            String str206 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str206, str206, this.linear_11);
            String str207 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str207, str207, this.linear_12);
            String str208 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str208, str208, this.linear_13);
            String str209 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str209, str209, this.linear_15);
            String str210 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str210, str210, this.linear_16);
        }
        if (this.Different_box == 15.0d) {
            String str211 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str211, str211, this.linear_1);
            String str212 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str212, str212, this.linear_2);
            String str213 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str213, str213, this.linear_3);
            String str214 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str214, str214, this.linear_4);
            String str215 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str215, str215, this.linear_5);
            String str216 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str216, str216, this.linear_6);
            String str217 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str217, str217, this.linear_7);
            String str218 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str218, str218, this.linear_8);
            String str219 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str219, str219, this.linear_9);
            String str220 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str220, str220, this.linear_10);
            String str221 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str221, str221, this.linear_11);
            String str222 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str222, str222, this.linear_12);
            String str223 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str223, str223, this.linear_13);
            String str224 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str224, str224, this.linear_14);
            String str225 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str225, str225, this.linear_16);
        }
        if (this.Different_box == 16.0d) {
            String str226 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str226, str226, this.linear_1);
            String str227 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str227, str227, this.linear_2);
            String str228 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str228, str228, this.linear_3);
            String str229 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str229, str229, this.linear_4);
            String str230 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str230, str230, this.linear_5);
            String str231 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str231, str231, this.linear_6);
            String str232 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str232, str232, this.linear_7);
            String str233 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str233, str233, this.linear_8);
            String str234 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str234, str234, this.linear_9);
            String str235 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str235, str235, this.linear_10);
            String str236 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str236, str236, this.linear_11);
            String str237 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str237, str237, this.linear_12);
            String str238 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str238, str238, this.linear_13);
            String str239 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str239, str239, this.linear_14);
            String str240 = this.Color_1;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str240, str240, this.linear_15);
        }
    }

    public void _restart() {
        this.imageview1.setVisibility(4);
        this.imageview2.setVisibility(4);
        this.imageview3.setVisibility(4);
        this.imageview4.setVisibility(4);
        this.imageview5.setVisibility(4);
        this.imageview6.setVisibility(4);
        this.imageview7.setVisibility(4);
        this.imageview8.setVisibility(4);
        this.imageview9.setVisibility(4);
        this.imageview10.setVisibility(4);
        this.imageview11.setVisibility(4);
        this.imageview12.setVisibility(4);
        this.imageview13.setVisibility(4);
        this.imageview14.setVisibility(4);
        this.imageview15.setVisibility(4);
        this.imageview16.setVisibility(4);
        _enable();
        _colors();
        _Set_Colors();
    }

    public void _correct_image() {
        _disable();
        this.Green = StringFogImpl.decrypt("dmAFbH5gZA==");
        if (this.Different_box == 1.0d) {
            this.imageview1.setVisibility(0);
            this.imageview1.setImageResource(R.drawable.ic_done_white);
            String str = this.Green;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str, str, this.linear_1);
        }
        if (this.Different_box == 2.0d) {
            this.imageview2.setVisibility(0);
            this.imageview2.setImageResource(R.drawable.ic_done_white);
            String str2 = this.Green;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str2, str2, this.linear_2);
        }
        if (this.Different_box == 3.0d) {
            this.imageview3.setVisibility(0);
            this.imageview3.setImageResource(R.drawable.ic_done_white);
            String str3 = this.Green;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str3, str3, this.linear_3);
        }
        if (this.Different_box == 4.0d) {
            this.imageview4.setVisibility(0);
            this.imageview4.setImageResource(R.drawable.ic_done_white);
            String str4 = this.Green;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str4, str4, this.linear_4);
        }
        if (this.Different_box == 5.0d) {
            this.imageview5.setVisibility(0);
            this.imageview5.setImageResource(R.drawable.ic_done_white);
            String str5 = this.Green;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str5, str5, this.linear_5);
        }
        if (this.Different_box == 6.0d) {
            this.imageview6.setVisibility(0);
            this.imageview6.setImageResource(R.drawable.ic_done_white);
            String str6 = this.Green;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str6, str6, this.linear_6);
        }
        if (this.Different_box == 7.0d) {
            this.imageview7.setVisibility(0);
            this.imageview7.setImageResource(R.drawable.ic_done_white);
            String str7 = this.Green;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str7, str7, this.linear_7);
        }
        if (this.Different_box == 8.0d) {
            this.imageview8.setVisibility(0);
            this.imageview8.setImageResource(R.drawable.ic_done_white);
            String str8 = this.Green;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str8, str8, this.linear_8);
        }
        if (this.Different_box == 9.0d) {
            this.imageview9.setVisibility(0);
            this.imageview9.setImageResource(R.drawable.ic_done_white);
            String str9 = this.Green;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str9, str9, this.linear_9);
        }
        if (this.Different_box == 10.0d) {
            this.imageview10.setVisibility(0);
            this.imageview10.setImageResource(R.drawable.ic_done_white);
            String str10 = this.Green;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str10, str10, this.linear_10);
        }
        if (this.Different_box == 11.0d) {
            this.imageview11.setVisibility(0);
            this.imageview11.setImageResource(R.drawable.ic_done_white);
            String str11 = this.Green;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str11, str11, this.linear_11);
        }
        if (this.Different_box == 12.0d) {
            this.imageview12.setVisibility(0);
            this.imageview12.setImageResource(R.drawable.ic_done_white);
            String str12 = this.Green;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str12, str12, this.linear_12);
        }
        if (this.Different_box == 13.0d) {
            this.imageview13.setVisibility(0);
            this.imageview13.setImageResource(R.drawable.ic_done_white);
            String str13 = this.Green;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str13, str13, this.linear_13);
        }
        if (this.Different_box == 14.0d) {
            this.imageview14.setVisibility(0);
            this.imageview14.setImageResource(R.drawable.ic_done_white);
            String str14 = this.Green;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str14, str14, this.linear_14);
        }
        if (this.Different_box == 15.0d) {
            this.imageview15.setVisibility(0);
            this.imageview15.setImageResource(R.drawable.ic_done_white);
            String str15 = this.Green;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str15, str15, this.linear_15);
        }
        if (this.Different_box == 16.0d) {
            this.imageview16.setVisibility(0);
            this.imageview16.setImageResource(R.drawable.ic_done_white);
            String str16 = this.Green;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str16, str16, this.linear_16);
        }
    }

    public void _wrong_image() {
        this.Red = StringFogImpl.decrypt("dhJyGQtmYg==");
        if (this.box_number == 1.0d) {
            this.imageview1.setVisibility(0);
            this.imageview1.setImageResource(R.drawable.ic_close_white);
            String str = this.Red;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str, str, this.linear_1);
        }
        if (this.box_number == 2.0d) {
            this.imageview2.setVisibility(0);
            this.imageview2.setImageResource(R.drawable.ic_close_white);
            String str2 = this.Red;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str2, str2, this.linear_2);
        }
        if (this.box_number == 3.0d) {
            this.imageview3.setVisibility(0);
            this.imageview3.setImageResource(R.drawable.ic_close_white);
            String str3 = this.Red;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str3, str3, this.linear_3);
        }
        if (this.box_number == 4.0d) {
            this.imageview4.setVisibility(0);
            this.imageview4.setImageResource(R.drawable.ic_close_white);
            String str4 = this.Red;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str4, str4, this.linear_4);
        }
        if (this.box_number == 5.0d) {
            this.imageview5.setVisibility(0);
            this.imageview5.setImageResource(R.drawable.ic_close_white);
            String str5 = this.Red;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str5, str5, this.linear_5);
        }
        if (this.box_number == 6.0d) {
            this.imageview6.setVisibility(0);
            this.imageview6.setImageResource(R.drawable.ic_close_white);
            String str6 = this.Red;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str6, str6, this.linear_6);
        }
        if (this.box_number == 7.0d) {
            this.imageview7.setVisibility(0);
            this.imageview7.setImageResource(R.drawable.ic_close_white);
            String str7 = this.Red;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str7, str7, this.linear_7);
        }
        if (this.box_number == 8.0d) {
            this.imageview8.setVisibility(0);
            this.imageview8.setImageResource(R.drawable.ic_close_white);
            String str8 = this.Red;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str8, str8, this.linear_8);
        }
        if (this.box_number == 9.0d) {
            this.imageview9.setVisibility(0);
            this.imageview9.setImageResource(R.drawable.ic_close_white);
            String str9 = this.Red;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str9, str9, this.linear_9);
        }
        if (this.box_number == 10.0d) {
            this.imageview10.setVisibility(0);
            this.imageview10.setImageResource(R.drawable.ic_close_white);
            String str10 = this.Red;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str10, str10, this.linear_10);
        }
        if (this.box_number == 11.0d) {
            this.imageview11.setVisibility(0);
            this.imageview11.setImageResource(R.drawable.ic_close_white);
            String str11 = this.Red;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str11, str11, this.linear_11);
        }
        if (this.box_number == 12.0d) {
            this.imageview12.setVisibility(0);
            this.imageview12.setImageResource(R.drawable.ic_close_white);
            String str12 = this.Red;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str12, str12, this.linear_12);
        }
        if (this.box_number == 13.0d) {
            this.imageview13.setVisibility(0);
            this.imageview13.setImageResource(R.drawable.ic_close_white);
            String str13 = this.Red;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str13, str13, this.linear_13);
        }
        if (this.box_number == 14.0d) {
            this.imageview14.setVisibility(0);
            this.imageview14.setImageResource(R.drawable.ic_close_white);
            String str14 = this.Red;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str14, str14, this.linear_14);
        }
        if (this.box_number == 15.0d) {
            this.imageview15.setVisibility(0);
            this.imageview15.setImageResource(R.drawable.ic_close_white);
            String str15 = this.Red;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str15, str15, this.linear_15);
        }
        if (this.box_number == 16.0d) {
            this.imageview16.setVisibility(0);
            this.imageview16.setImageResource(R.drawable.ic_close_white);
            String str16 = this.Red;
            _Corner_Reduce(10.0d, 0.0d, 0.0d, str16, str16, this.linear_16);
        }
    }

    public void _enable() {
        this.linear_1.setEnabled(true);
        this.linear_2.setEnabled(true);
        this.linear_3.setEnabled(true);
        this.linear_4.setEnabled(true);
        this.linear_5.setEnabled(true);
        this.linear_6.setEnabled(true);
        this.linear_7.setEnabled(true);
        this.linear_8.setEnabled(true);
        this.linear_9.setEnabled(true);
        this.linear_10.setEnabled(true);
        this.linear_11.setEnabled(true);
        this.linear_12.setEnabled(true);
        this.linear_13.setEnabled(true);
        this.linear_14.setEnabled(true);
        this.linear_15.setEnabled(true);
        this.linear_16.setEnabled(true);
    }

    public void _disable() {
        this.linear_1.setEnabled(false);
        this.linear_2.setEnabled(false);
        this.linear_3.setEnabled(false);
        this.linear_4.setEnabled(false);
        this.linear_5.setEnabled(false);
        this.linear_6.setEnabled(false);
        this.linear_7.setEnabled(false);
        this.linear_8.setEnabled(false);
        this.linear_9.setEnabled(false);
        this.linear_10.setEnabled(false);
        this.linear_11.setEnabled(false);
        this.linear_12.setEnabled(false);
        this.linear_13.setEnabled(false);
        this.linear_14.setEnabled(false);
        this.linear_15.setEnabled(false);
        this.linear_16.setEnabled(false);
    }

    public void _UI() {
        _Corner_Reduce(10.0d, 0.0d, 0.0d, StringFogImpl.decrypt("dmUCaAEXYg=="), StringFogImpl.decrypt("dmUCaAEXYg=="), this.linear_1);
        _Corner_Reduce(10.0d, 0.0d, 0.0d, StringFogImpl.decrypt("dmUCaAEXYg=="), StringFogImpl.decrypt("dmUCaAEXYg=="), this.linear_2);
        _Corner_Reduce(10.0d, 0.0d, 0.0d, StringFogImpl.decrypt("dmUCaAEXYg=="), StringFogImpl.decrypt("dmUCaAEXYg=="), this.linear_3);
        _Corner_Reduce(10.0d, 0.0d, 0.0d, StringFogImpl.decrypt("dmUCaAEXYg=="), StringFogImpl.decrypt("dmUCaAEXYg=="), this.linear_4);
        _Corner_Reduce(10.0d, 0.0d, 0.0d, StringFogImpl.decrypt("dmUCaAEXYg=="), StringFogImpl.decrypt("dmUCaAEXYg=="), this.linear_5);
        _Corner_Reduce(10.0d, 0.0d, 0.0d, StringFogImpl.decrypt("dmUCaAEXYg=="), StringFogImpl.decrypt("dmUCaAEXYg=="), this.linear_6);
        _Corner_Reduce(10.0d, 0.0d, 0.0d, StringFogImpl.decrypt("dmUCaAEXYg=="), StringFogImpl.decrypt("dmUCaAEXYg=="), this.linear_7);
        _Corner_Reduce(10.0d, 0.0d, 0.0d, StringFogImpl.decrypt("dmUCaAEXYg=="), StringFogImpl.decrypt("dmUCaAEXYg=="), this.linear_8);
        _Corner_Reduce(10.0d, 0.0d, 0.0d, StringFogImpl.decrypt("dmUCaAEXYg=="), StringFogImpl.decrypt("dmUCaAEXYg=="), this.linear_9);
        _Corner_Reduce(10.0d, 0.0d, 0.0d, StringFogImpl.decrypt("dmUCaAEXYg=="), StringFogImpl.decrypt("dmUCaAEXYg=="), this.linear_10);
        _Corner_Reduce(10.0d, 0.0d, 0.0d, StringFogImpl.decrypt("dmUCaAEXYg=="), StringFogImpl.decrypt("dmUCaAEXYg=="), this.linear_11);
        _Corner_Reduce(10.0d, 0.0d, 0.0d, StringFogImpl.decrypt("dmUCaAEXYg=="), StringFogImpl.decrypt("dmUCaAEXYg=="), this.linear_12);
        _Corner_Reduce(10.0d, 0.0d, 0.0d, StringFogImpl.decrypt("dmUCaAEXYg=="), StringFogImpl.decrypt("dmUCaAEXYg=="), this.linear_13);
        _Corner_Reduce(10.0d, 0.0d, 0.0d, StringFogImpl.decrypt("dmUCaAEXYg=="), StringFogImpl.decrypt("dmUCaAEXYg=="), this.linear_14);
        _Corner_Reduce(10.0d, 0.0d, 0.0d, StringFogImpl.decrypt("dmUCaAEXYg=="), StringFogImpl.decrypt("dmUCaAEXYg=="), this.linear_15);
        _Corner_Reduce(10.0d, 0.0d, 0.0d, StringFogImpl.decrypt("dmUCaAEXYg=="), StringFogImpl.decrypt("dmUCaAEXYg=="), this.linear_16);
        _Corner_Reduce(10.0d, 0.0d, 0.0d, StringFogImpl.decrypt("dmAFbH5gZA=="), StringFogImpl.decrypt("dmAFbH5gZA=="), this.button1);
        _Corner_Reduce(10.0d, 3.0d, 0.0d, StringFogImpl.decrypt("dmAFbH5gZA=="), StringFogImpl.decrypt("dhIAa34TEg=="), this.linear_score);
    }

    @Deprecated
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, 0).show();
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    @Deprecated
    public int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList<Double> arrayList = new ArrayList<>();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf(checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int i) {
        return TypedValue.applyDimension(1, i, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
