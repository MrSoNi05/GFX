package com.bgm.gfx;

import android.app.AlarmManager;
import android.app.Application;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Process;
import android.util.Log;

import com.github.megatronking.stringfog.xor.StringFogImpl;
import java.lang.Thread;

/* loaded from: classes7.dex */
public class SketchApplication extends Application {
    private Thread.UncaughtExceptionHandler uncaughtExceptionHandler;

    @Override // android.app.Application
    public void onCreate() {
        this.uncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() { // from class: com.bgm.gfx.SketchApplication.1
            @Override // java.lang.Thread.UncaughtExceptionHandler
            public void uncaughtException(Thread thread, Throwable th) {
                Intent intent = new Intent(SketchApplication.this.getApplicationContext(), DebugNewMainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                intent.putExtra(StringFogImpl.decrypt("MCY0Qko="), Log.getStackTraceString(th));
                ((AlarmManager) SketchApplication.this.getSystemService(StringFogImpl.decrypt("NDgnX1U="))).set(2, 1000L, PendingIntent.getActivity(SketchApplication.this.getApplicationContext(), 11111, intent, 1073741824));
                Process.killProcess(Process.myPid());
                System.exit(1);
                SketchApplication.this.uncaughtExceptionHandler.uncaughtException(thread, th);
            }
        });
        super.onCreate();
    }
}
