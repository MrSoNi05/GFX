package com.bgm.gfx;

import android.graphics.Canvas;
import android.view.SurfaceHolder;

/* loaded from: classes7.dex */
public class GameLoopThread extends Thread {
    static final long FPS = 10;
    private ISurface panel;
    private boolean running = false;
    private SurfaceHolder surfaceHolder;
    private long timer;
    private GameView view;

    public GameLoopThread(SurfaceHolder surfaceHolder, ISurface iSurface) {
        this.surfaceHolder = surfaceHolder;
        this.panel = iSurface;
        iSurface.onInitialize();
    }

    public void setRunning(boolean z) {
        this.running = z;
    }

    @Override // java.lang.Thread, java.lang.Runnable
    public void run() {
        while (this.running) {
            Canvas canvas = null;
            long currentTimeMillis = System.currentTimeMillis();
            this.timer = currentTimeMillis;
            this.panel.onUpdate(currentTimeMillis);
            try {
                canvas = this.surfaceHolder.lockCanvas();
                synchronized (this.surfaceHolder) {
                    this.panel.onDraw(canvas);
                }
                long currentTimeMillis2 = 200 - (System.currentTimeMillis() - currentTimeMillis);
                if (currentTimeMillis2 <= 0) {
                    currentTimeMillis2 = FPS;
                }
                try {
                    sleep(currentTimeMillis2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            } finally {
                if (canvas != null) {
                    this.surfaceHolder.unlockCanvasAndPost(canvas);
                }
            }
        }
    }
}
