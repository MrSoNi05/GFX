package com.bgm.gfx;

import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.bgm.gfx.RequestNetwork;
import com.github.megatronking.stringfog.xor.StringFogImpl;
import com.google.firebase.FirebaseApp;
import com.thecode.aestheticdialogs.AestheticDialog;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

/* loaded from: classes7.dex */
public class NonetActivity extends AppCompatActivity {
    private RequestNetwork.RequestListener _n_request_listener;
    private Timer _timer = new Timer();
    private Intent i = new Intent();
    private ImageView imageview1;
    private LinearLayout linear1;
    private RequestNetwork n;
    private TimerTask t;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.nonet);
        initialize(bundle);
          //   FirebaseApp.initializeApp(String.valueOf(this));
        initializeLogic();
    }

    private void initialize(Bundle bundle) {
        this.linear1 = (LinearLayout) findViewById(R.id.linear1);
        this.imageview1 = (ImageView) findViewById(R.id.imageview1);
        this.n = new RequestNetwork(this);
        this._n_request_listener = new RequestNetwork.RequestListener() { // from class: com.bgm.gfx.NonetActivity.1
            @Override // com.bgm.gfx.RequestNetwork.RequestListener
            public void onErrorResponse(String str, String str2) {
            }

            @Override // com.bgm.gfx.RequestNetwork.RequestListener
            public void onResponse(String str, String str2, HashMap<String, Object> hashMap) {
            }
        };
    }

    private void initializeLogic() {
        AestheticDialog.showConnectify(this, StringFogImpl.decrypt("BTgjTEswdDJYSjt0KUMYPDoySEo7MTINVyd0MURePA=="), StringFogImpl.decrypt("ARsHfmwQBhloagcbFA=="));
        _NavStatusBarColor(StringFogImpl.decrypt("dhIAFXtsEQBr"), StringFogImpl.decrypt("dhIAFXtsEQBr"));
        TimerTask timerTask = new TimerTask() { // from class: com.bgm.gfx.NonetActivity.2
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                NonetActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.NonetActivity.2.1
                    @Override // java.lang.Runnable
                    public void run() {
                        if (SketchwareUtil.isConnected(NonetActivity.this.getApplicationContext())) {
                            NonetActivity.this.t.cancel();
                            NonetActivity.this.i.setClass(NonetActivity.this.getApplicationContext(), MainActivity.class);
                            NonetActivity.this.startActivity(NonetActivity.this.i);
                        }
                    }
                });
            }
        };
        this.t = timerTask;
        this._timer.scheduleAtFixedRate(timerTask, 50L, 500L);
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        finishAffinity();
    }

    public void _NavStatusBarColor(String str, String str2) {
        if (Build.VERSION.SDK_INT > 21) {
            Window window = getWindow();
            window.clearFlags(67108864);
            window.addFlags(Integer.MIN_VALUE);
            window.setStatusBarColor(Color.parseColor(StringFogImpl.decrypt("dg==") + str.replace(StringFogImpl.decrypt("dg=="), "")));
            window.setNavigationBarColor(Color.parseColor(StringFogImpl.decrypt("dg==") + str2.replace(StringFogImpl.decrypt("dg=="), "")));
        }
    }

    @Deprecated
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    @Deprecated
    public int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList<Double> arrayList = new ArrayList<>();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf(checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int i) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, i, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
