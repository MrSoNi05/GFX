package com.bgm.gfx;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Point;
import android.os.Handler;
import android.view.MotionEvent;
import android.view.SurfaceHolder;
import android.view.SurfaceView;
import android.widget.Toast;
import com.bgm.gfx.Figure;
import com.github.megatronking.stringfog.xor.StringFogImpl;
import java.lang.reflect.Array;

/* loaded from: classes7.dex */
public class GameView extends SurfaceView implements ISurface {
    private static /* synthetic */ int[] $SWITCH_TABLE$com$bgm$gfx$Figure$FigureMotion = null;
    static final int BRICK_GAP_SIZE = 1;
    static final int BRICK_SIZE = 60;
    protected int _iHeight;
    protected int _iWidth;
    protected int bHeight;
    protected int bWidth;
    int bgColor;
    Context context;
    int fgColor;
    boolean[][] field;
    Figure figure;
    private GameLoopThread gameLoopThread;
    boolean gameOver;
    Handler handler;
    SurfaceHolder holder;
    Paint p;
    int score;

    private void fallDownFigure() {
    }

    static /* synthetic */ int[] $SWITCH_TABLE$com$bgm$gfx$Figure$FigureMotion() {
        int[] iArr = $SWITCH_TABLE$com$bgm$gfx$Figure$FigureMotion;
        if (iArr != null) {
            return iArr;
        }
        int[] iArr2 = new int[Figure.FigureMotion.valuesCustom().length];
        try {
            iArr2[Figure.FigureMotion.Down.ordinal()] = 3;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr2[Figure.FigureMotion.Left.ordinal()] = 1;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr2[Figure.FigureMotion.Right.ordinal()] = 2;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            iArr2[Figure.FigureMotion.Rotate.ordinal()] = 4;
        } catch (NoSuchFieldError unused4) {
        }
        $SWITCH_TABLE$com$bgm$gfx$Figure$FigureMotion = iArr2;
        return iArr2;
    }

    public GameView(Context context) {
        super(context);
        this.score = 0;
        this.context = context;
        this.p = new Paint();
        this.gameOver = false;
        this.handler = new Handler();
        this.figure = new Figure();
        this.holder = getHolder();
        this.gameLoopThread = new GameLoopThread(this.holder, this);
        this.holder.addCallback(new SurfaceHolder.Callback() { // from class: com.bgm.gfx.GameView.1
            @Override // android.view.SurfaceHolder.Callback
            public void surfaceChanged(SurfaceHolder surfaceHolder, int i, int i2, int i3) {
                GameView.this._iWidth = i2;
                GameView.this._iHeight = i3;
                GameView.this.initField();
            }

            @Override // android.view.SurfaceHolder.Callback
            public void surfaceCreated(SurfaceHolder surfaceHolder) {
                GameView.this.gameLoopThread.setRunning(true);
                try {
                    GameView.this.gameLoopThread.start();
                } catch (IllegalThreadStateException e) {
                    e.printStackTrace();
                }
            }

            @Override // android.view.SurfaceHolder.Callback
            public void surfaceDestroyed(SurfaceHolder surfaceHolder) {
                GameView.this.gameLoopThread.setRunning(false);
                boolean z = true;
                while (z) {
                    try {
                        GameView.this.gameLoopThread.join();
                        z = false;
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
            }
        });
    }

    @Override // android.view.View, com.bgm.gfx.ISurface
    public void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        canvas.drawColor(this.bgColor);
        this.p.setColor(this.fgColor);
        for (int i = 1; i < this.field.length - 1; i++) {
            int i2 = 1;
            while (true) {
                boolean[][] zArr = this.field;
                if (i2 >= zArr[i].length - 1) {
                    break;
                }
                if (zArr[i][i2]) {
                    canvas.drawRect((i2 - 1) * 61, (i - 1) * 61, (i2 * 61) - 1, (i * 61) - 1, this.p);
                }
                i2++;
            }
        }
        this.figure.DrawFigure(canvas);
    }

    public void initField() {
        int i = (this._iHeight / 61) + 2;
        this.bHeight = i;
        int i2 = (this._iWidth / 61) + 2;
        this.bWidth = i2;
        this.field = (boolean[][]) Array.newInstance(boolean.class, i, i2);
        CleanupField();
    }

    @Override // com.bgm.gfx.ISurface
    public void onInitialize() {
        this.bgColor = getResources().getColor(R.color.bg_color);
        this.fgColor = getResources().getColor(R.color.fg_color);
        this.figure.pos = new Point(this.bWidth / 2, 0);
        this.figure.type = Figure.FigureType.randomFigure();
    }

    private void CleanupField() {
        int i = 0;
        while (true) {
            boolean[][] zArr = this.field;
            if (i >= zArr[0].length) {
                break;
            }
            zArr[0][i] = true;
            zArr[zArr.length - 1][i] = true;
            i++;
        }
        int i2 = 1;
        while (true) {
            boolean[][] zArr2 = this.field;
            if (i2 >= zArr2.length - 1) {
                return;
            }
            zArr2[i2][0] = true;
            zArr2[i2][zArr2[i2].length - 1] = true;
            i2++;
        }
    }

    void moveDownFigure() {
        if (canMoveFigure(Figure.FigureMotion.Down)) {
            this.figure.pos.y++;
            return;
        }
        putFigure();
        getherComplitedLines();
        this.figure.refresh();
        this.figure.pos.set(this.bWidth / 6, 0);
        this.gameOver = isGameOver();
    }

    void getherComplitedLines() {
        int i = 0;
        for (int length = (this.figure.pos.y + this.figure.getMatrix().length) - 1; length > 0; length--) {
            int i2 = 1;
            boolean z = true;
            boolean z2 = true;
            while (true) {
                boolean[][] zArr = this.field;
                if (i2 >= zArr[0].length - 1) {
                    break;
                }
                int i3 = length + i;
                if (zArr[i3][i2]) {
                    z = false;
                }
                zArr[i3][i2] = zArr[length][i2];
                if (!zArr[length][i2]) {
                    z2 = false;
                }
                i2++;
            }
            if (z) {
                break;
            }
            if (z2) {
                i++;
            }
        }
        this.score += i * i;
    }

    boolean canMoveFigure(Figure.FigureMotion figureMotion) {
        Point point;
        boolean[][] matrix;
        int i = $SWITCH_TABLE$com$bgm$gfx$Figure$FigureMotion()[figureMotion.ordinal()];
        if (i == 1) {
            point = new Point(-1, 0);
            matrix = this.figure.getMatrix();
        } else if (i == 2) {
            point = new Point(1, 0);
            matrix = this.figure.getMatrix();
        } else if (i == 3) {
            point = new Point(0, 1);
            matrix = this.figure.getMatrix();
        } else if (i == 4) {
            point = new Point(0, 0);
            matrix = this.figure.getMatrix(true);
        } else {
            throw new IllegalArgumentException(StringFogImpl.decrypt("ADouTFYxOCNJGBg7MkRXOwA/XV10"));
        }
        for (int i2 = 0; i2 < matrix.length; i2++) {
            for (int i3 = 0; i3 < matrix[i2].length; i3++) {
                if (matrix[i2][i3] && this.field[this.figure.pos.y + point.y + i2][this.figure.pos.x + point.x + i3]) {
                    return false;
                }
            }
        }
        return true;
    }

    void putFigure() {
        boolean[][] matrix = this.figure.getMatrix();
        for (int i = 0; i < matrix.length; i++) {
            for (int i2 = 0; i2 < matrix[i].length; i2++) {
                if (matrix[i][i2]) {
                    this.field[this.figure.pos.y + i][this.figure.pos.x + i2] = matrix[i][i2];
                }
            }
        }
    }

    boolean isGameOver() {
        boolean[][] matrix = this.figure.getMatrix();
        for (int i = 0; i < matrix.length; i++) {
            for (int i2 = 0; i2 < matrix[i].length; i2++) {
                if (matrix[i][i2] && this.field[this.figure.pos.y + i + 1][this.figure.pos.x + i2]) {
                    this.handler.post(new Runnable() { // from class: com.bgm.gfx.GameView.2
                        @Override // java.lang.Runnable
                        public void run() {
                            Toast.makeText(GameView.this.context, StringFogImpl.decrypt("EjUrSBgaIiNfGQ=="), 1).show();
                        }
                    });
                    return true;
                }
            }
        }
        return false;
    }

    @Override // com.bgm.gfx.ISurface
    public void onUpdate(long j) {
        if (this.gameOver) {
            return;
        }
        moveDownFigure();
    }

    @Override // android.view.View
    public boolean onTouchEvent(MotionEvent motionEvent) {
        float x = motionEvent.getX();
        float y = motionEvent.getY();
        int i = this._iHeight;
        if (y < i / 3) {
            if (canMoveFigure(Figure.FigureMotion.Rotate)) {
                this.figure.rotate();
            }
        } else if (y > (i / 3) * 2) {
            fallDownFigure();
        } else if (x > this._iWidth / 2) {
            if (canMoveFigure(Figure.FigureMotion.Right)) {
                this.figure.pos.x++;
            }
        } else if (canMoveFigure(Figure.FigureMotion.Left)) {
            Point point = this.figure.pos;
            point.x--;
        }
        return super.onTouchEvent(motionEvent);
    }
}
