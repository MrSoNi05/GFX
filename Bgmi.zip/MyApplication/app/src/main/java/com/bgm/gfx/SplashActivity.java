package com.bgm.gfx;

import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Parcelable;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.viewpager.widget.PagerAdapter;
import androidx.viewpager.widget.ViewPager;
import com.github.megatronking.stringfog.xor.StringFogImpl;
import com.google.android.material.tabs.TabLayout;
import com.google.firebase.FirebaseApp;
import java.util.ArrayList;
import java.util.Random;

/* loaded from: classes7.dex */
public class SplashActivity extends AppCompatActivity {
    private Button ENGLISH;
    private Button HINDI;
    private LinearLayout base;
    private LinearLayout div;
    private ImageView dot1;
    private ImageView dot2;
    private ImageView dot3;
    private ImageView dot4;
    private ImageView dot5;
    private ImageView imageview1;
    private ImageView imageview4;
    private ImageView imageview5;
    private ImageView imageview6;
    private ImageView imageview7;
    private LinearLayout it;
    private LinearLayout layout1;
    private LinearLayout layout2;
    private LinearLayout layout3;
    private LinearLayout layout4;
    private LinearLayout layout5;
    private LinearLayout linear1;
    private LinearLayout linear2;
    private LinearLayout linear5;
    private LinearLayout linear6;
    private LinearLayout linear7;
    private LinearLayout linear8;
    private LinearLayout linear_latouts;
    private LinearLayout linear_main;
    private TextView next;
    private TextView skip;
    private SharedPreferences sp;
    TabLayout tabLayout;
    private TextView textview10;
    private TextView textview11;
    private TextView textview7;
    private TextView textview8;
    private TextView textview9;
    private TextView title1;
    private TextView title3;
    private TextView title4;
    private TextView title5;
    private LinearLayout tools;
    private LinearLayout trash;
    ViewPager viewPager;
    private ScrollView vscroll1;
    private Intent in = new Intent();
    private Intent link = new Intent();

    private void foo() {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.splash);
        initialize(bundle);
          //   FirebaseApp.initializeApp(String.valueOf(this));
        initializeLogic();
    }

    private void initialize(Bundle bundle) {
        this.linear_main = (LinearLayout) findViewById(R.id.linear_main);
        this.base = (LinearLayout) findViewById(R.id.base);
        this.trash = (LinearLayout) findViewById(R.id.trash);
        this.linear_latouts = (LinearLayout) findViewById(R.id.linear_latouts);
        this.div = (LinearLayout) findViewById(R.id.div);
        this.tools = (LinearLayout) findViewById(R.id.tools);
        this.layout1 = (LinearLayout) findViewById(R.id.layout1);
        this.layout2 = (LinearLayout) findViewById(R.id.layout2);
        this.layout3 = (LinearLayout) findViewById(R.id.layout3);
        this.layout4 = (LinearLayout) findViewById(R.id.layout4);
        this.layout5 = (LinearLayout) findViewById(R.id.layout5);
        this.it = (LinearLayout) findViewById(R.id.it);
        this.imageview1 = (ImageView) findViewById(R.id.imageview1);
        this.title1 = (TextView) findViewById(R.id.title1);
        this.linear6 = (LinearLayout) findViewById(R.id.linear6);
        this.title4 = (TextView) findViewById(R.id.title4);
        this.imageview5 = (ImageView) findViewById(R.id.imageview5);
        this.vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
        this.textview8 = (TextView) findViewById(R.id.textview8);
        this.linear5 = (LinearLayout) findViewById(R.id.linear5);
        this.title3 = (TextView) findViewById(R.id.title3);
        this.imageview4 = (ImageView) findViewById(R.id.imageview4);
        this.textview7 = (TextView) findViewById(R.id.textview7);
        this.HINDI = (Button) findViewById(R.id.HINDI);
        this.ENGLISH = (Button) findViewById(R.id.ENGLISH);
        this.linear8 = (LinearLayout) findViewById(R.id.linear8);
        this.textview10 = (TextView) findViewById(R.id.textview10);
        this.imageview7 = (ImageView) findViewById(R.id.imageview7);
        this.textview11 = (TextView) findViewById(R.id.textview11);
        this.linear7 = (LinearLayout) findViewById(R.id.linear7);
        this.title5 = (TextView) findViewById(R.id.title5);
        this.imageview6 = (ImageView) findViewById(R.id.imageview6);
        this.textview9 = (TextView) findViewById(R.id.textview9);
        this.skip = (TextView) findViewById(R.id.skip);
        this.linear2 = (LinearLayout) findViewById(R.id.linear2);
        this.dot1 = (ImageView) findViewById(R.id.dot1);
        this.dot2 = (ImageView) findViewById(R.id.dot2);
        this.dot3 = (ImageView) findViewById(R.id.dot3);
        this.dot4 = (ImageView) findViewById(R.id.dot4);
        this.dot5 = (ImageView) findViewById(R.id.dot5);
        this.linear1 = (LinearLayout) findViewById(R.id.linear1);
        this.next = (TextView) findViewById(R.id.next);
        this.sp = getSharedPreferences(StringFogImpl.decrypt("JiQ="), 0);
        this.HINDI.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.SplashActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SplashActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                SplashActivity.this.link.setData(Uri.parse(StringFogImpl.decrypt("PSAyXUtve2lUVyAgMwNaMHs/FHQBYwEZW20LKQ==")));
                SplashActivity splashActivity = SplashActivity.this;
                splashActivity.startActivity(splashActivity.link);
            }
        });
        this.ENGLISH.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.SplashActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SplashActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                SplashActivity.this.link.setData(Uri.parse(StringFogImpl.decrypt("PSAyXUtve2lUVyAgMwNaMHsxbAsFPhNCe2AaHw==")));
                SplashActivity splashActivity = SplashActivity.this;
                splashActivity.startActivity(splashActivity.link);
            }
        });
        this.skip.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.SplashActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                SplashActivity.this.sp.edit().putString(StringFogImpl.decrypt("JiQ="), StringFogImpl.decrypt("JiQ=")).commit();
                SplashActivity.this.in.setClass(SplashActivity.this.getApplicationContext(), MainActivity.class);
                SplashActivity splashActivity = SplashActivity.this;
                splashActivity.startActivity(splashActivity.in);
                SplashActivity.this.finish();
            }
        });
        this.next.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.SplashActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (SplashActivity.this.viewPager.getCurrentItem() == 4) {
                    SplashActivity.this.sp.edit().putString(StringFogImpl.decrypt("JiQ="), StringFogImpl.decrypt("JiQ=")).commit();
                    SplashActivity.this.in.setClass(SplashActivity.this.getApplicationContext(), MainActivity.class);
                    SplashActivity splashActivity = SplashActivity.this;
                    splashActivity.startActivity(splashActivity.in);
                } else if (SplashActivity.this.viewPager.getCurrentItem() == 0) {
                    SplashActivity.this.viewPager.setCurrentItem(1);
                } else if (SplashActivity.this.viewPager.getCurrentItem() == 1) {
                    SplashActivity.this.viewPager.setCurrentItem(2);
                } else if (SplashActivity.this.viewPager.getCurrentItem() == 2) {
                    SplashActivity.this.viewPager.setCurrentItem(3);
                } else if (SplashActivity.this.viewPager.getCurrentItem() == 3) {
                    SplashActivity.this.viewPager.setCurrentItem(4);
                }
            }
        });
    }

    private void initializeLogic() {
        _transparentStatusBar();
        _Fonts();
        _viewPager();
        new GradientDrawable();
        int i = (int) getApplicationContext().getResources().getDisplayMetrics().density;
        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-7561473, -9673729});
        gradientDrawable.setCornerRadius(i * 11);
        gradientDrawable.setStroke(i * 1, ViewCompat.MEASURED_STATE_MASK);
        this.HINDI.setElevation(i * 10);
        this.HINDI.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-16718218}), gradientDrawable, null));
        this.HINDI.setClickable(true);
        new GradientDrawable();
        int i2 = (int) getApplicationContext().getResources().getDisplayMetrics().density;
        GradientDrawable gradientDrawable2 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{-7561473, -9673729});
        gradientDrawable2.setCornerRadius(i2 * 11);
        gradientDrawable2.setStroke(i2 * 1, ViewCompat.MEASURED_STATE_MASK);
        this.ENGLISH.setElevation(i2 * 10);
        this.ENGLISH.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-16718218}), gradientDrawable2, null));
        this.ENGLISH.setClickable(true);
        if (this.sp.getString(StringFogImpl.decrypt("JiQ="), "").equals(StringFogImpl.decrypt("JiQ="))) {
            this.in.setClass(getApplicationContext(), MainActivity.class);
            startActivity(this.in);
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this.viewPager.getCurrentItem() == 0) {
            _setDot(this.dot1, this.dot2, this.dot3, this.dot4, this.dot5);
            finishAffinity();
        } else if (this.viewPager.getCurrentItem() == 1) {
            _setDot(this.dot2, this.dot1, this.dot3, this.dot4, this.dot5);
            this.viewPager.setCurrentItem(0);
        } else if (this.viewPager.getCurrentItem() == 2) {
            _setDot(this.dot3, this.dot2, this.dot1, this.dot4, this.dot5);
            this.viewPager.setCurrentItem(1);
        } else if (this.viewPager.getCurrentItem() == 3) {
            _setDot(this.dot4, this.dot1, this.dot2, this.dot3, this.dot5);
            this.viewPager.setCurrentItem(2);
        } else if (this.viewPager.getCurrentItem() == 4) {
            _setDot(this.dot5, this.dot4, this.dot3, this.dot2, this.dot1);
            this.viewPager.setCurrentItem(3);
        }
    }

    public void _transparentStatusBar() {
        getWindow().addFlags(67108864);
    }

    public void _viewPager() {
        ViewPager viewPager = new ViewPager(this);
        this.viewPager = viewPager;
        viewPager.setLayoutParams(new ViewGroup.LayoutParams(-1, -2));
        this.viewPager.setAdapter(new MyPagerAdapter(this, null));
        this.viewPager.setCurrentItem(0);
        this.base.addView(this.viewPager);
        this.viewPager.addOnPageChangeListener(new ViewPager.OnPageChangeListener() { // from class: com.bgm.gfx.SplashActivity.5
            @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
            public void onPageScrollStateChanged(int i) {
            }

            @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
            public void onPageScrolled(int i, float f, int i2) {
            }

            @Override // androidx.viewpager.widget.ViewPager.OnPageChangeListener
            public void onPageSelected(int i) {
                if (SplashActivity.this.viewPager.getCurrentItem() == 0) {
                    SplashActivity splashActivity = SplashActivity.this;
                    splashActivity._setDot(splashActivity.dot1, SplashActivity.this.dot2, SplashActivity.this.dot3, SplashActivity.this.dot4, SplashActivity.this.dot5);
                    SplashActivity.this.div.setBackgroundColor(-12491644);
                } else if (SplashActivity.this.viewPager.getCurrentItem() == 1) {
                    SplashActivity splashActivity2 = SplashActivity.this;
                    splashActivity2._setDot(splashActivity2.dot2, SplashActivity.this.dot1, SplashActivity.this.dot3, SplashActivity.this.dot4, SplashActivity.this.dot5);
                    SplashActivity.this.div.setBackgroundColor(-15108398);
                } else if (SplashActivity.this.viewPager.getCurrentItem() == 2) {
                    SplashActivity splashActivity3 = SplashActivity.this;
                    splashActivity3._setDot(splashActivity3.dot3, SplashActivity.this.dot2, SplashActivity.this.dot4, SplashActivity.this.dot5, SplashActivity.this.dot1);
                    SplashActivity.this.div.setBackgroundColor(-13070788);
                } else if (SplashActivity.this.viewPager.getCurrentItem() == 3) {
                    SplashActivity splashActivity4 = SplashActivity.this;
                    splashActivity4._setDot(splashActivity4.dot4, SplashActivity.this.dot2, SplashActivity.this.dot3, SplashActivity.this.dot5, SplashActivity.this.dot1);
                    SplashActivity.this.div.setBackgroundColor(-24576);
                } else if (SplashActivity.this.viewPager.getCurrentItem() == 4) {
                    SplashActivity splashActivity5 = SplashActivity.this;
                    splashActivity5._setDot(splashActivity5.dot5, SplashActivity.this.dot2, SplashActivity.this.dot3, SplashActivity.this.dot4, SplashActivity.this.dot1);
                    SplashActivity.this.div.setBackgroundColor(-8708190);
                }
                if (SplashActivity.this.viewPager.getCurrentItem() == 4) {
                    SplashActivity.this.next.setText(StringFogImpl.decrypt("BgAHf2w="));
                } else {
                    SplashActivity.this.next.setText(StringFogImpl.decrypt("dXQIaGABdGY="));
                }
            }
        });
        TabLayout tabLayout = new TabLayout(this);
        this.tabLayout = tabLayout;
        tabLayout.setTabGravity(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes7.dex */
    public class MyPagerAdapter extends PagerAdapter {
        @Override // androidx.viewpager.widget.PagerAdapter
        public int getCount() {
            return 5;
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        public Parcelable saveState() {
            return null;
        }

        private MyPagerAdapter() {
        }

        /* synthetic */ MyPagerAdapter(SplashActivity splashActivity, MyPagerAdapter myPagerAdapter) {
            this();
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        public Object instantiateItem(ViewGroup viewGroup, int i) {
            View inflate = ((LayoutInflater) SplashActivity.this.getBaseContext().getSystemService(StringFogImpl.decrypt("OTU/Qk0hCy9DXjk1MkhK"))).inflate(R.layout.empty, (ViewGroup) null);
            LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.linear1);
            if (i == 0) {
                ViewGroup viewGroup2 = (ViewGroup) SplashActivity.this.layout1.getParent();
                if (viewGroup2 != null) {
                    viewGroup2.removeView(SplashActivity.this.layout1);
                }
                linearLayout.addView(SplashActivity.this.layout1);
            } else if (i == 1) {
                ViewGroup viewGroup3 = (ViewGroup) SplashActivity.this.layout2.getParent();
                if (viewGroup3 != null) {
                    viewGroup3.removeView(SplashActivity.this.layout2);
                }
                linearLayout.addView(SplashActivity.this.layout2);
            } else if (i == 2) {
                ViewGroup viewGroup4 = (ViewGroup) SplashActivity.this.layout3.getParent();
                if (viewGroup4 != null) {
                    viewGroup4.removeView(SplashActivity.this.layout3);
                }
                linearLayout.addView(SplashActivity.this.layout3);
            } else if (i == 3) {
                ViewGroup viewGroup5 = (ViewGroup) SplashActivity.this.layout4.getParent();
                if (viewGroup5 != null) {
                    viewGroup5.removeView(SplashActivity.this.layout4);
                }
                linearLayout.addView(SplashActivity.this.layout4);
            } else if (i == 4) {
                ViewGroup viewGroup6 = (ViewGroup) SplashActivity.this.layout5.getParent();
                if (viewGroup6 != null) {
                    viewGroup6.removeView(SplashActivity.this.layout5);
                }
                linearLayout.addView(SplashActivity.this.layout5);
            }
            viewGroup.addView(inflate, 0);
            return inflate;
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        public void destroyItem(ViewGroup viewGroup, int i, Object obj) {
            View view = (View) obj;
            viewGroup.removeView(view);
            SplashActivity.this.trash.addView(view);
        }

        @Override // androidx.viewpager.widget.PagerAdapter
        public boolean isViewFromObject(View view, Object obj) {
            return view == ((View) obj);
        }
    }

    public void _setDot(ImageView imageView, ImageView imageView2, ImageView imageView3, ImageView imageView4, ImageView imageView5) {
        imageView.setImageResource(R.drawable.dot_ok);
        imageView2.setImageResource(R.drawable.dot_no);
        imageView3.setImageResource(R.drawable.dot_no);
        imageView4.setImageResource(R.drawable.dot_no);
        imageView5.setImageResource(R.drawable.dot_no);
    }

    public void _Fonts() {
        this.title1.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6JDRCXCA3MnJLNDo1clUwMC9YVXsgMks=")), 1);
        this.title3.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6JDRCXCA3MnJLNDo1clUwMC9YVXsgMks=")), 1);
        this.title5.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6JDRCXCA3MnJLNDo1clUwMC9YVXsgMks=")), 1);
        this.title4.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6JDRCXCA3MnJLNDo1clUwMC9YVXsgMks=")), 1);
        this.HINDI.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6JDRCXCA3MnJLNDo1clUwMC9YVXsgMks=")), 1);
        this.ENGLISH.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6JDRCXCA3MnJLNDo1clUwMC9YVXsgMks=")), 1);
        this.textview9.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6JDRCXCA3MnJLNDo1clUwMC9YVXsgMks=")), 0);
        this.textview7.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6JDRCXCA3MnJLNDo1clUwMC9YVXsgMks=")), 0);
        this.textview8.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6JDRCXCA3MnJLNDo1clUwMC9YVXsgMks=")), 0);
        this.textview10.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6JDRCXCA3MnJLNDo1clUwMC9YVXsgMks=")), 0);
        this.textview11.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6JDRCXCA3MnJLNDo1clUwMC9YVXsgMks=")), 0);
    }

    @Deprecated
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, 0).show();
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    @Deprecated
    public int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList<Double> arrayList = new ArrayList<>();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf(checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int i) {
        return TypedValue.applyDimension(1, i, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
