package com.bgm.gfx;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.github.megatronking.stringfog.xor.StringFogImpl;
import com.google.firebase.FirebaseApp;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;

/* loaded from: classes7.dex */
public class BricksActivity extends AppCompatActivity {
    private Context PlayActivity;
    private ImageView imageview1;
    private LinearLayout linear1;
    private LinearLayout linear2;
    private LinearLayout linear3;
    private LinearLayout linear4;
    private LinearLayout linear5;
    private TextView textview1;
    private TextView textview2;
    private TextView textview3;
    private TextView textview4;
    private TextView textview5;
    private double ranNumber = 0.0d;
    private String str = "";
    private ArrayList<HashMap<String, Object>> list2 = new ArrayList<>();
    private Intent i1 = new Intent();

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.bricks);
        initialize(bundle);
          //   FirebaseApp.initializeApp(String.valueOf(this));
        initializeLogic();
    }

    private void initialize(Bundle bundle) {
        this.linear1 = (LinearLayout) findViewById(R.id.linear1);
        this.linear4 = (LinearLayout) findViewById(R.id.linear4);
        this.textview1 = (TextView) findViewById(R.id.textview1);
        this.linear2 = (LinearLayout) findViewById(R.id.linear2);
        this.textview2 = (TextView) findViewById(R.id.textview2);
        this.linear3 = (LinearLayout) findViewById(R.id.linear3);
        this.linear5 = (LinearLayout) findViewById(R.id.linear5);
        this.imageview1 = (ImageView) findViewById(R.id.imageview1);
        this.textview5 = (TextView) findViewById(R.id.textview5);
        this.textview3 = (TextView) findViewById(R.id.textview3);
        this.textview4 = (TextView) findViewById(R.id.textview4);
        this.textview2.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BricksActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                BricksActivity.this.i1.setClass(BricksActivity.this.getApplicationContext(), PlayActivity.class);
                BricksActivity bricksActivity = BricksActivity.this;
                bricksActivity.startActivity(bricksActivity.i1);
                BricksActivity.this.finish();
            }
        });
    }

    /* JADX WARN: Type inference failed for: r1v7, types: [com.bgm.gfx.BricksActivity$3] */
    private void initializeLogic() {
        this.list2 = (ArrayList) new Gson().fromJson("", new TypeToken<ArrayList<HashMap<String, Object>>>() { // from class: com.bgm.gfx.BricksActivity.2
        }.getType());
        _darkStatusBar();
        if (Build.VERSION.SDK_INT > 19) {
            Window window = getWindow();
            window.clearFlags(67108864);
            window.addFlags(Integer.MIN_VALUE);
            window.setStatusBarColor(-15656415);
        }
        this.textview1.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6MilDWScgKQNMITI=")), Typeface.NORMAL);
        this.textview2.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6MilDWScgKQNMITI=")), Typeface.NORMAL);
        this.linear5.setBackground(new GradientDrawable() { // from class: com.bgm.gfx.BricksActivity.3
            public GradientDrawable getIns(int i, int i2, int i3) {
                setStroke(i, i2);
                setColor(i3);
                return this;
            }
        }.getIns(2, -1, 0));
        _Card_View(this.textview2, 360.0d, StringFogImpl.decrypt("dmR2HQhlZHYd"), 0.0d, 3.0d, StringFogImpl.decrypt("dhIAa34TEg=="));
    }

    public void _darkStatusBar() {
        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(decorView.getSystemUiVisibility() & (-8193));
    }

    public void _Card_View(View view, double d, String str, double d2, double d3, String str2) {
        if (d3 == 0.0d) {
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setCornerRadius((float) d);
            gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dg==") + str.replace(StringFogImpl.decrypt("dg=="), "")));
            view.setBackground(gradientDrawable);
            view.setElevation((float) d2);
            return;
        }
        GradientDrawable gradientDrawable2 = new GradientDrawable();
        int i = (int) d3;
        gradientDrawable2.setStroke(i, Color.parseColor(StringFogImpl.decrypt("dg==") + str2.replace(StringFogImpl.decrypt("dg=="), "")));
        gradientDrawable2.setCornerRadius((float) d);
        gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dg==") + str.replace(StringFogImpl.decrypt("dg=="), "")));
        view.setBackground(gradientDrawable2);
        view.setElevation((float) d2);
    }

    @Deprecated
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    @Deprecated
    public int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList<Double> arrayList = new ArrayList<>();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf(checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int i) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, i, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
