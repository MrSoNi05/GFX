package com.bgm.gfx;

import android.animation.ObjectAnimator;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.github.megatronking.stringfog.xor.StringFogImpl;
import com.google.firebase.FirebaseApp;
import com.rejowan.cutetoast.CuteToast;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

/* loaded from: classes7.dex */
public class HvaiActivity extends AppCompatActivity {
    private Button button1;
    private ImageView imageview_ai;
    private ImageView imageview_h;
    private ImageView imageview_paper;
    private ImageView imageview_rock;
    private ImageView imageview_scissor;
    private ImageView imageview_selected;
    private LinearLayout linear1;
    private LinearLayout linear3;
    private LinearLayout linear4;
    private LinearLayout linear6;
    private LinearLayout linear7;
    private LinearLayout linear8;
    private LinearLayout linear_option;
    private LinearLayout linear_score;
    private LinearLayout linear_submit;
    private TextView opponent_score;
    private TextView player_score;
    private TextView textview2;
    private TextView textview3;
    private TextView textview4;
    private TextView textview_opponent;
    private TextView textview_player;
    private TimerTask timer;
    private SharedPreferences user;
    private Timer _timer = new Timer();
    private String edge = "";
    private String inside = "";
    private String User_choice = "";
    private double Random = 0.0d;
    private String AI_choise = "";
    private double Player_score = 0.0d;
    private double AI_score = 0.0d;
    private String won = "";
    private String Wonmsg = "";
    private boolean NEXT = false;
    private ObjectAnimator animation = new ObjectAnimator();

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.hvai);
        initialize(bundle);
          //   FirebaseApp.initializeApp(String.valueOf(this));
        initializeLogic();
    }

    private void initialize(Bundle bundle) {
        this.linear1 = (LinearLayout) findViewById(R.id.linear1);
        this.linear_score = (LinearLayout) findViewById(R.id.linear_score);
        this.linear8 = (LinearLayout) findViewById(R.id.linear8);
        this.textview3 = (TextView) findViewById(R.id.textview3);
        this.linear_option = (LinearLayout) findViewById(R.id.linear_option);
        this.linear_submit = (LinearLayout) findViewById(R.id.linear_submit);
        this.textview4 = (TextView) findViewById(R.id.textview4);
        this.linear7 = (LinearLayout) findViewById(R.id.linear7);
        this.textview_player = (TextView) findViewById(R.id.textview_player);
        this.player_score = (TextView) findViewById(R.id.player_score);
        this.linear6 = (LinearLayout) findViewById(R.id.linear6);
        this.textview_opponent = (TextView) findViewById(R.id.textview_opponent);
        this.opponent_score = (TextView) findViewById(R.id.opponent_score);
        this.imageview_h = (ImageView) findViewById(R.id.imageview_h);
        this.textview2 = (TextView) findViewById(R.id.textview2);
        this.imageview_ai = (ImageView) findViewById(R.id.imageview_ai);
        this.imageview_paper = (ImageView) findViewById(R.id.imageview_paper);
        this.linear3 = (LinearLayout) findViewById(R.id.linear3);
        this.imageview_scissor = (ImageView) findViewById(R.id.imageview_scissor);
        this.linear4 = (LinearLayout) findViewById(R.id.linear4);
        this.imageview_rock = (ImageView) findViewById(R.id.imageview_rock);
        this.imageview_selected = (ImageView) findViewById(R.id.imageview_selected);
        this.button1 = (Button) findViewById(R.id.button1);
        this.user = getSharedPreferences(StringFogImpl.decrypt("ICcjXw=="), 0);
        this.imageview_paper.setOnClickListener(new AnonymousClass1());
        this.imageview_scissor.setOnClickListener(new AnonymousClass2());
        this.imageview_rock.setOnClickListener(new AnonymousClass3());
        this.button1.setOnClickListener(new AnonymousClass4());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.HvaiActivity$1  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass1 implements View.OnClickListener {
        AnonymousClass1() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (HvaiActivity.this.NEXT) {
                HvaiActivity.this.imageview_selected.setImageResource(R.drawable.paper);
                HvaiActivity.this.button1.setText(StringFogImpl.decrypt("BTU2SEo="));
                HvaiActivity.this.User_choice = StringFogImpl.decrypt("JTU2SEo=");
                HvaiActivity.this.NEXT = false;
                HvaiActivity.this.Random = SketchwareUtil.getRandom(1, 3);
                if (HvaiActivity.this.Random == 1.0d) {
                    HvaiActivity.this.AI_choise = StringFogImpl.decrypt("JTU2SEo=");
                }
                if (HvaiActivity.this.Random == 2.0d) {
                    HvaiActivity.this.AI_choise = StringFogImpl.decrypt("JjcvXks6Jg==");
                }
                if (HvaiActivity.this.Random == 3.0d) {
                    HvaiActivity.this.AI_choise = StringFogImpl.decrypt("JzslRg==");
                }
                HvaiActivity.this._SET_BOTH_CHOICES();
                HvaiActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.HvaiActivity.1.1
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        HvaiActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.HvaiActivity.1.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                HvaiActivity.this.NEXT = true;
                                HvaiActivity.this._check_winner();
                            }
                        });
                    }
                };
                HvaiActivity.this._timer.schedule(HvaiActivity.this.timer, 1500L);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.HvaiActivity$2  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass2 implements View.OnClickListener {
        AnonymousClass2() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (HvaiActivity.this.NEXT) {
                HvaiActivity.this.imageview_selected.setImageResource(R.drawable.scissor);
                HvaiActivity.this.button1.setText(StringFogImpl.decrypt("BjcvXks6Jg=="));
                HvaiActivity.this.User_choice = StringFogImpl.decrypt("JjcvXks6Jg==");
                HvaiActivity.this.NEXT = false;
                HvaiActivity.this.Random = SketchwareUtil.getRandom(1, 3);
                if (HvaiActivity.this.Random == 1.0d) {
                    HvaiActivity.this.AI_choise = StringFogImpl.decrypt("JTU2SEo=");
                }
                if (HvaiActivity.this.Random == 2.0d) {
                    HvaiActivity.this.AI_choise = StringFogImpl.decrypt("JjcvXks6Jg==");
                }
                if (HvaiActivity.this.Random == 3.0d) {
                    HvaiActivity.this.AI_choise = StringFogImpl.decrypt("JzslRg==");
                }
                HvaiActivity.this._SET_BOTH_CHOICES();
                HvaiActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.HvaiActivity.2.1
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        HvaiActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.HvaiActivity.2.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                HvaiActivity.this.NEXT = true;
                                HvaiActivity.this._check_winner();
                            }
                        });
                    }
                };
                HvaiActivity.this._timer.schedule(HvaiActivity.this.timer, 1500L);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.HvaiActivity$3  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass3 implements View.OnClickListener {
        AnonymousClass3() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (HvaiActivity.this.NEXT) {
                HvaiActivity.this.imageview_selected.setImageResource(R.drawable.rock);
                HvaiActivity.this.button1.setText(StringFogImpl.decrypt("BzslRg=="));
                HvaiActivity.this.User_choice = StringFogImpl.decrypt("JzslRg==");
                HvaiActivity.this.NEXT = false;
                HvaiActivity.this.Random = SketchwareUtil.getRandom(1, 3);
                if (HvaiActivity.this.Random == 1.0d) {
                    HvaiActivity.this.AI_choise = StringFogImpl.decrypt("JTU2SEo=");
                }
                if (HvaiActivity.this.Random == 2.0d) {
                    HvaiActivity.this.AI_choise = StringFogImpl.decrypt("JjcvXks6Jg==");
                }
                if (HvaiActivity.this.Random == 3.0d) {
                    HvaiActivity.this.AI_choise = StringFogImpl.decrypt("JzslRg==");
                }
                HvaiActivity.this._SET_BOTH_CHOICES();
                HvaiActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.HvaiActivity.3.1
                    @Override // java.util.TimerTask, java.lang.Runnable
                    public void run() {
                        HvaiActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.HvaiActivity.3.1.1
                            @Override // java.lang.Runnable
                            public void run() {
                                HvaiActivity.this.NEXT = true;
                                HvaiActivity.this._check_winner();
                            }
                        });
                    }
                };
                HvaiActivity.this._timer.schedule(HvaiActivity.this.timer, 1500L);
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.HvaiActivity$4  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass4 implements View.OnClickListener {
        AnonymousClass4() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            if (HvaiActivity.this.User_choice.equals("")) {
                SketchwareUtil.showMessage(HvaiActivity.this.getApplicationContext(), StringFogImpl.decrypt("BTgjTEswdDVIVDA3Mg1ZOy0="));
                return;
            }
            HvaiActivity.this.Random = SketchwareUtil.getRandom(1, 3);
            if (HvaiActivity.this.Random == 1.0d) {
                HvaiActivity.this.AI_choise = StringFogImpl.decrypt("JTU2SEo=");
            }
            if (HvaiActivity.this.Random == 2.0d) {
                HvaiActivity.this.AI_choise = StringFogImpl.decrypt("JjcvXks6Jg==");
            }
            if (HvaiActivity.this.Random == 3.0d) {
                HvaiActivity.this.AI_choise = StringFogImpl.decrypt("JzslRg==");
            }
            HvaiActivity.this._SET_BOTH_CHOICES();
            HvaiActivity.this.timer = new TimerTask() { // from class: com.bgm.gfx.HvaiActivity.4.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    HvaiActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.HvaiActivity.4.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            HvaiActivity.this._check_winner();
                        }
                    });
                }
            };
            HvaiActivity.this._timer.schedule(HvaiActivity.this.timer, 1500L);
        }
    }

    private void initializeLogic() {
        this.textview_player.setText(StringFogImpl.decrypt("DBsT").concat(StringFogImpl.decrypt("dW4=")));
        this.Player_score = 0.0d;
        this.AI_score = 0.0d;
        this.NEXT = true;
        this.opponent_score.setText(String.valueOf((long) 0.0d));
        this.player_score.setText(String.valueOf((long) this.AI_score));
        _UI();
    }

    public void _Corner_Reduce(double d, double d2, double d3, String str, String str2, View view) {
        float f = (float) d3;
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(Color.parseColor(str2));
        gradientDrawable.setCornerRadius((float) d);
        gradientDrawable.setStroke((int) d2, Color.parseColor(str));
        view.setBackground(gradientDrawable);
        view.setElevation(f);
    }

    public void _UI() {
        this.edge = StringFogImpl.decrypt("dhIAa34TEg==");
        this.inside = StringFogImpl.decrypt("dmcAGAkXYQ==");
        String str = this.edge;
        _Corner_Reduce(200.0d, 3.0d, 10.0d, str, str, this.imageview_ai);
        String str2 = this.edge;
        _Corner_Reduce(200.0d, 3.0d, 10.0d, str2, str2, this.imageview_h);
        String str3 = this.edge;
        _Corner_Reduce(100.0d, 3.0d, 10.0d, str3, str3, this.imageview_paper);
        String str4 = this.edge;
        _Corner_Reduce(100.0d, 3.0d, 10.0d, str4, str4, this.imageview_scissor);
        String str5 = this.edge;
        _Corner_Reduce(100.0d, 3.0d, 10.0d, str5, str5, this.imageview_rock);
        String str6 = this.edge;
        _Corner_Reduce(100.0d, 3.0d, 10.0d, str6, str6, this.imageview_selected);
        String str7 = this.edge;
        _Corner_Reduce(50.0d, 3.0d, 10.0d, str7, str7, this.button1);
        _Corner_Reduce(140.0d, 3.0d, 10.0d, this.edge, this.inside, this.linear_option);
        _Corner_Reduce(140.0d, 3.0d, 10.0d, this.edge, this.inside, this.linear_submit);
        _Corner_Reduce(10.0d, 3.0d, 10.0d, this.edge, this.inside, this.linear_score);
        _Corner_Reduce(10.0d, 3.0d, 10.0d, this.inside, StringFogImpl.decrypt("dmF1G1wzMQ=="), this.linear8);
    }

    public void _check_winner() {
        if (this.User_choice.equals(this.AI_choise)) {
            SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("EQYHeg=="));
            _RESET();
            return;
        }
        if (this.User_choice.equals(StringFogImpl.decrypt("JTU2SEo=")) && this.AI_choise.equals(StringFogImpl.decrypt("JzslRg=="))) {
            _RESET();
            double d = this.Player_score + 1.0d;
            this.Player_score = d;
            this.player_score.setText(String.valueOf((long) d));
            CuteToast.ct((Context) this, (CharSequence) StringFogImpl.decrypt("DBsTDW8cGg=="), 0, CuteToast.HAPPY, true).show();
        }
        if (this.User_choice.equals(StringFogImpl.decrypt("JjcvXks6Jg==")) && this.AI_choise.equals(StringFogImpl.decrypt("JTU2SEo="))) {
            _RESET();
            double d2 = this.Player_score + 1.0d;
            this.Player_score = d2;
            this.player_score.setText(String.valueOf((long) d2));
            CuteToast.ct((Context) this, (CharSequence) StringFogImpl.decrypt("DBsTDW8cGg=="), 0, CuteToast.HAPPY, true).show();
        }
        if (this.User_choice.equals(StringFogImpl.decrypt("JzslRg==")) && this.AI_choise.equals(StringFogImpl.decrypt("JjcvXks6Jg=="))) {
            _RESET();
            double d3 = this.Player_score + 1.0d;
            this.Player_score = d3;
            this.player_score.setText(String.valueOf((long) d3));
            CuteToast.ct((Context) this, (CharSequence) StringFogImpl.decrypt("DBsTDW8cGg=="), 0, CuteToast.HAPPY, true).show();
        }
        if (this.AI_choise.equals(StringFogImpl.decrypt("JTU2SEo=")) && this.User_choice.equals(StringFogImpl.decrypt("JzslRg=="))) {
            _RESET();
            double d4 = this.AI_score + 1.0d;
            this.AI_score = d4;
            this.opponent_score.setText(String.valueOf((long) d4));
            CuteToast.ct((Context) this, (CharSequence) StringFogImpl.decrypt("DBsTDXQaGxVo"), 0, CuteToast.INFO, true).show();
        }
        if (this.AI_choise.equals(StringFogImpl.decrypt("JjcvXks6Jg==")) && this.User_choice.equals(StringFogImpl.decrypt("JTU2SEo="))) {
            _RESET();
            double d5 = this.AI_score + 1.0d;
            this.AI_score = d5;
            this.opponent_score.setText(String.valueOf((long) d5));
            CuteToast.ct((Context) this, (CharSequence) StringFogImpl.decrypt("DBsTDXQaGxVo"), 0, CuteToast.INFO, true).show();
        }
        if (this.AI_choise.equals(StringFogImpl.decrypt("JzslRg==")) && this.User_choice.equals(StringFogImpl.decrypt("JjcvXks6Jg=="))) {
            _RESET();
            double d6 = this.AI_score + 1.0d;
            this.AI_score = d6;
            this.opponent_score.setText(String.valueOf((long) d6));
            CuteToast.ct((Context) this, (CharSequence) StringFogImpl.decrypt("DBsTDXQaGxVo"), 0, CuteToast.INFO, true).show();
        }
    }

    public void _SET_BOTH_CHOICES() {
        if (this.User_choice.equals(StringFogImpl.decrypt("JTU2SEo="))) {
            this.imageview_h.setImageResource(R.drawable.paper);
        }
        if (this.User_choice.equals(StringFogImpl.decrypt("JjcvXks6Jg=="))) {
            this.imageview_h.setImageResource(R.drawable.scissor);
        }
        if (this.User_choice.equals(StringFogImpl.decrypt("JzslRg=="))) {
            this.imageview_h.setImageResource(R.drawable.rock);
        }
        if (this.AI_choise.equals(StringFogImpl.decrypt("JTU2SEo="))) {
            this.imageview_ai.setImageResource(R.drawable.paper);
        }
        if (this.AI_choise.equals(StringFogImpl.decrypt("JjcvXks6Jg=="))) {
            this.imageview_ai.setImageResource(R.drawable.scissor);
        }
        if (this.AI_choise.equals(StringFogImpl.decrypt("JzslRg=="))) {
            this.imageview_ai.setImageResource(R.drawable.rock);
        }
    }

    public void _RESET() {
        this.imageview_ai.setImageResource(R.drawable.icon_ai);
        this.imageview_h.setImageResource(R.drawable.icon_you);
        this.imageview_selected.setImageResource(R.drawable.icon_you);
        this.button1.setText(StringFogImpl.decrypt("DDsz"));
        this.User_choice = "";
        this.AI_choise = "";
    }

    @Deprecated
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, 0).show();
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    @Deprecated
    public int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList<Double> arrayList = new ArrayList<>();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf(checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int i) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, i, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
