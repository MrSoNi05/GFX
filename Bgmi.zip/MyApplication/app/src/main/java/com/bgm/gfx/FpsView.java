package com.bgm.gfx;

import android.annotation.TargetApi;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.os.Build;
import android.util.AttributeSet;
import android.util.Log;
import android.widget.TextView;
import androidx.core.view.ViewCompat;
import com.github.megatronking.stringfog.xor.StringFogImpl;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.LinkedList;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

/* loaded from: classes7.dex */
public class FpsView extends TextView {
    protected static final int DEFAULT_HISTORY_SIZE = 30;
    private static final double FPS_WEIGHT_RATE = 0.016666666666666666d;
    private static final double FPS_WEIGHT_RATIO = 0.03333333333333333d;
    boolean floatingWindowIsOn;
    private final NumberFormat mFormatter;
    private final LinkedList<Double> mFpsHistory;
    private TimerTask mFpsHistoryTask;
    private final Runnable mFpsRunner;
    private String mFpsValue;
    private double mFpsWeightRatio;
    private int mHistorySize;
    private long mLastFrame;
    private double mMsPerFrame;
    private final Paint mPaint;
    private boolean mPaused;
    private final RectF mRect;
    private final Timer mTimer;

    /* JADX INFO: Access modifiers changed from: private */
    /* loaded from: classes7.dex */
    public final class FpsHistoryTask extends TimerTask {
        private FpsHistoryTask() {
        }

        /* synthetic */ FpsHistoryTask(FpsView fpsView, FpsHistoryTask fpsHistoryTask) {
            this();
        }

        @Override // java.util.TimerTask, java.lang.Runnable
        public void run() {
            synchronized (FpsView.this.mFpsHistory) {
                double fps = FpsView.this.mLastFrame < System.currentTimeMillis() - 500 ? 0.0d : FpsView.this.getFps();
                if (FpsView.this.mFpsHistory.size() > FpsView.this.mHistorySize) {
                    FpsView.this.mFpsHistory.removeFirst();
                }
                String decrypt = StringFogImpl.decrypt("EyQ1e1EwIw==");
                Log.d(decrypt, StringFogImpl.decrypt("PT01WVcnLXwN") + fps);
                FpsView.this.mFpsHistory.add(Double.valueOf(fps));
            }
        }
    }

    public FpsView(Context context) {
        super(context);
        this.mFormatter = DecimalFormat.getInstance(Locale.ENGLISH);
        setFractionDigits(0);
        this.mHistorySize = 30;
        this.mFpsWeightRatio = 1.0d;
        this.mFpsValue = StringFogImpl.decrypt("ZXQAfWs=");
        this.floatingWindowIsOn = false;
        this.mFpsHistory = new LinkedList<>();
        this.mFpsRunner = new Runnable() { // from class: com.bgm.gfx.FpsView.1
            @Override // java.lang.Runnable
            public void run() {
                String format = FpsView.this.mFormatter.format(FpsView.this.getFps());
                FpsView fpsView = FpsView.this;
                fpsView.mFpsValue = String.valueOf(format) + StringFogImpl.decrypt("dRIWfg==");
                FpsView fpsView2 = FpsView.this;
                fpsView2.setText(fpsView2.mFpsValue);
                BgmiActivity.fpsValue = FpsView.this.mFpsValue;
            }
        };
        this.mTimer = new Timer();
        this.mRect = new RectF();
        this.mPaint = new Paint();
        init(context, null, 0);
    }

    public FpsView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.mFormatter = DecimalFormat.getInstance(Locale.ENGLISH);
        setFractionDigits(0);
        this.mHistorySize = 30;
        this.mFpsWeightRatio = 1.0d;
        this.mFpsValue = StringFogImpl.decrypt("ZXQAfWs=");
        this.floatingWindowIsOn = false;
        this.mFpsHistory = new LinkedList<>();
        this.mFpsRunner = new Runnable() { // from class: com.bgm.gfx.FpsView.1
            @Override // java.lang.Runnable
            public void run() {
                String format = FpsView.this.mFormatter.format(FpsView.this.getFps());
                FpsView fpsView = FpsView.this;
                fpsView.mFpsValue = String.valueOf(format) + StringFogImpl.decrypt("dRIWfg==");
                FpsView fpsView2 = FpsView.this;
                fpsView2.setText(fpsView2.mFpsValue);
                BgmiActivity.fpsValue = FpsView.this.mFpsValue;
            }
        };
        this.mTimer = new Timer();
        this.mRect = new RectF();
        this.mPaint = new Paint();
        init(context, attributeSet, 0);
    }

    public FpsView(Context context, AttributeSet attributeSet, int i) {
        super(context, attributeSet, i);
        this.mFormatter = DecimalFormat.getInstance(Locale.ENGLISH);
        setFractionDigits(0);
        this.mHistorySize = 30;
        this.mFpsWeightRatio = 1.0d;
        this.mFpsValue = StringFogImpl.decrypt("ZXQAfWs=");
        this.floatingWindowIsOn = false;
        this.mFpsHistory = new LinkedList<>();
        this.mFpsRunner = new Runnable() { // from class: com.bgm.gfx.FpsView.1
            @Override // java.lang.Runnable
            public void run() {
                String format = FpsView.this.mFormatter.format(FpsView.this.getFps());
                FpsView fpsView = FpsView.this;
                fpsView.mFpsValue = String.valueOf(format) + StringFogImpl.decrypt("dRIWfg==");
                FpsView fpsView2 = FpsView.this;
                fpsView2.setText(fpsView2.mFpsValue);
                BgmiActivity.fpsValue = FpsView.this.mFpsValue;
            }
        };
        this.mTimer = new Timer();
        this.mRect = new RectF();
        this.mPaint = new Paint();
        init(context, attributeSet, i);
    }

    private void init(Context context, AttributeSet attributeSet, int i) {
        setBackgroundColor(-16711936);
        this.mPaint.setColor(ViewCompat.MEASURED_STATE_MASK);
    }

    @Override // android.widget.TextView, android.view.View
    protected void onDraw(Canvas canvas) {
        double d = this.mFpsWeightRatio;
        double currentTimeMillis = (System.currentTimeMillis() - this.mLastFrame) * d;
        if (d > FPS_WEIGHT_RATIO) {
            double d2 = d - FPS_WEIGHT_RATE;
            this.mFpsWeightRatio = d2;
            if (d2 < FPS_WEIGHT_RATIO) {
                this.mFpsWeightRatio = FPS_WEIGHT_RATIO;
            }
        }
        this.mMsPerFrame = (this.mMsPerFrame * (1.0d - this.mFpsWeightRatio)) + currentTimeMillis;
        this.mLastFrame = System.currentTimeMillis();
        super.onDraw(canvas);
        if (this.mFpsHistoryTask != null) {
            nextFrame();
        }
    }

    @TargetApi(16)
    protected void nextFrame() {
        if (Build.VERSION.SDK_INT >= 16) {
            postOnAnimation(this.mFpsRunner);
        } else {
            post(this.mFpsRunner);
        }
    }

    protected double getFps() {
        double d = this.mMsPerFrame;
        if (d > 0.0d) {
            return 1000.0d / d;
        }
        return 0.0d;
    }

    @Override // android.view.View
    protected void onWindowVisibilityChanged(int i) {
        super.onWindowVisibilityChanged(i);
        if (i == 0) {
            if (this.mPaused) {
                return;
            }
            resume(false);
        } else if ((i == 4 || i == 8) && !this.mPaused) {
            pause(false);
        }
    }

    public void resume() {
        resume(true);
    }

    protected void resume(boolean z) {
        if (z) {
            this.mPaused = false;
        }
        if (this.mFpsHistoryTask == null) {
            FpsHistoryTask fpsHistoryTask = new FpsHistoryTask(this, null);
            this.mFpsHistoryTask = fpsHistoryTask;
            this.mTimer.scheduleAtFixedRate(fpsHistoryTask, 500L, 2500L);
        }
    }

    public void pause() {
        pause(true);
    }

    protected void pause(boolean z) {
        if (z) {
            this.mPaused = true;
        }
        if (this.mFpsHistoryTask != null) {
            removeCallbacks(this.mFpsRunner);
            this.mFpsHistoryTask.cancel();
            this.mFpsHistoryTask = null;
        }
    }

    public void setHistorySize(int i) {
        this.mHistorySize = i;
    }

    public void setFractionDigits(int i) {
        this.mFormatter.setMinimumFractionDigits(i);
        this.mFormatter.setMaximumFractionDigits(i);
    }
}
