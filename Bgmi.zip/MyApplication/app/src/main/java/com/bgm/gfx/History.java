package com.bgm.gfx;

import android.content.Context;
import android.content.SharedPreferences;

/* loaded from: classes7.dex */
public class History {
    private SharedPreferences date;

    public final void setScore(Context context, String str, long j) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(str, 0);
        this.date = sharedPreferences;
        sharedPreferences.edit().putLong(str, j).apply();
    }

    public final long getScore(Context context, String str) {
        SharedPreferences sharedPreferences = context.getSharedPreferences(str, 0);
        this.date = sharedPreferences;
        if (sharedPreferences.contains(str)) {
            return this.date.getLong(str, 0L);
        }
        return 0L;
    }
}
