package com.bgm.gfx;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.view.Window;
import android.view.animation.LinearInterpolator;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.github.megatronking.stringfog.xor.StringFogImpl;
import com.google.firebase.FirebaseApp;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

/* loaded from: classes7.dex */
public class GameActivity extends AppCompatActivity {
    private SharedPreferences SCORE;
    private TimerTask adss;
    private TimerTask bg;
    private TimerTask duration_time;
    private TextView high_score;
    private LinearLayout l1;
    private LinearLayout l2;
    private LinearLayout l3;
    private LinearLayout l4;
    private LinearLayout linear1;
    private LinearLayout linear_out;
    private LinearLayout linear_top_child;
    private MediaPlayer md;
    private TimerTask out;
    private LinearLayout parent;
    private LinearLayout parent_child;
    private SharedPreferences sp;
    private LinearLayout tile1;
    private LinearLayout tile2;
    private LinearLayout tile3;
    private LinearLayout tile4;
    private TimerTask tt1;
    private TimerTask tt2;
    private TimerTask tt3;
    private TimerTask tt4;
    private TextView txt_credit;
    private TextView txt_out;
    private TextView txt_retry;
    private TextView txt_score;
    private Vibrator v;
    private Timer _timer = new Timer();
    private double returnNumber = 0.0d;
    private double s1 = 0.0d;
    private double s2 = 0.0d;
    private double s3 = 0.0d;
    private double s4 = 0.0d;
    private boolean STOPE = false;
    private double duration = 0.0d;
    private double addd = 0.0d;
    private ObjectAnimator t1 = new ObjectAnimator();
    private ObjectAnimator t2 = new ObjectAnimator();
    private ObjectAnimator t3 = new ObjectAnimator();
    private ObjectAnimator t4 = new ObjectAnimator();
    private Intent i = new Intent();
    private Intent link = new Intent();

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.game);
        initialize(bundle);
          //   FirebaseApp.initializeApp(String.valueOf(this));
        initializeLogic();
    }

    private void initialize(Bundle bundle) {
        this.parent = (LinearLayout) findViewById(R.id.parent);
        this.linear_top_child = (LinearLayout) findViewById(R.id.linear_top_child);
        this.parent_child = (LinearLayout) findViewById(R.id.parent_child);
        this.linear_out = (LinearLayout) findViewById(R.id.linear_out);
        this.txt_credit = (TextView) findViewById(R.id.txt_credit);
        this.high_score = (TextView) findViewById(R.id.high_score);
        this.linear1 = (LinearLayout) findViewById(R.id.linear1);
        this.txt_score = (TextView) findViewById(R.id.txt_score);
        this.l1 = (LinearLayout) findViewById(R.id.l1);
        this.l2 = (LinearLayout) findViewById(R.id.l2);
        this.l3 = (LinearLayout) findViewById(R.id.l3);
        this.l4 = (LinearLayout) findViewById(R.id.l4);
        this.tile1 = (LinearLayout) findViewById(R.id.tile1);
        this.tile2 = (LinearLayout) findViewById(R.id.tile2);
        this.tile3 = (LinearLayout) findViewById(R.id.tile3);
        this.tile4 = (LinearLayout) findViewById(R.id.tile4);
        this.txt_out = (TextView) findViewById(R.id.txt_out);
        this.txt_retry = (TextView) findViewById(R.id.txt_retry);
        this.SCORE = getSharedPreferences(StringFogImpl.decrypt("BhcJf30="), 0);
        this.v = (Vibrator) getSystemService(StringFogImpl.decrypt("Iz0kX1khOzQ="));
        this.sp = getSharedPreferences(StringFogImpl.decrypt("JiQ="), 0);
        this.tile1.setOnClickListener(new AnonymousClass1());
        this.tile2.setOnClickListener(new AnonymousClass2());
        this.tile3.setOnClickListener(new AnonymousClass3());
        this.tile4.setOnClickListener(new AnonymousClass4());
        this.txt_retry.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.GameActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                GameActivity.this.recreate();
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.GameActivity$1  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass1 implements View.OnClickListener {
        AnonymousClass1() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            GameActivity.this.tile1.setAlpha(0.3f);
            GameActivity.this.txt_score.setText(String.valueOf((long) (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) + 5.0d)));
            GameActivity.this.tt1 = new TimerTask() { // from class: com.bgm.gfx.GameActivity.1.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    GameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.GameActivity.1.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            GameActivity.this.tile1.setAlpha(1.0f);
                            GameActivity.this._PickRandom1(SketchwareUtil.getRandom(1, 6));
                        }
                    });
                }
            };
            GameActivity.this._timer.schedule(GameActivity.this.tt1, 100L);
            GameActivity.this.v.vibrate(50L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.GameActivity$2  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass2 implements View.OnClickListener {
        AnonymousClass2() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            GameActivity.this.tile2.setAlpha(0.3f);
            GameActivity.this.txt_score.setText(String.valueOf((long) (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) + 5.0d)));
            GameActivity.this.tt2 = new TimerTask() { // from class: com.bgm.gfx.GameActivity.2.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    GameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.GameActivity.2.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            GameActivity.this.tile2.setAlpha(1.0f);
                            GameActivity.this._PickRandom2(SketchwareUtil.getRandom(1, 6));
                        }
                    });
                }
            };
            GameActivity.this._timer.schedule(GameActivity.this.tt2, 100L);
            GameActivity.this.v.vibrate(50L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.GameActivity$3  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass3 implements View.OnClickListener {
        AnonymousClass3() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            GameActivity.this.tile3.setAlpha(0.3f);
            GameActivity.this.txt_score.setText(String.valueOf((long) (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) + 5.0d)));
            GameActivity.this.tt3 = new TimerTask() { // from class: com.bgm.gfx.GameActivity.3.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    GameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.GameActivity.3.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            GameActivity.this.tile3.setAlpha(1.0f);
                            GameActivity.this._PickRandom3(SketchwareUtil.getRandom(1, 6));
                        }
                    });
                }
            };
            GameActivity.this._timer.schedule(GameActivity.this.tt3, 100L);
            GameActivity.this.v.vibrate(50L);
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.GameActivity$4  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass4 implements View.OnClickListener {
        AnonymousClass4() {
        }

        @Override // android.view.View.OnClickListener
        public void onClick(View view) {
            GameActivity.this.tile4.setAlpha(0.3f);
            GameActivity.this.txt_score.setText(String.valueOf((long) (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) + 5.0d)));
            GameActivity.this.tt4 = new TimerTask() { // from class: com.bgm.gfx.GameActivity.4.1
                @Override // java.util.TimerTask, java.lang.Runnable
                public void run() {
                    GameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.GameActivity.4.1.1
                        @Override // java.lang.Runnable
                        public void run() {
                            GameActivity.this.tile4.setAlpha(1.0f);
                            GameActivity.this._PickRandom4(SketchwareUtil.getRandom(1, 6));
                        }
                    });
                }
            };
            GameActivity.this._timer.schedule(GameActivity.this.tt4, 100L);
            GameActivity.this.v.vibrate(50L);
        }
    }

    private void initializeLogic() {
        _NavStatusBarColor(StringFogImpl.decrypt("djIgH11nMnMZ"), StringFogImpl.decrypt("dhIAa34TEg=="));
        _PickRandom1(SketchwareUtil.getRandom(1, 6));
        _PickRandom2(SketchwareUtil.getRandom(1, 6));
        _PickRandom3(SketchwareUtil.getRandom(1, 6));
        _PickRandom4(SketchwareUtil.getRandom(1, 6));
        _parent_bg();
        this.linear_out.setVisibility(8);
        this.linear_out.setTranslationY(SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) * (-1));
        if (!this.sp.getString(StringFogImpl.decrypt("ZA=="), "").equals("")) {
            this.high_score.setText(this.sp.getString(StringFogImpl.decrypt("ZA=="), ""));
        }
        TimerTask timerTask = new TimerTask() { // from class: com.bgm.gfx.GameActivity.6
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                GameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.GameActivity.6.1
                    @Override // java.lang.Runnable
                    public void run() {
                        if (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) > Double.parseDouble(GameActivity.this.high_score.getText().toString())) {
                            GameActivity.this.high_score.setText(GameActivity.this.txt_score.getText().toString());
                            GameActivity.this.sp.edit().putString(StringFogImpl.decrypt("ZA=="), GameActivity.this.txt_score.getText().toString()).commit();
                        }
                    }
                });
            }
        };
        this.duration_time = timerTask;
        this._timer.scheduleAtFixedRate(timerTask, 200L, 100L);
        TimerTask timerTask2 = new TimerTask() { // from class: com.bgm.gfx.GameActivity.7
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                GameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.GameActivity.7.1
                    @Override // java.lang.Runnable
                    public void run() {
                        try {
                            File file = new File(GameActivity.this.getCacheDir(), StringFogImpl.decrypt("OGVoQEhm"));
                            if (!file.exists()) {
                                try {
                                    InputStream open = GameActivity.this.getAssets().open(StringFogImpl.decrypt("OGVoQEhm"));
                                    FileOutputStream fileOutputStream = new FileOutputStream(file);
                                    byte[] bArr = new byte[1024];
                                    while (true) {
                                        int read = open.read(bArr);
                                        if (read == -1) {
                                            break;
                                        }
                                        fileOutputStream.write(bArr, 0, read);
                                    }
                                    open.close();
                                    fileOutputStream.close();
                                } catch (Exception unused) {
                                }
                            }
                            GameActivity.this.md = MediaPlayer.create(GameActivity.this.getApplicationContext(), Uri.fromFile(new File(file.getAbsolutePath())));
                            GameActivity.this.md.setLooping(true);
                            GameActivity.this.md.start();
                        } catch (Exception unused2) {
                            SketchwareUtil.showMessage(GameActivity.this.getApplicationContext(), StringFogImpl.decrypt("GAEVZHt1ERR/dwc="));
                        }
                    }
                });
            }
        };
        this.tt3 = timerTask2;
        this._timer.schedule(timerTask2, 1000L);
        TimerTask timerTask3 = new TimerTask() { // from class: com.bgm.gfx.GameActivity.8
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                GameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.GameActivity.8.1
                    @Override // java.lang.Runnable
                    public void run() {
                        if (!GameActivity.this.t1.isRunning()) {
                            GameActivity.this.l1.setBackgroundColor(-12846);
                            GameActivity.this.linear_out.setVisibility(0);
                            GameActivity.this.tile1.setEnabled(false);
                            GameActivity.this.tile2.setEnabled(false);
                            GameActivity.this.tile3.setEnabled(false);
                            GameActivity.this.tile4.setEnabled(false);
                            GameActivity.this.md.pause();
                        }
                        if (!GameActivity.this.t2.isRunning()) {
                            GameActivity.this.l2.setBackgroundColor(-12846);
                            GameActivity.this.linear_out.setVisibility(0);
                            GameActivity.this.tile1.setEnabled(false);
                            GameActivity.this.tile2.setEnabled(false);
                            GameActivity.this.tile3.setEnabled(false);
                            GameActivity.this.tile4.setEnabled(false);
                            GameActivity.this.md.pause();
                        }
                        if (!GameActivity.this.t3.isRunning()) {
                            GameActivity.this.l3.setBackgroundColor(-12846);
                            GameActivity.this.linear_out.setVisibility(0);
                            GameActivity.this.tile1.setEnabled(false);
                            GameActivity.this.tile2.setEnabled(false);
                            GameActivity.this.tile3.setEnabled(false);
                            GameActivity.this.tile4.setEnabled(false);
                            GameActivity.this.md.pause();
                        }
                        if (!GameActivity.this.t4.isRunning()) {
                            GameActivity.this.l4.setBackgroundColor(-12846);
                            GameActivity.this.linear_out.setVisibility(0);
                            GameActivity.this.tile1.setEnabled(false);
                            GameActivity.this.tile2.setEnabled(false);
                            GameActivity.this.tile3.setEnabled(false);
                            GameActivity.this.tile4.setEnabled(false);
                            GameActivity.this.md.pause();
                        }
                        if (GameActivity.this.t1.isRunning() && GameActivity.this.t2.isRunning() && GameActivity.this.t3.isRunning() && GameActivity.this.t4.isRunning()) {
                            return;
                        }
                        GameActivity.this.STOPE = true;
                        GameActivity.this.out.cancel();
                    }
                });
            }
        };
        this.out = timerTask3;
        this._timer.scheduleAtFixedRate(timerTask3, 2500L, 10L);
        this.l1.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.GameActivity.9
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (GameActivity.this.STOPE) {
                    return;
                }
                GameActivity.this.l1.setBackgroundColor(-12846);
                GameActivity.this.linear_out.setVisibility(0);
                GameActivity.this.tile1.setEnabled(false);
                GameActivity.this.tile2.setEnabled(false);
                GameActivity.this.tile3.setEnabled(false);
                GameActivity.this.tile4.setEnabled(false);
                GameActivity.this.md.pause();
                GameActivity.this.STOPE = true;
                GameActivity.this.out.cancel();
            }
        });
        this.l2.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.GameActivity.10
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (GameActivity.this.STOPE) {
                    return;
                }
                GameActivity.this.l2.setBackgroundColor(-12846);
                GameActivity.this.linear_out.setVisibility(0);
                GameActivity.this.tile1.setEnabled(false);
                GameActivity.this.tile2.setEnabled(false);
                GameActivity.this.tile3.setEnabled(false);
                GameActivity.this.tile4.setEnabled(false);
                GameActivity.this.STOPE = true;
                GameActivity.this.out.cancel();
                GameActivity.this.md.pause();
            }
        });
        this.l3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.GameActivity.11
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (GameActivity.this.STOPE) {
                    return;
                }
                GameActivity.this.l3.setBackgroundColor(-12846);
                GameActivity.this.linear_out.setVisibility(0);
                GameActivity.this.tile1.setEnabled(false);
                GameActivity.this.tile2.setEnabled(false);
                GameActivity.this.tile3.setEnabled(false);
                GameActivity.this.tile4.setEnabled(false);
                GameActivity.this.STOPE = true;
                GameActivity.this.md.pause();
                GameActivity.this.out.cancel();
            }
        });
        this.l4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.GameActivity.12
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (GameActivity.this.STOPE) {
                    return;
                }
                GameActivity.this.l4.setBackgroundColor(-12846);
                GameActivity.this.linear_out.setVisibility(0);
                GameActivity.this.tile1.setEnabled(false);
                GameActivity.this.tile2.setEnabled(false);
                GameActivity.this.tile3.setEnabled(false);
                GameActivity.this.tile4.setEnabled(false);
                GameActivity.this.STOPE = true;
                GameActivity.this.md.pause();
                GameActivity.this.out.cancel();
            }
        });
        TimerTask timerTask4 = new TimerTask() { // from class: com.bgm.gfx.GameActivity.13
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                GameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.GameActivity.13.1
                    @Override // java.lang.Runnable
                    public void run() {
                        if (GameActivity.this.duration != 2000.0d) {
                            GameActivity.this.duration += 100.0d;
                        }
                    }
                });
            }
        };
        this.duration_time = timerTask4;
        this._timer.scheduleAtFixedRate(timerTask4, 20000L, 5000L);
        TimerTask timerTask5 = new TimerTask() { // from class: com.bgm.gfx.GameActivity.14
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                GameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.GameActivity.14.1
                    @Override // java.lang.Runnable
                    public void run() {
                        if (GameActivity.this.STOPE) {
                            GameActivity.this.adss.cancel();
                        }
                    }
                });
            }
        };
        this.adss = timerTask5;
        this._timer.scheduleAtFixedRate(timerTask5, 1000L, 2000L);
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onStop() {
        super.onStop();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onResume() {
        super.onResume();
    }

    @Override // androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onPause() {
        super.onPause();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        try {
            if (this.md.isPlaying()) {
                this.md.pause();
            }
        } catch (Exception unused) {
            SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("e3poAxZ7emg="));
        }
        this.out.cancel();
        this.tt3.cancel();
        this.i.setClass(getApplicationContext(), MainActivity.class);
        finish();
    }

    public void _PickRandom1(double d) {
        if (d == 1.0d) {
            this.t1.setTarget(this.tile1);
            this.t1.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t1.setFloatValues(-1500.0f, 1500.0f);
            this.t1.setDuration((int) (3000.0d - this.duration));
            this.t1.setInterpolator(new LinearInterpolator());
            this.t1.start();
        }
        if (d == 2.0d) {
            this.t1.setTarget(this.tile1);
            this.t1.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t1.setFloatValues(-1500.0f, 1500.0f);
            this.t1.setDuration((int) (3100.0d - this.duration));
            this.t1.setInterpolator(new LinearInterpolator());
            this.t1.start();
        }
        if (d == 3.0d) {
            this.t1.setTarget(this.tile1);
            this.t1.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t1.setFloatValues(-1500.0f, 1500.0f);
            this.t1.setDuration((int) (3200.0d - this.duration));
            this.t1.setInterpolator(new LinearInterpolator());
            this.t1.start();
        }
        if (d == 4.0d) {
            this.t1.setTarget(this.tile1);
            this.t1.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t1.setFloatValues(-1500.0f, 1500.0f);
            this.t1.setDuration((int) (3300.0d - this.duration));
            this.t1.setInterpolator(new LinearInterpolator());
            this.t1.start();
        }
        if (d == 5.0d) {
            this.t1.setTarget(this.tile1);
            this.t1.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t1.setFloatValues(-1500.0f, 1500.0f);
            this.t1.setDuration((int) (3400.0d - this.duration));
            this.t1.setInterpolator(new LinearInterpolator());
            this.t1.start();
        }
        if (d == 6.0d) {
            this.t1.setTarget(this.tile1);
            this.t1.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t1.setFloatValues(-1500.0f, 1500.0f);
            this.t1.setDuration((int) (3500.0d - this.duration));
            this.t1.setInterpolator(new LinearInterpolator());
            this.t1.start();
        }
    }

    public void _PickRandom2(double d) {
        if (d == 1.0d) {
            this.t2.setTarget(this.tile2);
            this.t2.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t2.setFloatValues(-1500.0f, 1500.0f);
            this.t2.setDuration((int) (3000.0d - this.duration));
            this.t2.setInterpolator(new LinearInterpolator());
            this.t2.start();
        }
        if (d == 2.0d) {
            this.t2.setTarget(this.tile2);
            this.t2.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t2.setFloatValues(-1500.0f, 1500.0f);
            this.t2.setDuration((int) (3100.0d - this.duration));
            this.t2.setInterpolator(new LinearInterpolator());
            this.t2.start();
        }
        if (d == 3.0d) {
            this.t2.setTarget(this.tile2);
            this.t2.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t2.setFloatValues(-1500.0f, 1500.0f);
            this.t2.setDuration((int) (3200.0d - this.duration));
            this.t2.setInterpolator(new LinearInterpolator());
            this.t2.start();
        }
        if (d == 4.0d) {
            this.t2.setTarget(this.tile2);
            this.t2.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t2.setFloatValues(-1500.0f, 1500.0f);
            this.t2.setDuration((int) (3300.0d - this.duration));
            this.t2.setInterpolator(new LinearInterpolator());
            this.t2.start();
        }
        if (d == 5.0d) {
            this.t2.setTarget(this.tile2);
            this.t2.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t2.setFloatValues(-1500.0f, 1500.0f);
            this.t2.setDuration((int) (3400.0d - this.duration));
            this.t2.setInterpolator(new LinearInterpolator());
            this.t2.start();
        }
        if (d == 6.0d) {
            this.t2.setTarget(this.tile2);
            this.t2.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t2.setFloatValues(-1500.0f, 1500.0f);
            this.t2.setDuration((int) (3500.0d - this.duration));
            this.t2.setInterpolator(new LinearInterpolator());
            this.t2.start();
        }
    }

    public void _PickRandom3(double d) {
        if (d == 1.0d) {
            this.t3.setTarget(this.tile3);
            this.t3.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t3.setFloatValues(-1500.0f, 1500.0f);
            this.t3.setDuration((int) (3000.0d - this.duration));
            this.t3.setInterpolator(new LinearInterpolator());
            this.t3.start();
        }
        if (d == 2.0d) {
            this.t3.setTarget(this.tile3);
            this.t3.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t3.setFloatValues(-1500.0f, 1500.0f);
            this.t3.setDuration((int) (3100.0d - this.duration));
            this.t3.setInterpolator(new LinearInterpolator());
            this.t3.start();
        }
        if (d == 3.0d) {
            this.t3.setTarget(this.tile3);
            this.t3.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t3.setFloatValues(-1500.0f, 1500.0f);
            this.t3.setDuration((int) (3200.0d - this.duration));
            this.t3.setInterpolator(new LinearInterpolator());
            this.t3.start();
        }
        if (d == 4.0d) {
            this.t3.setTarget(this.tile3);
            this.t3.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t3.setFloatValues(-1500.0f, 1500.0f);
            this.t3.setDuration((int) (3300.0d - this.duration));
            this.t3.setInterpolator(new LinearInterpolator());
            this.t3.start();
        }
        if (d == 5.0d) {
            this.t3.setTarget(this.tile3);
            this.t3.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t3.setFloatValues(-1500.0f, 1500.0f);
            this.t3.setDuration((int) (3400.0d - this.duration));
            this.t3.setInterpolator(new LinearInterpolator());
            this.t3.start();
        }
        if (d == 6.0d) {
            this.t3.setTarget(this.tile3);
            this.t3.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t3.setFloatValues(-1500.0f, 1500.0f);
            this.t3.setDuration((int) (3500.0d - this.duration));
            this.t3.setInterpolator(new LinearInterpolator());
            this.t3.start();
        }
    }

    public void _PickRandom4(double d) {
        if (d == 1.0d) {
            this.t4.setTarget(this.tile4);
            this.t4.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t4.setFloatValues(-1500.0f, 1500.0f);
            this.t4.setDuration((int) (3000.0d - this.duration));
            this.t4.setInterpolator(new LinearInterpolator());
            this.t4.start();
        }
        if (d == 2.0d) {
            this.t4.setTarget(this.tile4);
            this.t4.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t4.setFloatValues(-1500.0f, 1500.0f);
            this.t4.setDuration((int) (3100.0d - this.duration));
            this.t4.setInterpolator(new LinearInterpolator());
            this.t4.start();
        }
        if (d == 3.0d) {
            this.t4.setTarget(this.tile4);
            this.t4.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t4.setFloatValues(-1500.0f, 1500.0f);
            this.t4.setDuration((int) (3200.0d - this.duration));
            this.t4.setInterpolator(new LinearInterpolator());
            this.t4.start();
        }
        if (d == 4.0d) {
            this.t4.setTarget(this.tile4);
            this.t4.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t4.setFloatValues(-1500.0f, 1500.0f);
            this.t4.setDuration((int) (3300.0d - this.duration));
            this.t4.setInterpolator(new LinearInterpolator());
            this.t4.start();
        }
        if (d == 5.0d) {
            this.t4.setTarget(this.tile4);
            this.t4.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t4.setFloatValues(-1500.0f, 1500.0f);
            this.t4.setDuration((int) (3400.0d - this.duration));
            this.t4.setInterpolator(new LinearInterpolator());
            this.t4.start();
        }
        if (d == 6.0d) {
            this.t4.setTarget(this.tile4);
            this.t4.setPropertyName(StringFogImpl.decrypt("ISYnQ0s5NTJEVzsN"));
            this.t4.setFloatValues(-1500.0f, 1500.0f);
            this.t4.setDuration((int) (3500.0d - this.duration));
            this.t4.setInterpolator(new LinearInterpolator());
            this.t4.start();
        }
    }

    public void _parent_bg() {
        TimerTask timerTask = new TimerTask() { // from class: com.bgm.gfx.GameActivity.15
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                GameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.GameActivity.15.1
                    @Override // java.lang.Runnable
                    public void run() {
                        if (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) > 0.0d && Double.parseDouble(GameActivity.this.txt_score.getText().toString()) < 500.0d) {
                            GameActivity.this.parent.setBackgroundResource(R.drawable.parent_bg_1);
                        } else if (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) > 500.0d && Double.parseDouble(GameActivity.this.txt_score.getText().toString()) < 1000.0d) {
                            GameActivity.this.parent.setBackgroundResource(R.drawable.parent_bg_2);
                        } else if (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) > 1000.0d && Double.parseDouble(GameActivity.this.txt_score.getText().toString()) < 1500.0d) {
                            GameActivity.this.parent.setBackgroundResource(R.drawable.parent_bg_3);
                        } else if (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) > 1500.0d && Double.parseDouble(GameActivity.this.txt_score.getText().toString()) < 2000.0d) {
                            GameActivity.this.parent.setBackgroundResource(R.drawable.parent_bg_4);
                        } else if (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) > 2000.0d && Double.parseDouble(GameActivity.this.txt_score.getText().toString()) < 2500.0d) {
                            GameActivity.this.parent.setBackgroundResource(R.drawable.parent_bg_1);
                        } else if (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) > 2500.0d && Double.parseDouble(GameActivity.this.txt_score.getText().toString()) < 3000.0d) {
                            GameActivity.this.parent.setBackgroundResource(R.drawable.parent_bg_2);
                        } else if (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) > 3000.0d && Double.parseDouble(GameActivity.this.txt_score.getText().toString()) < 3500.0d) {
                            GameActivity.this.parent.setBackgroundResource(R.drawable.parent_bg_3);
                        } else if (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) > 3500.0d && Double.parseDouble(GameActivity.this.txt_score.getText().toString()) < 4000.0d) {
                            GameActivity.this.parent.setBackgroundResource(R.drawable.parent_bg_4);
                        } else if (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) > 4000.0d && Double.parseDouble(GameActivity.this.txt_score.getText().toString()) < 4500.0d) {
                            GameActivity.this.parent.setBackgroundResource(R.drawable.parent_bg_2);
                        } else if (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) > 4500.0d && Double.parseDouble(GameActivity.this.txt_score.getText().toString()) < 5000.0d) {
                            GameActivity.this.parent.setBackgroundResource(R.drawable.parent_bg_3);
                        } else if (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) > 5000.0d && Double.parseDouble(GameActivity.this.txt_score.getText().toString()) < 5500.0d) {
                            GameActivity.this.parent.setBackgroundResource(R.drawable.parent_bg_4);
                        } else if (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) > 5500.0d && Double.parseDouble(GameActivity.this.txt_score.getText().toString()) < 6000.0d) {
                            GameActivity.this.parent.setBackgroundResource(R.drawable.parent_bg_1);
                        } else if (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) > 6000.0d && Double.parseDouble(GameActivity.this.txt_score.getText().toString()) < 6500.0d) {
                            GameActivity.this.parent.setBackgroundResource(R.drawable.parent_bg_2);
                        } else if (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) > 6500.0d && Double.parseDouble(GameActivity.this.txt_score.getText().toString()) < 7000.0d) {
                            GameActivity.this.parent.setBackgroundResource(R.drawable.parent_bg_3);
                        } else if (Double.parseDouble(GameActivity.this.txt_score.getText().toString()) > 7000.0d) {
                            GameActivity.this.parent.setBackgroundResource(R.drawable.parent_bg_4);
                        }
                    }
                });
            }
        };
        this.bg = timerTask;
        this._timer.scheduleAtFixedRate(timerTask, 0L, 100L);
    }

    public void _NavStatusBarColor(String str, String str2) {
        if (Build.VERSION.SDK_INT > 21) {
            Window window = getWindow();
            window.clearFlags(67108864);
            window.addFlags(Integer.MIN_VALUE);
            window.setStatusBarColor(Color.parseColor(StringFogImpl.decrypt("dg==") + str.replace(StringFogImpl.decrypt("dg=="), "")));
            window.setNavigationBarColor(Color.parseColor(StringFogImpl.decrypt("dg==") + str2.replace(StringFogImpl.decrypt("dg=="), "")));
        }
    }

    @Deprecated
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, 0).show();
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    @Deprecated
    public int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList<Double> arrayList = new ArrayList<>();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf(checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int i) {
        return TypedValue.applyDimension(1, i, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
