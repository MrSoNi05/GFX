package com.bgm.gfx;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;
import com.github.megatronking.stringfog.xor.StringFogImpl;

/* loaded from: classes7.dex */
public class NotificationClickReceiver extends BroadcastReceiver {
    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        Toast.makeText(context, StringFogImpl.decrypt("GzsyRF48NydZUTo6Zm5UPDctSFw="), 0).show();
    }
}
