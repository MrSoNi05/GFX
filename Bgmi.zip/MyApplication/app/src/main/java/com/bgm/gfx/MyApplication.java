package com.bgm.gfx;

import android.annotation.SuppressLint;
import android.app.AlarmManager;
import android.app.Application;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Process;

import com.github.megatronking.stringfog.xor.StringFogImpl;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import java.io.PrintWriter;
import java.io.StringWriter;
import java.lang.Thread;

/* loaded from: classes7.dex */
public class MyApplication extends Application {
    private static AppOpenManager appOpenManager;
    private Thread.UncaughtExceptionHandler uncaughtExceptionHandler;

    @SuppressLint("MissingSuperCall")
    @Override // android.app.Application
    public void onCreate() {
        super.onCreate();
        MobileAds.initialize(this, new OnInitializationCompleteListener() { // from class: com.bgm.gfx.MyApplication.1
            @Override // com.google.android.gms.ads.initialization.OnInitializationCompleteListener
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        appOpenManager = new AppOpenManager(this);
        this.uncaughtExceptionHandler = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() { // from class: com.bgm.gfx.MyApplication.2
            @Override // java.lang.Thread.UncaughtExceptionHandler
            public void uncaughtException(Thread thread, Throwable th) {
                Intent intent = new Intent(MyApplication.this.getApplicationContext(), DebugNewMainActivity.class);
                intent.setFlags(32768);
                intent.putExtra(StringFogImpl.decrypt("MCY0Qko="), MyApplication.this.getStackTrace(th));
                ((AlarmManager) MyApplication.this.getSystemService(StringFogImpl.decrypt("NDgnX1U="))).set(2, 1000L, PendingIntent.getActivity(MyApplication.this.getApplicationContext(), 11111, intent, 1073741824));
                Process.killProcess(Process.myPid());
                System.exit(2);
                MyApplication.this.uncaughtExceptionHandler.uncaughtException(thread, th);
            }
        });
        super.onCreate();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public String getStackTrace(Throwable th) {
        StringWriter stringWriter = new StringWriter();
        PrintWriter printWriter = new PrintWriter(stringWriter);
        while (th != null) {
            th.printStackTrace(printWriter);
            th = th.getCause();
        }
        String obj = stringWriter.toString();
        printWriter.close();
        return obj;
    }
}
