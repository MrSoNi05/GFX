package com.bgm.gfx;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Point;
import com.github.megatronking.stringfog.xor.StringFogImpl;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Random;

/* loaded from: classes7.dex */
public class Figure {
    private static /* synthetic */ int[] $SWITCH_TABLE$com$bgm$gfx$Figure$FigureType = null;
    static final int BRICK_GAP_SIZE = 1;
    static final int BRICK_SIZE = 60;
    static final int FIGURE_MATRIX_SIZE = 12;
    private ArrayList<HashMap<String, Object>> list2 = new ArrayList<>();
    private String actcolor = "";
    Point pos = new Point();
    FigureType type = FigureType.randomFigure();
    private int rotation = 0;

    /* loaded from: classes7.dex */
    public enum FigureMotion {
        Left,
        Right,
        Down,
        Rotate;

        /* renamed from: values  reason: to resolve conflict with enum method */
        public static FigureMotion[] valuesCustom() {
            FigureMotion[] valuesCustom = values();
            int length = valuesCustom.length;
            FigureMotion[] figureMotionArr = new FigureMotion[length];
            System.arraycopy(valuesCustom, 0, figureMotionArr, 0, length);
            return figureMotionArr;
        }
    }

    static /* synthetic */ int[] $SWITCH_TABLE$com$bgm$gfx$Figure$FigureType() {
        int[] iArr = $SWITCH_TABLE$com$bgm$gfx$Figure$FigureType;
        if (iArr != null) {
            return iArr;
        }
        int[] iArr2 = new int[FigureType.valuesCustom().length];
        try {
            iArr2[FigureType.I.ordinal()] = 1;
        } catch (NoSuchFieldError unused) {
        }
        try {
            iArr2[FigureType.J.ordinal()] = 4;
        } catch (NoSuchFieldError unused2) {
        }
        try {
            iArr2[FigureType.L.ordinal()] = 3;
        } catch (NoSuchFieldError unused3) {
        }
        try {
            iArr2[FigureType.O.ordinal()] = 2;
        } catch (NoSuchFieldError unused4) {
        }
        try {
            iArr2[FigureType.S.ordinal()] = 5;
        } catch (NoSuchFieldError unused5) {
        }
        try {
            iArr2[FigureType.T.ordinal()] = 7;
        } catch (NoSuchFieldError unused6) {
        }
        try {
            iArr2[FigureType.Z.ordinal()] = 6;
        } catch (NoSuchFieldError unused7) {
        }
        $SWITCH_TABLE$com$bgm$gfx$Figure$FigureType = iArr2;
        return iArr2;
    }

    /* loaded from: classes7.dex */
    public enum FigureType {
        I,
        O,
        L,
        J,
        S,
        Z,
        T;
        
        private static final Random RANDOM;
        private static final int SIZE;
        private static final List<FigureType> VALUES;

        /* renamed from: values  reason: to resolve conflict with enum method */
        public static FigureType[] valuesCustom() {
            FigureType[] valuesCustom = values();
            int length = valuesCustom.length;
            FigureType[] figureTypeArr = new FigureType[length];
            System.arraycopy(valuesCustom, 0, figureTypeArr, 0, length);
            return figureTypeArr;
        }

        static {
            List<FigureType> unmodifiableList = Collections.unmodifiableList(Arrays.asList(valuesCustom()));
            VALUES = unmodifiableList;
            SIZE = unmodifiableList.size();
            RANDOM = new Random();
        }

        public static FigureType randomFigure() {
            return VALUES.get(RANDOM.nextInt(SIZE));
        }
    }

    public void refresh() {
        this.list2 = (ArrayList) new Gson().fromJson(StringFogImpl.decrypt("Di9kTlc5OzQPAnd3ABl8ZWcAD0V5L2ROVzk7NA8Cd3cEHglnZXEPRXkvZE5XOTs0DwJ3dwMbAGEVAw9FeS9kTlc5OzQPAnd3cmgMZmNwD0V5L2ROVzk7NA8Cd3dwaXxgEQIPRXkvZE5XOTs0DwJ3dwBuDmJicQ9FeS9kTlc5OzQPAnd3Bxh7Fmx0D0V5L2ROVzk7NA8Cd3dzHg5sY3APRXkvZE5XOTs0DwJ3dwQaAW1tdw9FeS9kTlc5OzQPAnd3AGt9ZWR2D0V5L2ROVzk7NA8Cd3cAa3liYXcPRXkvZE5XOTs0DwJ3d3MZC2YSAA9FeS9kTlc5OzQPAnd3dR4MEWF2D0V5L2ROVzk7NA8Cd3cAa31lZHYPRXkvZE5XOTs0DwJ3dwMZfWARcA9FeS9kTlc5OzQPAnd3cGt6ZBIFD0V5L2ROVzk7NA8Cd3cHbnoXY34PRXkvZE5XOTs0DwJ3d34bfhERfg9FeS9kTlc5OzQPAnd3cx4ObGNwD0V5L2ROVzk7NA8Cd3cAb3tiEHIPRXkvZE5XOTs0DwJ3d3EYCxRsfg9FeS9kTlc5OzQPAnd3ABR8YWZ1D0V5L2ROVzk7NA8Cd3cEa31sEgAPRXkvZE5XOTs0DwJ3dwVuChdhAw9FeS9kTlc5OzQPAnd3dh17YxIAD0V5L2ROVzk7NA8Cd3dxbwFnZAcPRXkvZE5XOTs0DwJ3d35ueWMQBA9FeS9kTlc5OzQPAnd3AGsBYWN0D0V5L2ROVzk7NA8Cd3d+aA1hEX8PRXkvZE5XOTs0DwJ3d3McDmZtcw9FCA=="), new TypeToken<ArrayList<HashMap<String, Object>>>() { // from class: com.bgm.gfx.Figure.1
        }.getType());
        this.actcolor = this.list2.get(SketchwareUtil.getRandom(0, 29)).get(StringFogImpl.decrypt("NjsqQko=")).toString();
        this.type = FigureType.randomFigure();
        this.rotation = 0;
    }

    private int getNextRotation() {
        int i = this.rotation;
        if (3 == i) {
            return 0;
        }
        return i + 1;
    }

    public void rotate() {
        this.rotation = getNextRotation();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean[][] getMatrix(boolean z) {
        return getMatrix(getNextRotation());
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public boolean[][] getMatrix() {
        return getMatrix(this.rotation);
    }

    private boolean[][] getMatrix(int i) {
        switch ($SWITCH_TABLE$com$bgm$gfx$Figure$FigureType()[this.type.ordinal()]) {
            case 1:
                if (i != 0) {
                    if (i != 1) {
                        if (i != 2) {
                            if (i != 3) {
                                return null;
                            }
                        }
                    }
                    return new boolean[][]{new boolean[]{true, true, true, true}};
                }
                return new boolean[][]{new boolean[]{true}, new boolean[]{true}, new boolean[]{true}, new boolean[]{true}};
            case 2:
                if (i == 0 || i == 1 || i == 2 || i == 3) {
                    return new boolean[][]{new boolean[]{true, true}, new boolean[]{true, true}};
                }
                return null;
            case 3:
                if (i != 0) {
                    if (i != 1) {
                        if (i != 2) {
                            if (i != 3) {
                                return null;
                            }
                            return new boolean[][]{new boolean[]{true, true, true}, new boolean[]{true}};
                        }
                        return new boolean[][]{new boolean[]{true, true}, new boolean[]{false, true}, new boolean[]{false, true}};
                    }
                    return new boolean[][]{new boolean[]{false, false, true}, new boolean[]{true, true, true}};
                }
                return new boolean[][]{new boolean[]{true}, new boolean[]{true}, new boolean[]{true, true}};
            case 4:
                if (i != 0) {
                    if (i != 1) {
                        if (i != 2) {
                            if (i != 3) {
                                return null;
                            }
                            return new boolean[][]{new boolean[]{true}, new boolean[]{true, true, true}};
                        }
                        return new boolean[][]{new boolean[]{true, true}, new boolean[]{true}, new boolean[]{true}};
                    }
                    return new boolean[][]{new boolean[]{true, true, true}, new boolean[]{false, false, true}};
                }
                return new boolean[][]{new boolean[]{false, true}, new boolean[]{false, true}, new boolean[]{true, true}};
            case 5:
                if (i != 0) {
                    if (i != 1) {
                        if (i != 2) {
                            if (i != 3) {
                                return null;
                            }
                        }
                    }
                    return new boolean[][]{new boolean[]{true}, new boolean[]{true, true}, new boolean[]{false, true}};
                }
                return new boolean[][]{new boolean[]{false, true, true}, new boolean[]{true, true}};
            case 6:
                if (i != 0) {
                    if (i != 1) {
                        if (i != 2) {
                            if (i != 3) {
                                return null;
                            }
                        }
                    }
                    return new boolean[][]{new boolean[]{false, true}, new boolean[]{true, true}, new boolean[]{true}};
                }
                return new boolean[][]{new boolean[]{true, true}, new boolean[]{false, true, true}};
            case 7:
                if (i != 0) {
                    if (i != 1) {
                        if (i != 2) {
                            if (i != 3) {
                                return null;
                            }
                            return new boolean[][]{new boolean[]{true}, new boolean[]{true, true}, new boolean[]{true}};
                        }
                        return new boolean[][]{new boolean[]{true, true, true}, new boolean[]{false, true}};
                    }
                    return new boolean[][]{new boolean[]{false, true}, new boolean[]{true, true}, new boolean[]{false, true}};
                }
                return new boolean[][]{new boolean[]{false, true}, new boolean[]{true, true, true}};
            default:
                throw new IllegalArgumentException(StringFogImpl.decrypt("ADouTFYxOCNJGBM9IVhMMAA/XV10"));
        }
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    public void DrawFigure(Canvas canvas) {
        DrawFigure(canvas, getMatrix(), false);
    }

    void DrawFigure(Canvas canvas, boolean[][] zArr) {
        DrawFigure(canvas, zArr, false);
    }

    void DrawFigure(Canvas canvas, boolean[][] zArr, boolean z) {
        Paint paint = new Paint();
        paint.setColor(Color.parseColor(this.actcolor));
        DrawFigure(canvas, zArr, paint);
    }

    void DrawFigure(Canvas canvas, boolean[][] zArr, Paint paint) {
        canvas.save();
        for (int i = 0; i < zArr.length; i++) {
            for (int i2 = 0; i2 < zArr[i].length; i2++) {
                if (zArr[i][i2]) {
                    canvas.drawRect(((this.pos.x + i2) - 1) * 61, ((this.pos.y + i) - 1) * 61, ((this.pos.x + i2) * 61) - 1, ((this.pos.y + i) * 61) - 1, paint);
                }
            }
        }
        canvas.restore();
    }
}
