package com.bgm.gfx;

import android.widget.ImageView;
import android.widget.RelativeLayout;

/* loaded from: classes7.dex */
public class Collision {
    public final boolean getCollision(ImageView imageView, ImageView imageView2, RelativeLayout relativeLayout) {
        return imageView2.getX() - ((float) (imageView.getWidth() / 2)) < imageView.getX() && imageView2.getX() + ((float) (imageView2.getWidth() / 2)) > imageView.getX() && imageView2.getY() - ((float) imageView.getHeight()) < imageView.getY() && imageView2.getY() + ((float) imageView2.getHeight()) > imageView.getY();
    }
}
