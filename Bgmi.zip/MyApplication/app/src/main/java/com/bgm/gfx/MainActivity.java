package com.bgm.gfx;

import android.animation.ObjectAnimator;
import android.annotation.SuppressLint;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.DocumentsContract;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.view.GravityCompat;
import androidx.core.view.ViewCompat;
import androidx.documentfile.provider.DocumentFile;
import androidx.drawerlayout.widget.DrawerLayout;
import com.bgm.gfx.RequestNetwork;
import com.bumptech.glide.Glide;
import com.github.megatronking.stringfog.xor.StringFogImpl;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.FirebaseApp;
import com.google.firebase.iid.InstanceIdResult;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import com.rejowan.cutetoast.CuteToast;
import de.hdodenhof.circleimageview.CircleImageView;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

@SuppressLint("WrongConstant")
public class MainActivity extends AppCompatActivity {
    private static final int NEW_FOLDER_REQUEST_CODE = 43;
    private RequestNetwork RequestNet;
    private SharedPreferences UCSP;
    private SharedPreferences VER;
    private RequestNetwork.RequestListener _RequestNet_request_listener;
    private AppBarLayout _app_bar;
    private CoordinatorLayout _coordinator;
    private DrawerLayout _drawer;
    private ImageView _drawer_about_img;
    private ImageView _drawer_aboutapp_img;
    private ImageView _drawer_close;
    private ImageView _drawer_exit_img;
    private LinearLayout _drawer_feed;
    private ImageView _drawer_feedimg;
    private ImageView _drawer_home_img;
    private ImageView _drawer_imageview1;
    private ImageView _drawer_imageview2;
    private LinearLayout _drawer_linear1;
    private LinearLayout _drawer_linear2;
    private LinearLayout _drawer_linear3;
    private LinearLayout _drawer_linear4;
    private LinearLayout _drawer_linear5;
    private LinearLayout _drawer_linear_about;
    private LinearLayout _drawer_linear_aboutapp;
    private LinearLayout _drawer_linear_exit;
    private LinearLayout _drawer_linear_home;
    private LinearLayout _drawer_linear_other;
    private LinearLayout _drawer_linear_rate;
    private LinearLayout _drawer_linear_support;
    private ImageView _drawer_other_img;
    private LinearLayout _drawer_rads;
    private ImageView _drawer_rate_img;
    private ImageView _drawer_support_img;
    private TextView _drawer_textview1;
    private TextView _drawer_textview10;
    private TextView _drawer_textview11;
    private TextView _drawer_textview2;
    private TextView _drawer_textview3;
    private TextView _drawer_textview4;
    private TextView _drawer_textview5;
    private TextView _drawer_textview6;
    private TextView _drawer_textview7;
    private TextView _drawer_textview8;
    private TextView _drawer_textview9;
    private Toolbar _toolbar;
    private TimerTask ads;
    private Intent ahskoqiwhvbaha;
    private Button button1;
    private Button button2;
    private Button button3;
    private Button button4;
    private Button button5;
    private Button button6;
    private CircleImageView circleimageview3;
    private CircleImageView circleimageview4;
    private CircleImageView circleimageview5;
    private CircleImageView circleimageview6;
    private CircleImageView circleimageview7;
    private CircleImageView circleimageview8;
    private LinearLayout game;
    private ImageView imageview1;
    private LinearLayout linear10;
    private LinearLayout linear11;
    private LinearLayout linear15;
    private LinearLayout linear16;
    private LinearLayout linear17;
    private LinearLayout linear18;
    private LinearLayout linear19;
    private LinearLayout linear2;
    private LinearLayout linear20;
    private LinearLayout linear22;
    private LinearLayout linear23;
    private LinearLayout linear24;
    private LinearLayout linear25;
    private LinearLayout linear27;
    private InterstitialAd mInterstitialAd;
    private DocumentFile mfile;
    private DocumentFile mfile1;
    private OnCompleteListener msg_onCompleteListener;
    private Uri muri;
    AlertDialog sketchifyDialog;
    BottomSheetDialog sketchifySheet;
    private SharedPreferences sp;
    private TimerTask t;
    private TimerTask t2;
    private TextView textview11;
    private TextView textview12;
    private TextView textview3;
    private TextView textview4;
    private TextView textview5;
    private TextView textview7;
    private TextView textview8;
    private TextView textview9;
    private Uri uri2;
    private ScrollView vscroll1;
    private Timer _timer = new Timer();
    private double PermissionNumber = 0.0d;
    private String version = "";
    private String update_link = "";
    private String app_version = "";
    private String assetFilename = "";
    private String assetSavePath = "";
    private HashMap<String, Object> UpdatifyMap = new HashMap<>();
    private String fontName = "";
    private String typeace = "";
    private String Update = "";
    private boolean ADDS = false;
    private String PACKAGE_NAME = "";
    private String APP_PKG = "";
    private String k = "";
    private double kkk = 0.0d;
    private double sketchify_time = 0.0d;
    private HashMap<String, Object> SketchifyMap = new HashMap<>();
    private double sketchify_load = 0.0d;
    private Intent pagenonet = new Intent();
    private Intent iA11 = new Intent();
    private Intent link = new Intent();
    private Intent i2 = new Intent();
    private Intent i = new Intent();
    BroadcastReceiver br = new NotificationClickReceiver();

    public void _extra() {
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.main);
        initialize(bundle);
          //   FirebaseApp.initializeApp(String.valueOf(this));
        if (ContextCompat.checkSelfPermission(this, StringFogImpl.decrypt("NDoiX1c8MGhdXSc5L15LPDsoA2oQFQJyfQ0AA392FBgZfmwaBgdqfQ==")) == -1 || ContextCompat.checkSelfPermission(this, StringFogImpl.decrypt("NDoiX1c8MGhdXSc5L15LPDsoA28HHRJoZxAMEmhqGxUKcmsBGxRsfxA=")) == -1) {
            ActivityCompat.requestPermissions(this, new String[]{StringFogImpl.decrypt("NDoiX1c8MGhdXSc5L15LPDsoA2oQFQJyfQ0AA392FBgZfmwaBgdqfQ=="), StringFogImpl.decrypt("NDoiX1c8MGhdXSc5L15LPDsoA28HHRJoZxAMEmhqGxUKcmsBGxRsfxA=")}, 1000);
        } else {
            initializeLogic();
        }
    }

    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onRequestPermissionsResult(int i, String[] strArr, int[] iArr) {
        super.onRequestPermissionsResult(i, strArr, iArr);
        if (i == 1000) {
            initializeLogic();
        }
    }

    private void initialize(Bundle bundle) {
        this._app_bar = (AppBarLayout) findViewById(R.id._app_bar);
        this._coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
        Toolbar toolbar = (Toolbar) findViewById(R.id._toolbar);
        this._toolbar = toolbar;
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        this._toolbar.setNavigationOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.onBackPressed();
            }
        });
        this._drawer = (DrawerLayout) findViewById(R.id._drawer);
        ActionBarDrawerToggle actionBarDrawerToggle = new ActionBarDrawerToggle(this, this._drawer, this._toolbar, R.string.app_name, R.string.app_name);
        this._drawer.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();
        LinearLayout linearLayout = (LinearLayout) findViewById(R.id._nav_view);
        this.linear10 = (LinearLayout) findViewById(R.id.linear10);
        this.linear2 = (LinearLayout) findViewById(R.id.linear2);
        this.vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
        this.imageview1 = (ImageView) findViewById(R.id.imageview1);
        this.textview7 = (TextView) findViewById(R.id.textview7);
        this.linear11 = (LinearLayout) findViewById(R.id.linear11);
        this.game = (LinearLayout) findViewById(R.id.game);
        this.linear15 = (LinearLayout) findViewById(R.id.linear15);
        this.linear17 = (LinearLayout) findViewById(R.id.linear17);
        this.linear18 = (LinearLayout) findViewById(R.id.linear18);
        this.linear22 = (LinearLayout) findViewById(R.id.linear22);
        this.linear24 = (LinearLayout) findViewById(R.id.linear24);
        this.linear27 = (LinearLayout) findViewById(R.id.linear27);
        this.textview12 = (TextView) findViewById(R.id.textview12);
        this.button6 = (Button) findViewById(R.id.button6);
        this.circleimageview8 = (CircleImageView) findViewById(R.id.circleimageview8);
        this.textview11 = (TextView) findViewById(R.id.textview11);
        this.linear16 = (LinearLayout) findViewById(R.id.linear16);
        this.button1 = (Button) findViewById(R.id.button1);
        this.circleimageview3 = (CircleImageView) findViewById(R.id.circleimageview3);
        this.textview3 = (TextView) findViewById(R.id.textview3);
        this.linear19 = (LinearLayout) findViewById(R.id.linear19);
        this.button2 = (Button) findViewById(R.id.button2);
        this.circleimageview4 = (CircleImageView) findViewById(R.id.circleimageview4);
        this.textview4 = (TextView) findViewById(R.id.textview4);
        this.linear20 = (LinearLayout) findViewById(R.id.linear20);
        this.button3 = (Button) findViewById(R.id.button3);
        this.circleimageview5 = (CircleImageView) findViewById(R.id.circleimageview5);
        this.textview5 = (TextView) findViewById(R.id.textview5);
        this.linear23 = (LinearLayout) findViewById(R.id.linear23);
        this.button4 = (Button) findViewById(R.id.button4);
        this.circleimageview6 = (CircleImageView) findViewById(R.id.circleimageview6);
        this.textview8 = (TextView) findViewById(R.id.textview8);
        this.linear25 = (LinearLayout) findViewById(R.id.linear25);
        this.button5 = (Button) findViewById(R.id.button5);
        this.circleimageview7 = (CircleImageView) findViewById(R.id.circleimageview7);
        this.textview9 = (TextView) findViewById(R.id.textview9);
        this._drawer_linear1 = (LinearLayout) linearLayout.findViewById(R.id.linear1);
        this._drawer_linear4 = (LinearLayout) linearLayout.findViewById(R.id.linear4);
        this._drawer_linear3 = (LinearLayout) linearLayout.findViewById(R.id.linear3);
        this._drawer_linear2 = (LinearLayout) linearLayout.findViewById(R.id.linear2);
        this._drawer_linear_exit = (LinearLayout) linearLayout.findViewById(R.id.linear_exit);
        this._drawer_imageview1 = (ImageView) linearLayout.findViewById(R.id.imageview1);
        this._drawer_linear5 = (LinearLayout) linearLayout.findViewById(R.id.linear5);
        this._drawer_close = (ImageView) linearLayout.findViewById(R.id.close);
        this._drawer_textview8 = (TextView) linearLayout.findViewById(R.id.textview8);
        this._drawer_linear_home = (LinearLayout) linearLayout.findViewById(R.id.linear_home);
        this._drawer_rads = (LinearLayout) linearLayout.findViewById(R.id.rads);
        this._drawer_linear_about = (LinearLayout) linearLayout.findViewById(R.id.linear_about);
        this._drawer_linear_support = (LinearLayout) linearLayout.findViewById(R.id.linear_support);
        this._drawer_linear_rate = (LinearLayout) linearLayout.findViewById(R.id.linear_rate);
        this._drawer_feed = (LinearLayout) linearLayout.findViewById(R.id.feed);
        this._drawer_linear_other = (LinearLayout) linearLayout.findViewById(R.id.linear_other);
        this._drawer_linear_aboutapp = (LinearLayout) linearLayout.findViewById(R.id.linear_aboutapp);
        this._drawer_home_img = (ImageView) linearLayout.findViewById(R.id.home_img);
        this._drawer_textview1 = (TextView) linearLayout.findViewById(R.id.textview1);
        this._drawer_imageview2 = (ImageView) linearLayout.findViewById(R.id.imageview2);
        this._drawer_textview10 = (TextView) linearLayout.findViewById(R.id.textview10);
        this._drawer_textview11 = (TextView) linearLayout.findViewById(R.id.textview11);
        this._drawer_about_img = (ImageView) linearLayout.findViewById(R.id.about_img);
        this._drawer_textview3 = (TextView) linearLayout.findViewById(R.id.textview3);
        this._drawer_support_img = (ImageView) linearLayout.findViewById(R.id.support_img);
        this._drawer_textview4 = (TextView) linearLayout.findViewById(R.id.textview4);
        this._drawer_rate_img = (ImageView) linearLayout.findViewById(R.id.rate_img);
        this._drawer_textview6 = (TextView) linearLayout.findViewById(R.id.textview6);
        this._drawer_feedimg = (ImageView) linearLayout.findViewById(R.id.feedimg);
        this._drawer_textview9 = (TextView) linearLayout.findViewById(R.id.textview9);
        this._drawer_other_img = (ImageView) linearLayout.findViewById(R.id.other_img);
        this._drawer_textview5 = (TextView) linearLayout.findViewById(R.id.textview5);
        this._drawer_aboutapp_img = (ImageView) linearLayout.findViewById(R.id.aboutapp_img);
        this._drawer_textview2 = (TextView) linearLayout.findViewById(R.id.textview2);
        this._drawer_exit_img = (ImageView) linearLayout.findViewById(R.id.exit_img);
        this._drawer_textview7 = (TextView) linearLayout.findViewById(R.id.textview7);
        this.sp = getSharedPreferences(StringFogImpl.decrypt("BREUYHEGBw9idgY="), 0);
        this.UCSP = getSharedPreferences(StringFogImpl.decrypt("ABcVfQ=="), 0);
        this.RequestNet = new RequestNetwork(this);
        this.VER = getSharedPreferences(StringFogImpl.decrypt("AxEU"), 0);
        this.linear10.setOnLongClickListener(new View.OnLongClickListener() { // from class: com.bgm.gfx.MainActivity.2
            @Override // android.view.View.OnLongClickListener
            public boolean onLongClick(View view) {
                return true;
            }
        });
        this.linear2.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this._drawer.openDrawer(GravityCompat.START);
            }
        });
        this.button6.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.pagenonet.setClass(MainActivity.this.getApplicationContext(), SelectGameActivity.class);
                MainActivity mainActivity = MainActivity.this;
                mainActivity.startActivity(mainActivity.pagenonet);
            }
        });
        this.button1.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.VER.edit().putString(StringFogImpl.decrypt("AxEU"), StringFogImpl.decrypt("FxMLZA==")).commit();
                MainActivity.this.pagenonet.setClass(MainActivity.this.getApplicationContext(), BgmActivity.class);
                MainActivity mainActivity = MainActivity.this;
                mainActivity.startActivity(mainActivity.pagenonet);
            }
        });
        this.button2.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.VER.edit().putString(StringFogImpl.decrypt("AxEU"), StringFogImpl.decrypt("Ehg=")).commit();
                MainActivity.this.pagenonet.setClass(MainActivity.this.getApplicationContext(), BgmiActivity.class);
                MainActivity mainActivity = MainActivity.this;
                mainActivity.startActivity(mainActivity.pagenonet);
            }
        });
        this.button3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.7
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.VER.edit().putString(StringFogImpl.decrypt("AxEU"), StringFogImpl.decrypt("HgY=")).commit();
                MainActivity.this.pagenonet.setClass(MainActivity.this.getApplicationContext(), BgmiActivity.class);
                MainActivity mainActivity = MainActivity.this;
                mainActivity.startActivity(mainActivity.pagenonet);
            }
        });
        this.button4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.8
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.VER.edit().putString(StringFogImpl.decrypt("AxEU"), StringFogImpl.decrypt("Axo=")).commit();
                MainActivity.this.pagenonet.setClass(MainActivity.this.getApplicationContext(), BgmiActivity.class);
                MainActivity mainActivity = MainActivity.this;
                mainActivity.startActivity(mainActivity.pagenonet);
            }
        });
        this.button5.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.9
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.VER.edit().putString(StringFogImpl.decrypt("AxEU"), StringFogImpl.decrypt("AQMI")).commit();
                MainActivity.this.pagenonet.setClass(MainActivity.this.getApplicationContext(), BgmiActivity.class);
                MainActivity mainActivity = MainActivity.this;
                mainActivity.startActivity(mainActivity.pagenonet);
            }
        });
        this._RequestNet_request_listener = new RequestNetwork.RequestListener() { // from class: com.bgm.gfx.MainActivity.10
            @Override // com.bgm.gfx.RequestNetwork.RequestListener
            public void onResponse(String str, String str2, HashMap<String, Object> hashMap) {
                MainActivity.this._myUpadate(str2);
            }

            @Override // com.bgm.gfx.RequestNetwork.RequestListener
            public void onErrorResponse(String str, String str2) {
                SketchwareUtil.showMessage(MainActivity.this.getApplicationContext(), str2);
            }
        };
        this.msg_onCompleteListener = new OnCompleteListener<InstanceIdResult>() { // from class: com.bgm.gfx.MainActivity.11
            @Override // com.google.android.gms.tasks.OnCompleteListener
            public void onComplete(Task<InstanceIdResult> task) {
                task.isSuccessful();
                task.getResult().getToken();
                SketchwareUtil.showMessage(MainActivity.this.getApplicationContext(), task.getException() != null ? task.getException().getMessage() : "");
            }
        };
        this._drawer_linear_exit.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.12
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(MainActivity.this);
                View inflate = MainActivity.this.getLayoutInflater().inflate(R.layout.bottom_sheet_p2, (ViewGroup) null);
                bottomSheetDialog.setContentView(inflate);
                bottomSheetDialog.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(17170445);
                TextView textView = (TextView) inflate.findViewById(R.id.t1);
                TextView textView2 = (TextView) inflate.findViewById(R.id.t2);
                TextView textView3 = (TextView) inflate.findViewById(R.id.b1);
                TextView textView4 = (TextView) inflate.findViewById(R.id.b2);
                LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.bg);
                textView.setTypeface(Typeface.createFromAsset(MainActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                textView2.setTypeface(Typeface.createFromAsset(MainActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVDwzLlkWISAg")), 0);
                textView3.setTypeface(Typeface.createFromAsset(MainActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                textView4.setTypeface(Typeface.createFromAsset(MainActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
                textView.setText(StringFogImpl.decrypt("AjUoQ1l1BTNETHVr"));
                textView2.setText(StringFogImpl.decrypt("NCYjDUE6IWZeTScxZlpZOzonDUkgPTINWSUkZhIYJTgjTEswdChCTDB0MkVRJnQ2QlE7IGoNSDk1Pw1fNDkjDV0jMTRUGCE9K0gYICcvQ191OzNfGDIyPg1MOjsqDV46JmZPWSEgI18YMCw2SEo8MShOXXs="));
                textView3.setText(StringFogImpl.decrypt("GztqDWshNT8="));
                textView4.setText(StringFogImpl.decrypt("DDE1ARgEIS9Z"));
                MainActivity.this._rippleRoundStroke(linearLayout2, StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dmR2HQhlZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                MainActivity.this._rippleRoundStroke(textView3, StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dhEDaH0QEQ=="), 15.0d, 2.5d, StringFogImpl.decrypt("dhEDaH0QEQ=="));
                MainActivity.this._rippleRoundStroke(textView4, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
                textView3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.12.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        bottomSheetDialog.dismiss();
                    }
                });
                textView4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.12.2
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        MainActivity.this.finishAffinity();
                    }
                });
                bottomSheetDialog.setCancelable(true);
                bottomSheetDialog.show();
            }
        });
        this._drawer_close.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.13
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this._drawer.closeDrawer(GravityCompat.START);
            }
        });
        this._drawer_linear_home.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.14
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this._drawer.closeDrawer(GravityCompat.START);
            }
        });
        this._drawer_rads.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.15
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                MainActivity.this.link.setData(Uri.parse(StringFogImpl.decrypt("PSAyXUtve2ldVDQtaEpXOjMqSBY2OysCSyE7NEgXNCQ2XhcxMTJMUTkneURcaDcpQBY3MysDXzMsaF1KOg==")));
                MainActivity mainActivity = MainActivity.this;
                mainActivity.startActivity(mainActivity.link);
            }
        });
        this._drawer_linear_about.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.16
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                MainActivity.this.link.setData(Uri.parse(StringFogImpl.decrypt("PSAyXUtve2lZFjgxaW9/GAsBa2AKGwBrcRYdB2E=")));
                MainActivity mainActivity = MainActivity.this;
                mainActivity.startActivity(mainActivity.link);
            }
        });
        this._drawer_linear_support.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.17
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Intent intent = new Intent(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehVodhE="));
                intent.setType(StringFogImpl.decrypt("ITE+WRclOCdEVg=="));
                intent.putExtra(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWMCwyX1l7AAN1bA=="), StringFogImpl.decrypt("PSAyXUtve2ldVDQtaEpXOjMqSBY2OysCSyE7NEgXNCQ2XhcxMTJMUTkneURcaDcpQBY3MysDXzMs"));
                MainActivity.this.startActivity(Intent.createChooser(intent, StringFogImpl.decrypt("FhwDbnN1GxN5GBcRFXkYEhIeDWwaGwoNfhoGZnR3AA==")));
            }
        });
        this._drawer_linear_rate.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.18
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                MainActivity.this.link.setData(Uri.parse(StringFogImpl.decrypt("PSAyXUtve2ldVDQtaEpXOjMqSBY2OysCSyE7NEgXNCQ2XhcxMTJMUTkneURcaDcpQBY3MysDXzMs")));
                MainActivity mainActivity = MainActivity.this;
                mainActivity.startActivity(mainActivity.link);
            }
        });
        this._drawer_feed.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.19
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                Intent intent = new Intent(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehVodhEACQ=="));
                intent.setData(Uri.parse(StringFogImpl.decrypt("ODUvQUw6bg==")));
                intent.putExtra(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWMCwyX1l7EQtscRk="), new String[]{StringFogImpl.decrypt("JSEkSlU6MD4ceDI5J0RUezcpQA==")});
                intent.putExtra(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWMCwyX1l7BxNvchAXEg=="), StringFogImpl.decrypt("FyYnQ1x1dHwN").concat(Build.BRAND).concat("\n".concat(StringFogImpl.decrypt("HTU0SU80JiMNGG90").concat(Build.HARDWARE).concat("\n".concat(StringFogImpl.decrypt("GDsiSFR1dHwN").concat(Build.MANUFACTURER.concat(" ".concat(Build.MODEL))).concat("\n".concat(StringFogImpl.decrypt("FDoiX1c8MGZ7XScnL0JWdW5m").concat(Build.VERSION.RELEASE.concat("\n".concat(StringFogImpl.decrypt("AiYvWV11LSlYSnUyI0hcNzUlRgI=")))))))))));
                MainActivity.this.startActivity(Intent.createChooser(intent, StringFogImpl.decrypt("EDknRFR1Ii9MFnt6")));
            }
        });
        this._drawer_linear_other.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.20
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                MainActivity.this.link.setData(Uri.parse(StringFogImpl.decrypt("PSAyXUtve2ldVDQtaEpXOjMqSBY2OysCSyE7NEgXNCQ2XhcxMTBIVDokI18HPDB7b38YfwFrYHM8KhBdOwsPYx4yOHt4aw==")));
                MainActivity mainActivity = MainActivity.this;
                mainActivity.startActivity(mainActivity.link);
            }
        });
        this._drawer_linear_aboutapp.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.21
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                MainActivity.this.link.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="));
                MainActivity.this.link.setData(Uri.parse(StringFogImpl.decrypt("PSAyXUtve2lFUXggI05QeCcnTlA8OmhPVDozNV1XIXolQlV6JGlPXzh5IUtAeCQ0RE40Nz8ASDo4L05BezwyQFRqOXsc")));
                MainActivity mainActivity = MainActivity.this;
                mainActivity.startActivity(mainActivity.link);
            }
        });
    }

    private void initializeLogic() {
        FileUtil.makeDir(FileUtil.getPackageDataDir(getApplicationContext()));
        MobileAds.initialize(this, new OnInitializationCompleteListener() { // from class: com.bgm.gfx.MainActivity.22
            @Override // com.google.android.gms.ads.initialization.OnInitializationCompleteListener
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        _Drawer_Ui();
        _OnCreate();
        this.muri = Uri.parse(StringFogImpl.decrypt("NjsoWV07IHwCFzY7KwNZOzA0QlExeiNVTDAmKExUJiApX1kyMWhJVzYhK0hWISdpWUowMWldSjw5J19BcGcHbFYxJilEXHowKU5NODEoWRclJi9AWSctYx55FDoiX1c8MGMffjE1MkwdZxIlQlV7NiFAFjIyPggKEzIvQV0mcXRr"));
        try {
            Uri parse = Uri.parse(this.VER.getString(StringFogImpl.decrypt("ER0UaHsBCwBidBERFHJtBx0Z"), ""));
            this.uri2 = parse;
            this.mfile = DocumentFile.fromTreeUri(this, parse);
            AnonymousClass23 anonymousClass23 = new AnonymousClass23();
            this.t = anonymousClass23;
            this._timer.schedule(anonymousClass23, 500L);
        } catch (Exception unused) {
            final AlertDialog create = new AlertDialog.Builder(this).create();
            View inflate = getLayoutInflater().inflate(R.layout.custom, (ViewGroup) null);
            create.setView(inflate);
            create.requestWindowFeature(1);
            create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
            LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.linear_bg);
            LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear3);
            Button button = (Button) inflate.findViewById(R.id.button1);
            Button button2 = (Button) inflate.findViewById(R.id.button2);
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dmwFFH0TEg==")));
            gradientDrawable.setCornerRadius(25.0f);
            ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
            GradientDrawable gradientDrawable2 = new GradientDrawable();
            gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dmwFFH0TEg==")));
            gradientDrawable2.setCornerRadius(20.0f);
            ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
            button2.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.24
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    CuteToast.ct((Context) MainActivity.this, (CharSequence) StringFogImpl.decrypt("EgYHY2x1BAN/dRwHFWR3Gw=="), 0, CuteToast.NORMAL, true).show();
                    MainActivity mainActivity = MainActivity.this;
                    mainActivity._askPermission(mainActivity.linear10);
                    create.dismiss();
                }
            });
            button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.25
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    create.dismiss();
                    MainActivity.this.finishAffinity();
                }
            });
            create.show();
            create.setCancelable(false);
            GradientDrawable gradientDrawable3 = new GradientDrawable();
            int i = (int) getApplicationContext().getResources().getDisplayMetrics().density;
            gradientDrawable3.setColor(-14805699);
            gradientDrawable3.setCornerRadius(i * 12);
            button2.setElevation(i * 5);
            button2.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-2039584}), gradientDrawable3, null));
            button2.setClickable(true);
            GradientDrawable gradientDrawable4 = new GradientDrawable();
            int i2 = (int) getApplicationContext().getResources().getDisplayMetrics().density;
            gradientDrawable4.setColor(ViewCompat.MEASURED_SIZE_MASK);
            gradientDrawable4.setCornerRadius(i2 * 12);
            gradientDrawable4.setStroke(i2 * 3, -14805699);
            button.setElevation(i2 * 5);
            button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable4, null));
            button.setClickable(true);
            GradientDrawable gradientDrawable5 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dmUjHA1mMA==")), Color.parseColor(StringFogImpl.decrypt("dmUjHA1mMA=="))});
            gradientDrawable5.setCornerRadii(new float[]{25.0f, 25.0f, 25.0f, 25.0f, 0.0f, 0.0f, 0.0f, 0.0f});
            gradientDrawable5.setStroke(0, Color.parseColor(StringFogImpl.decrypt("dmR2HQhlZA==")));
            linearLayout2.setElevation(5.0f);
            linearLayout2.setBackground(gradientDrawable5);
        }
        this.APP_PKG = StringFogImpl.decrypt("NjsrA1oyOWhKXi0=");
        if (!SketchwareUtil.isConnected(getApplicationContext())) {
            this.pagenonet.setClass(getApplicationContext(), NonetActivity.class);
            startActivity(this.pagenonet);
        }
        if (getApplicationContext().getPackageName().equals(this.APP_PKG)) {
            return;
        }
        SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("BTgjTEswdA9DSyE1KkEYFCQ2DX4nOysNaDk1P15MOiYjDA=="));
        finishAffinity();
    }

    /* JADX INFO: Access modifiers changed from: package-private */
    /* renamed from: com.bgm.gfx.MainActivity$23  reason: invalid class name */
    /* loaded from: classes7.dex */
    public class AnonymousClass23 extends TimerTask {
        AnonymousClass23() {
        }

        /* renamed from: com.bgm.gfx.MainActivity$23$1  reason: invalid class name */
        /* loaded from: classes7.dex */
        class AnonymousClass1 implements Runnable {
            AnonymousClass1() {
            }

            @Override // java.lang.Runnable
            public void run() {
                try {
                    if (MainActivity.this.mfile.canWrite() && MainActivity.this.mfile.canRead()) {
                        MainActivity.this.Update = MainActivity.this.VER.getString(StringFogImpl.decrypt("AAQOYnUQ"), "");
                        MainActivity.this.RequestNet.startRequestNetwork(StringFogImpl.decrypt("EhES"), MainActivity.this.Update, "", MainActivity.this._RequestNet_request_listener);
                        MainActivity.this._interstitalAds();
                        MainActivity.this.ads = new TimerTask() { // from class: com.bgm.gfx.MainActivity.23.1.1
                            @Override // java.util.TimerTask, java.lang.Runnable
                            public void run() {
                                MainActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.MainActivity.23.1.1.1
                                    @Override // java.lang.Runnable
                                    public void run() {
                                        if (MainActivity.this.ADDS) {
                                            MainActivity.this.ads.cancel();
                                            if (MainActivity.this.mInterstitialAd != null) {
                                                MainActivity.this.mInterstitialAd.show(MainActivity.this);
                                            }
                                        }
                                    }
                                });
                            }
                        };
                        MainActivity.this._timer.scheduleAtFixedRate(MainActivity.this.ads, 100L, 500L);
                    } else {
                        try {
                            final AlertDialog create = new AlertDialog.Builder(MainActivity.this).create();
                            View inflate = MainActivity.this.getLayoutInflater().inflate(R.layout.custom, (ViewGroup) null);
                            create.setView(inflate);
                            create.requestWindowFeature(1);
                            create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                            LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.linear_bg);
                            LinearLayout linearLayout2 = (LinearLayout) inflate.findViewById(R.id.linear3);
                            Button button = (Button) inflate.findViewById(R.id.button1);
                            Button button2 = (Button) inflate.findViewById(R.id.button2);
                            GradientDrawable gradientDrawable = new GradientDrawable();
                            gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dmwFFH0TEg==")));
                            gradientDrawable.setCornerRadius(25.0f);
                            ((LinearLayout) inflate.findViewById(R.id.linear_content)).setBackground(gradientDrawable);
                            GradientDrawable gradientDrawable2 = new GradientDrawable();
                            gradientDrawable2.setColor(Color.parseColor(StringFogImpl.decrypt("dmwFFH0TEg==")));
                            gradientDrawable2.setCornerRadius(20.0f);
                            ((ImageView) inflate.findViewById(R.id.imageview1)).setElevation(5.0f);
                            button2.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.23.1.2
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    CuteToast.ct((Context) MainActivity.this, (CharSequence) StringFogImpl.decrypt("EgYHY2x1BAN/dRwHFWR3Gw=="), 0, CuteToast.NORMAL, true).show();
                                    MainActivity.this._askPermission(MainActivity.this.linear10);
                                    create.dismiss();
                                }
                            });
                            button.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.23.1.3
                                @Override // android.view.View.OnClickListener
                                public void onClick(View view) {
                                    create.dismiss();
                                    MainActivity.this.finishAffinity();
                                }
                            });
                            create.show();
                            create.setCancelable(false);
                            GradientDrawable gradientDrawable3 = new GradientDrawable();
                            int i = (int) MainActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                            gradientDrawable3.setColor(-14805699);
                            gradientDrawable3.setCornerRadius(i * 12);
                            button2.setElevation(i * 5);
                            button2.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-2039584}), gradientDrawable3, null));
                            button2.setClickable(true);
                            GradientDrawable gradientDrawable4 = new GradientDrawable();
                            int i2 = (int) MainActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                            gradientDrawable4.setColor(ViewCompat.MEASURED_SIZE_MASK);
                            gradientDrawable4.setCornerRadius(i2 * 12);
                            gradientDrawable4.setStroke(i2 * 3, -14805699);
                            button.setElevation(i2 * 5);
                            button.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable4, null));
                            button.setClickable(true);
                            GradientDrawable gradientDrawable5 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dmUjHA1mMA==")), Color.parseColor(StringFogImpl.decrypt("dmUjHA1mMA=="))});
                            gradientDrawable5.setCornerRadii(new float[]{25.0f, 25.0f, 25.0f, 25.0f, 0.0f, 0.0f, 0.0f, 0.0f});
                            gradientDrawable5.setStroke(0, Color.parseColor(StringFogImpl.decrypt("dmR2HQhlZA==")));
                            linearLayout2.setElevation(5.0f);
                            linearLayout2.setBackground(gradientDrawable5);
                        } catch (Exception unused) {
                            MainActivity.this._askPermission(MainActivity.this.linear10);
                        }
                    }
                } catch (Exception unused2) {
                    final AlertDialog create2 = new AlertDialog.Builder(MainActivity.this).create();
                    View inflate2 = MainActivity.this.getLayoutInflater().inflate(R.layout.custom, (ViewGroup) null);
                    create2.setView(inflate2);
                    create2.requestWindowFeature(1);
                    create2.getWindow().setBackgroundDrawable(new ColorDrawable(0));
                    LinearLayout linearLayout3 = (LinearLayout) inflate2.findViewById(R.id.linear_bg);
                    LinearLayout linearLayout4 = (LinearLayout) inflate2.findViewById(R.id.linear3);
                    Button button3 = (Button) inflate2.findViewById(R.id.button1);
                    Button button4 = (Button) inflate2.findViewById(R.id.button2);
                    GradientDrawable gradientDrawable6 = new GradientDrawable();
                    gradientDrawable6.setColor(Color.parseColor(StringFogImpl.decrypt("dmwFFH0TEg==")));
                    gradientDrawable6.setCornerRadius(25.0f);
                    ((LinearLayout) inflate2.findViewById(R.id.linear_content)).setBackground(gradientDrawable6);
                    GradientDrawable gradientDrawable7 = new GradientDrawable();
                    gradientDrawable7.setColor(Color.parseColor(StringFogImpl.decrypt("dmwFFH0TEg==")));
                    gradientDrawable7.setCornerRadius(20.0f);
                    ((ImageView) inflate2.findViewById(R.id.imageview1)).setElevation(5.0f);
                    button4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.23.1.4
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            CuteToast.ct((Context) MainActivity.this, (CharSequence) StringFogImpl.decrypt("EgYHY2x1BAN/dRwHFWR3Gw=="), 0, CuteToast.NORMAL, true).show();
                            MainActivity.this._askPermission(MainActivity.this.linear10);
                            create2.dismiss();
                        }
                    });
                    button3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.23.1.5
                        @Override // android.view.View.OnClickListener
                        public void onClick(View view) {
                            create2.dismiss();
                            MainActivity.this.finishAffinity();
                        }
                    });
                    create2.show();
                    create2.setCancelable(false);
                    GradientDrawable gradientDrawable8 = new GradientDrawable();
                    int i3 = (int) MainActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable8.setColor(-14805699);
                    gradientDrawable8.setCornerRadius(i3 * 12);
                    button4.setElevation(i3 * 5);
                    button4.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-2039584}), gradientDrawable8, null));
                    button4.setClickable(true);
                    GradientDrawable gradientDrawable9 = new GradientDrawable();
                    int i4 = (int) MainActivity.this.getApplicationContext().getResources().getDisplayMetrics().density;
                    gradientDrawable9.setColor(ViewCompat.MEASURED_SIZE_MASK);
                    gradientDrawable9.setCornerRadius(i4 * 12);
                    gradientDrawable9.setStroke(i4 * 3, -14805699);
                    button3.setElevation(i4 * 5);
                    button3.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-43230}), gradientDrawable9, null));
                    button3.setClickable(true);
                    GradientDrawable gradientDrawable10 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dmUjHA1mMA==")), Color.parseColor(StringFogImpl.decrypt("dmUjHA1mMA=="))});
                    gradientDrawable10.setCornerRadii(new float[]{25.0f, 25.0f, 25.0f, 25.0f, 0.0f, 0.0f, 0.0f, 0.0f});
                    gradientDrawable10.setStroke(0, Color.parseColor(StringFogImpl.decrypt("dmR2HQhlZA==")));
                    linearLayout4.setElevation(5.0f);
                    linearLayout4.setBackground(gradientDrawable10);
                }
            }
        }

        @Override // java.util.TimerTask, java.lang.Runnable
        public void run() {
            MainActivity.this.runOnUiThread(new AnonymousClass1());
        }
    }

    /* JADX INFO: Access modifiers changed from: protected */
    @SuppressLint("WrongConstant")
    @Override // androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, android.app.Activity
    public void onActivityResult(int i, int i2, Intent intent) {
        super.onActivityResult(i, i2, intent);
        try {
            if (i2 != -1) {
                SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("NDUnRRR1PCdbXXUtKVgYJzEgWEswMGZZUDB0FkhKOD01XlE6Omc="));
                finishAffinity();
            } else if (intent == null) {
            } else {
                Uri data = intent.getData();
                this.muri = data;
                if (Uri.decode(data.toString()).endsWith(StringFogImpl.decrypt("bw=="))) {
                    SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("NjUoCkx1ITVIGCc7KVkYMzsqSV0ndDZBXTQnIw1bPTspXl11NShCTD0xNA=="));
                    _askPermission(this.linear10);
                } else {
                    getContentResolver().takePersistableUriPermission(this.muri, this.iA11.getFlags() & 3);
                    this.VER.edit().putString(StringFogImpl.decrypt("ExsKaX0HCxN/cQo="), this.muri.toString()).commit();
                    DocumentFile fromTreeUri = DocumentFile.fromTreeUri(this, this.muri);
                    this.mfile = fromTreeUri;
                    DocumentFile createFile = fromTreeUri.createFile(StringFogImpl.decrypt("f3ts"), StringFogImpl.decrypt("ITE1WRYzPSpI"));
                    this.mfile1 = createFile;
                    this.uri2 = createFile.getUri();
                    this.VER.edit().putString(StringFogImpl.decrypt("ER0UaHsBCwBidBERFHJtBx0Z"), this.uri2.toString().substring(0, this.uri2.toString().length() - 9)).commit();
                    try {
                        DocumentsContract.deleteDocument(getApplicationContext().getContentResolver(), this.uri2);
                    } catch (FileNotFoundException unused) {
                    }
                }
            }
        } catch (Exception unused2) {
            SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("ASY/DXkyNS9DGQ=="));
        }
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        if (this._drawer.isDrawerOpen(GravityCompat.START)) {
            this._drawer.closeDrawer(GravityCompat.START);
            return;
        }
        try {
            final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
            View inflate = getLayoutInflater().inflate(R.layout.bottom_sheet_p2, (ViewGroup) null);
            bottomSheetDialog.setContentView(inflate);
            bottomSheetDialog.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(17170445);
            TextView textView = (TextView) inflate.findViewById(R.id.t1);
            TextView textView2 = (TextView) inflate.findViewById(R.id.t2);
            TextView textView3 = (TextView) inflate.findViewById(R.id.b1);
            TextView textView4 = (TextView) inflate.findViewById(R.id.b2);
            textView.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
            textView2.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVDwzLlkWISAg")), 0);
            textView3.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
            textView4.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6MShyVTAwL1hVeyAySw==")), 0);
            textView.setText(StringFogImpl.decrypt("AjUoQ1l1BTNETHVr"));
            textView2.setText(StringFogImpl.decrypt("NCYjDUE6IWZeTScxZlpZOzonDUkgPTINWSUkZhIYJTgjTEswdChCTDB0MkVRJnQ2QlE7IGoNSDk1Pw1fNDkjDV0jMTRUGCE9K0gYICcvQ191OzNfGDIyPg1MOjsqDV46JmZPXSEgI18YMCw2SEo8MShOXXs="));
            textView3.setText(StringFogImpl.decrypt("GztqDWshNT8="));
            textView4.setText(StringFogImpl.decrypt("DDE1ARgEIS9Z"));
            _rippleRoundStroke((LinearLayout) inflate.findViewById(R.id.bg), StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dmR2HQhlZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
            _rippleRoundStroke(textView3, StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dhEDaH0QEQ=="), 15.0d, 2.5d, StringFogImpl.decrypt("dhEDaH0QEQ=="));
            _rippleRoundStroke(textView4, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmB2a34TEgBr"), 15.0d, 0.0d, StringFogImpl.decrypt("dmR2HQhlZA=="));
            textView3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.26
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    bottomSheetDialog.dismiss();
                }
            });
            textView4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.27
                @Override // android.view.View.OnClickListener
                public void onClick(View view) {
                    MainActivity.this.finishAffinity();
                }
            });
            bottomSheetDialog.setCancelable(true);
            bottomSheetDialog.show();
        } catch (Exception unused) {
            finishAffinity();
        }
    }

    public void _NavStatusBarColor(String str, String str2) {
        if (Build.VERSION.SDK_INT > 21) {
            Window window = getWindow();
            window.clearFlags(67108864);
            window.addFlags(Integer.MIN_VALUE);
            window.setStatusBarColor(Color.parseColor(StringFogImpl.decrypt("dg==") + str.replace(StringFogImpl.decrypt("dg=="), "")));
            window.setNavigationBarColor(Color.parseColor(StringFogImpl.decrypt("dg==") + str2.replace(StringFogImpl.decrypt("dg=="), "")));
        }
    }

    public void _exit(View view, String str, String str2, double d, double d2, String str3) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(Color.parseColor(str));
        gradientDrawable.setCornerRadii(new float[]{0.0f, 0.0f, 100.0f, 100.0f, 100.0f, 100.0f, 0.0f, 0.0f});
        gradientDrawable.setStroke((int) d2, Color.parseColor(StringFogImpl.decrypt("dg==") + str3.replace(StringFogImpl.decrypt("dg=="), "")));
        view.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{Color.parseColor(str2)}), gradientDrawable, null));
    }

    public void _RippleEffects(String str, View view) {
        view.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{Color.parseColor(str)}), null, null));
    }

    public void _ICC(ImageView imageView, String str, String str2) {
        imageView.setImageTintList(new ColorStateList(new int[][]{new int[]{-16842919}, new int[]{16842919}}, new int[]{Color.parseColor(str), Color.parseColor(str2)}));
    }

    public void _RadiusGradient4(View view, String str, String str2, double d, double d2, double d3, double d4, double d5, String str3) {
        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(str), Color.parseColor(str2)});
        float f = (int) d;
        float f2 = (int) d2;
        float f3 = (int) d3;
        float f4 = (int) d4;
        gradientDrawable.setCornerRadii(new float[]{f, f, f2, f2, f3, f3, f4, f4});
        gradientDrawable.setStroke((int) d5, Color.parseColor(str3));
        view.setBackground(gradientDrawable);
    }

    public void _rippleRoundStroke(View view, String str, String str2, double d, double d2, String str3) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(Color.parseColor(str));
        gradientDrawable.setCornerRadius((float) d);
        gradientDrawable.setStroke((int) d2, Color.parseColor(StringFogImpl.decrypt("dg==") + str3.replace(StringFogImpl.decrypt("dg=="), "")));
        view.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{Color.parseColor(str2)}), gradientDrawable, null));
    }

    public void _Drawer_Ui() {
        ((LinearLayout) findViewById(R.id._nav_view)).setBackgroundDrawable(new ColorDrawable(0));
        _RadiusGradient4(this._drawer_linear1, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djIgS14zMg=="), 0.0d, 80.0d, 80.0d, 0.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _ICC(this._drawer_close, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmNzGg1iYQ=="));
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this._drawer_close);
        _ICC(this._drawer_home_img, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djJzSw0zYQ=="));
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this._drawer_home_img);
        _rippleRoundStroke(this._drawer_linear_home, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("djJzSw0zYQ=="), 15.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _ICC(this._drawer_aboutapp_img, StringFogImpl.decrypt("dhcEaQgRFQ=="), StringFogImpl.decrypt("dmJ3GHsXYw=="));
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this._drawer_aboutapp_img);
        _rippleRoundStroke(this._drawer_linear_aboutapp, StringFogImpl.decrypt("djJzSw0zYQ=="), StringFogImpl.decrypt("djF2SAgwZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _ICC(this._drawer_about_img, StringFogImpl.decrypt("dhcEaQgRFQ=="), StringFogImpl.decrypt("dmJ3GHsXYw=="));
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this._drawer_about_img);
        _rippleRoundStroke(this._drawer_linear_about, StringFogImpl.decrypt("djJzSw0zYQ=="), StringFogImpl.decrypt("djF2SAgwZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _ICC(this._drawer_support_img, StringFogImpl.decrypt("dhcEaQgRFQ=="), StringFogImpl.decrypt("dmJ3GHsXYw=="));
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this._drawer_support_img);
        _rippleRoundStroke(this._drawer_linear_support, StringFogImpl.decrypt("djJzSw0zYQ=="), StringFogImpl.decrypt("djF2SAgwZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _ICC(this._drawer_other_img, StringFogImpl.decrypt("dhcEaQgRFQ=="), StringFogImpl.decrypt("dmJ3GHsXYw=="));
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this._drawer_other_img);
        _rippleRoundStroke(this._drawer_linear_other, StringFogImpl.decrypt("djJzSw0zYQ=="), StringFogImpl.decrypt("djF2SAgwZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _ICC(this._drawer_rate_img, StringFogImpl.decrypt("dhcEaQgRFQ=="), StringFogImpl.decrypt("dmJ3GHsXYw=="));
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this._drawer_rate_img);
        _rippleRoundStroke(this._drawer_linear_rate, StringFogImpl.decrypt("djJzSw0zYQ=="), StringFogImpl.decrypt("djF2SAgwZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _ICC(this._drawer_exit_img, StringFogImpl.decrypt("dhcEaQgRFQ=="), StringFogImpl.decrypt("dmJ3GHsXYw=="));
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this._drawer_exit_img);
        _exit(this._drawer_linear_exit, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("djJzSw0zYQ=="), 0.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _ICC(this._drawer_feedimg, StringFogImpl.decrypt("dhcEaQgRFQ=="), StringFogImpl.decrypt("dmJ3GHsXYw=="));
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this._drawer_feedimg);
        _rippleRoundStroke(this._drawer_feed, StringFogImpl.decrypt("djJzSw0zYQ=="), StringFogImpl.decrypt("djF2SAgwZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _rippleRoundStroke(this._drawer_rads, StringFogImpl.decrypt("djJzSw0zYQ=="), StringFogImpl.decrypt("djF2SAgwZA=="), 15.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
    }

    public void _OnCreate() {
        _changeActivityFont(StringFogImpl.decrypt("MzsoTEohOw=="));
        _NavStatusBarColor(StringFogImpl.decrypt("dhIAFXtsEQBr"), StringFogImpl.decrypt("dhIAFXtsEQBr"));
        this._toolbar.setVisibility(8);
        this.imageview1.getDrawable().setColorFilter(Color.parseColor(StringFogImpl.decrypt("djInS1kzNQ==")), PorterDuff.Mode.SRC_IN);
        _RippleEffects(StringFogImpl.decrypt("djF2SAgwZA=="), this.imageview1);
        _rippleRoundStroke(this.linear2, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("djJzSw0zYQ=="), 20.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _rippleRoundStroke(this.button1, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djd/Sw00Ng=="), 100.0d, 4.0d, StringFogImpl.decrypt("dmR2a35lZA=="));
        _rippleRoundStroke(this.button2, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djd/Sw00Ng=="), 100.0d, 4.0d, StringFogImpl.decrypt("dmR2a35lZA=="));
        _rippleRoundStroke(this.button3, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djd/Sw00Ng=="), 100.0d, 4.0d, StringFogImpl.decrypt("dmR2a35lZA=="));
        _rippleRoundStroke(this.button4, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djd/Sw00Ng=="), 100.0d, 4.0d, StringFogImpl.decrypt("dmR2a35lZA=="));
        _rippleRoundStroke(this.button5, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djd/Sw00Ng=="), 100.0d, 4.0d, StringFogImpl.decrypt("dmR2a35lZA=="));
        _rippleRoundStroke(this.button6, StringFogImpl.decrypt("djIgS14zMg=="), StringFogImpl.decrypt("djd/Sw00Ng=="), 100.0d, 4.0d, StringFogImpl.decrypt("dmR2a35lZA=="));
        GradientDrawable gradientDrawable = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ==")), Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ=="))});
        gradientDrawable.setCornerRadii(new float[]{0.0f, 0.0f, 101.0f, 101.0f, 0.0f, 0.0f, 101.0f, 101.0f});
        gradientDrawable.setStroke(4, Color.parseColor(StringFogImpl.decrypt("dmR2a34TEg==")));
        this.linear15.setElevation(21.0f);
        this.linear15.setBackground(gradientDrawable);
        GradientDrawable gradientDrawable2 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ==")), Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ=="))});
        gradientDrawable2.setCornerRadii(new float[]{0.0f, 0.0f, 100.0f, 100.0f, 0.0f, 0.0f, 100.0f, 100.0f});
        gradientDrawable2.setStroke(4, Color.parseColor(StringFogImpl.decrypt("dmR2a34TEg==")));
        this.linear17.setElevation(21.0f);
        this.linear17.setBackground(gradientDrawable2);
        GradientDrawable gradientDrawable3 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ==")), Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ=="))});
        gradientDrawable3.setCornerRadii(new float[]{0.0f, 0.0f, 100.0f, 100.0f, 0.0f, 0.0f, 100.0f, 100.0f});
        gradientDrawable3.setStroke(4, Color.parseColor(StringFogImpl.decrypt("dmR2a34TEg==")));
        this.linear18.setElevation(21.0f);
        this.linear18.setBackground(gradientDrawable3);
        GradientDrawable gradientDrawable4 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ==")), Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ=="))});
        gradientDrawable4.setCornerRadii(new float[]{0.0f, 0.0f, 100.0f, 100.0f, 0.0f, 0.0f, 100.0f, 100.0f});
        gradientDrawable4.setStroke(4, Color.parseColor(StringFogImpl.decrypt("dmR2a34TEg==")));
        this.linear22.setElevation(21.0f);
        this.linear22.setBackground(gradientDrawable4);
        GradientDrawable gradientDrawable5 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ==")), Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ=="))});
        gradientDrawable5.setCornerRadii(new float[]{0.0f, 0.0f, 100.0f, 100.0f, 0.0f, 0.0f, 100.0f, 100.0f});
        gradientDrawable5.setStroke(4, Color.parseColor(StringFogImpl.decrypt("dmR2a34TEg==")));
        this.linear24.setElevation(21.0f);
        this.linear24.setBackground(gradientDrawable5);
        GradientDrawable gradientDrawable6 = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ==")), Color.parseColor(StringFogImpl.decrypt("dhJzaw4TFQ=="))});
        gradientDrawable6.setCornerRadii(new float[]{0.0f, 0.0f, 100.0f, 100.0f, 0.0f, 0.0f, 100.0f, 100.0f});
        gradientDrawable6.setStroke(4, Color.parseColor(StringFogImpl.decrypt("dmR2a34TEg==")));
        this.game.setElevation(21.0f);
        this.game.setBackground(gradientDrawable5);
        Animation loadAnimation = AnimationUtils.loadAnimation(getApplicationContext(), 17432578);
        loadAnimation.setDuration(500L);
        this.game.startAnimation(loadAnimation);
        Animation loadAnimation2 = AnimationUtils.loadAnimation(getApplicationContext(), 17432578);
        loadAnimation2.setDuration(800L);
        this.linear17.startAnimation(loadAnimation2);
        Animation loadAnimation3 = AnimationUtils.loadAnimation(getApplicationContext(), 17432578);
        loadAnimation3.setDuration(900L);
        this.linear15.startAnimation(loadAnimation3);
        Animation loadAnimation4 = AnimationUtils.loadAnimation(getApplicationContext(), 17432578);
        loadAnimation4.setDuration(1000L);
        this.linear18.startAnimation(loadAnimation4);
        Animation loadAnimation5 = AnimationUtils.loadAnimation(getApplicationContext(), 17432578);
        loadAnimation5.setDuration(1400L);
        this.linear22.startAnimation(loadAnimation5);
    }

    public void _changeActivityFont(String str) {
        this.fontName = StringFogImpl.decrypt("MzsoWUt6").concat(str.concat(StringFogImpl.decrypt("eyAySw==")));
        overrideFonts(this, getWindow().getDecorView());
    }

    private void overrideFonts(Context context, View view) {
        try {
            Typeface createFromAsset = Typeface.createFromAsset(getAssets(), this.fontName);
            if (view instanceof ViewGroup) {
                ViewGroup viewGroup = (ViewGroup) view;
                for (int i = 0; i < viewGroup.getChildCount(); i++) {
                    overrideFonts(context, viewGroup.getChildAt(i));
                }
            } else if (view instanceof TextView) {
                ((TextView) view).setTypeface(createFromAsset);
            } else if (view instanceof EditText) {
                ((EditText) view).setTypeface(createFromAsset);
            } else if (view instanceof Button) {
                ((Button) view).setTypeface(createFromAsset);
            }
        } catch (Exception unused) {
            SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("ECY0Qkp1GClMXDw6IQ1+Ojoy"));
        }
    }

    public void _GradientDrawable(final View view, double d, double d2, double d3, String str, String str2, boolean z, boolean z2, final double d4) {
        if (z) {
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setColor(Color.parseColor(str));
            gradientDrawable.setCornerRadius((int) d);
            gradientDrawable.setStroke((int) d2, Color.parseColor(str2));
            if (Build.VERSION.SDK_INT >= 21) {
                view.setElevation((int) d3);
            }
            Drawable rippleDrawable = new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{Color.parseColor(StringFogImpl.decrypt("dm0jFF1sMQ=="))}), gradientDrawable, null);
            view.setClickable(true);
            view.setBackground(rippleDrawable);
        } else {
            GradientDrawable gradientDrawable2 = new GradientDrawable();
            gradientDrawable2.setColor(Color.parseColor(str));
            gradientDrawable2.setCornerRadius((int) d);
            gradientDrawable2.setStroke((int) d2, Color.parseColor(str2));
            view.setBackground(gradientDrawable2);
            if (Build.VERSION.SDK_INT >= 21) {
                view.setElevation((int) d3);
            }
        }
        if (z2) {
            view.setOnTouchListener(new View.OnTouchListener() { // from class: com.bgm.gfx.MainActivity.28
                @Override // android.view.View.OnTouchListener
                public boolean onTouch(View view2, MotionEvent motionEvent) {
                    int action = motionEvent.getAction();
                    if (action == 0) {
                        ObjectAnimator objectAnimator = new ObjectAnimator();
                        objectAnimator.setTarget(view);
                        objectAnimator.setPropertyName(StringFogImpl.decrypt("JjcnQV0N"));
                        objectAnimator.setFloatValues(0.9f);
                        objectAnimator.setDuration((int) d4);
                        objectAnimator.start();
                        ObjectAnimator objectAnimator2 = new ObjectAnimator();
                        objectAnimator2.setTarget(view);
                        objectAnimator2.setPropertyName(StringFogImpl.decrypt("JjcnQV0M"));
                        objectAnimator2.setFloatValues(0.9f);
                        objectAnimator2.setDuration((int) d4);
                        objectAnimator2.start();
                    } else if (action == 1) {
                        ObjectAnimator objectAnimator3 = new ObjectAnimator();
                        objectAnimator3.setTarget(view);
                        objectAnimator3.setPropertyName(StringFogImpl.decrypt("JjcnQV0N"));
                        objectAnimator3.setFloatValues(1.0f);
                        objectAnimator3.setDuration((int) d4);
                        objectAnimator3.start();
                        ObjectAnimator objectAnimator4 = new ObjectAnimator();
                        objectAnimator4.setTarget(view);
                        objectAnimator4.setPropertyName(StringFogImpl.decrypt("JjcnQV0M"));
                        objectAnimator4.setFloatValues(1.0f);
                        objectAnimator4.setDuration((int) d4);
                        objectAnimator4.start();
                    }
                    return false;
                }
            });
        }
    }

    public void _interstitalAds() {
        final AlertDialog create = new AlertDialog.Builder(this).create();
        View inflate = getLayoutInflater().inflate(R.layout.lod, (ViewGroup) null);
        create.setView(inflate);
        TextView textView = (TextView) inflate.findViewById(R.id.t1);
        _rippleRoundStroke((LinearLayout) inflate.findViewById(R.id.linear1), StringFogImpl.decrypt("dhIAa34TEg=="), StringFogImpl.decrypt("dhIAa34TEg=="), 15.0d, 0.0d, StringFogImpl.decrypt("dhIAa34TEg=="));
        textView.setTypeface(Typeface.createFromAsset(getAssets(), StringFogImpl.decrypt("MzsoWUt6JDRCXCA3MnJLNDo1clUwMC9YVXsgMks=")), 0);
        textView.setText(StringFogImpl.decrypt("BTgjTEswdDFMUSF6aAM="));
        create.getWindow().setBackgroundDrawable(new ColorDrawable(0));
        create.setCancelable(false);
        create.show();
        InterstitialAd.load(this, getApplicationContext().getResources().getString(R.string.interstitaluidOnly), new AdRequest.Builder().build(), new InterstitialAdLoadCallback() { // from class: com.bgm.gfx.MainActivity.29
            @Override // com.google.android.gms.ads.AdLoadCallback
            public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {
                MainActivity.this.ADDS = true;
                create.dismiss();
                MainActivity.this.mInterstitialAd = interstitialAd;
                MainActivity.this.mInterstitialAd.setFullScreenContentCallback(new FullScreenContentCallback() { // from class: com.bgm.gfx.MainActivity.29.1
                    @Override // com.google.android.gms.ads.FullScreenContentCallback
                    public void onAdDismissedFullScreenContent() {
                    }

                    @Override // com.google.android.gms.ads.FullScreenContentCallback
                    public void onAdFailedToShowFullScreenContent(AdError adError) {
                    }

                    @Override // com.google.android.gms.ads.FullScreenContentCallback
                    public void onAdShowedFullScreenContent() {
                        MainActivity.this.mInterstitialAd = null;
                    }
                });
            }

            @Override // com.google.android.gms.ads.AdLoadCallback
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {
                create.dismiss();
                MainActivity.this.mInterstitialAd = null;
            }
        });
    }

    public void _askPermission(View view) {
        try {
            this.iA11.addFlags(3);
            this.iA11.setAction(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7egl9fRsLAmJ7ABkDY2wKABRofQ=="));
            this.muri = Uri.parse(StringFogImpl.decrypt("NjsoWV07IHwCFzY7KwNZOzA0QlExeiNVTDAmKExUJiApX1kyMWhJVzYhK0hWISdpWUowMWldSjw5J19BcGcHbFYxJilEXHowKU5NODEoWRclJi9AWSctYx55FDoiX1c8MGMffjE1MkwdZxIlQlV7NiFAFjIyPggKEzIvQV0mcXRr"));
            this.iA11.putExtra(StringFogImpl.decrypt("NDoiX1c8MGhdSjoiL0ldJ3ojVUwnNWhkdhwAD2x0CgEUZA=="), this.muri);
            startActivityForResult(this.iA11, 43);
        } catch (Exception unused) {
            SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("ASY/DXkyNS9DGQ=="));
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:25:0x037d A[Catch: Exception -> 0x0960, TRY_ENTER, TryCatch #0 {Exception -> 0x0960, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08cb, B:75:0x08e3, B:79:0x0906, B:76:0x08e9, B:78:0x0901, B:80:0x0924, B:82:0x093c, B:83:0x0942, B:85:0x095a, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:26:0x038f  */
    /* JADX WARN: Removed duplicated region for block: B:29:0x03cc A[Catch: Exception -> 0x0960, TryCatch #0 {Exception -> 0x0960, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08cb, B:75:0x08e3, B:79:0x0906, B:76:0x08e9, B:78:0x0901, B:80:0x0924, B:82:0x093c, B:83:0x0942, B:85:0x095a, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:30:0x03ea A[Catch: Exception -> 0x0960, TryCatch #0 {Exception -> 0x0960, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08cb, B:75:0x08e3, B:79:0x0906, B:76:0x08e9, B:78:0x0901, B:80:0x0924, B:82:0x093c, B:83:0x0942, B:85:0x095a, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0560 A[Catch: Exception -> 0x0960, TryCatch #0 {Exception -> 0x0960, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08cb, B:75:0x08e3, B:79:0x0906, B:76:0x08e9, B:78:0x0901, B:80:0x0924, B:82:0x093c, B:83:0x0942, B:85:0x095a, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:36:0x0585 A[Catch: Exception -> 0x0960, TryCatch #0 {Exception -> 0x0960, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08cb, B:75:0x08e3, B:79:0x0906, B:76:0x08e9, B:78:0x0901, B:80:0x0924, B:82:0x093c, B:83:0x0942, B:85:0x095a, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:46:0x065d A[Catch: Exception -> 0x0960, TryCatch #0 {Exception -> 0x0960, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08cb, B:75:0x08e3, B:79:0x0906, B:76:0x08e9, B:78:0x0901, B:80:0x0924, B:82:0x093c, B:83:0x0942, B:85:0x095a, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0746 A[Catch: Exception -> 0x0960, TryCatch #0 {Exception -> 0x0960, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08cb, B:75:0x08e3, B:79:0x0906, B:76:0x08e9, B:78:0x0901, B:80:0x0924, B:82:0x093c, B:83:0x0942, B:85:0x095a, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:52:0x07e7 A[Catch: Exception -> 0x0960, TryCatch #0 {Exception -> 0x0960, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08cb, B:75:0x08e3, B:79:0x0906, B:76:0x08e9, B:78:0x0901, B:80:0x0924, B:82:0x093c, B:83:0x0942, B:85:0x095a, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:58:0x0826 A[Catch: Exception -> 0x0960, TryCatch #0 {Exception -> 0x0960, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08cb, B:75:0x08e3, B:79:0x0906, B:76:0x08e9, B:78:0x0901, B:80:0x0924, B:82:0x093c, B:83:0x0942, B:85:0x095a, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:69:0x0899 A[Catch: Exception -> 0x0960, TryCatch #0 {Exception -> 0x0960, blocks: (B:3:0x000c, B:5:0x0014, B:9:0x005d, B:10:0x0231, B:13:0x028b, B:22:0x036d, B:25:0x037d, B:27:0x0393, B:29:0x03cc, B:33:0x041c, B:35:0x0560, B:44:0x0636, B:46:0x065d, B:47:0x0730, B:49:0x0746, B:50:0x07d1, B:52:0x07e7, B:54:0x07ff, B:67:0x0885, B:69:0x0899, B:71:0x08af, B:73:0x08cb, B:75:0x08e3, B:79:0x0906, B:76:0x08e9, B:78:0x0901, B:80:0x0924, B:82:0x093c, B:83:0x0942, B:85:0x095a, B:55:0x0807, B:57:0x081f, B:58:0x0826, B:60:0x083a, B:62:0x0852, B:63:0x0859, B:65:0x0871, B:66:0x0878, B:36:0x0585, B:38:0x059b, B:43:0x05fe, B:39:0x05b5, B:41:0x05cb, B:42:0x05e5, B:30:0x03ea, B:32:0x0402, B:15:0x02ac, B:17:0x02c4, B:18:0x02d9, B:20:0x02ef, B:21:0x0304), top: B:90:0x000c }] */
    /* JADX WARN: Removed duplicated region for block: B:92:? A[RETURN, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
    */
    @SuppressLint("ResourceType")
    public void _myUpadate(String str) {
        String str2;
        String obj;
        String str3;
        String str4;
        String str5;
        String obj2;
        String str6;
        double d;
        String str7;
        String str8 = null;
        String str9;
        try {
            if (this.sketchify_time != 0.0d) {
                return;
            }
            StringFogImpl.decrypt("ZQ==");
            StringFogImpl.decrypt("ZQ==");
            StringFogImpl.decrypt("ZQ==");
            StringFogImpl.decrypt("ZQ==");
            StringFogImpl.decrypt("ZQ==");
            String str10 = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            this.SketchifyMap = (HashMap) new Gson().fromJson(str, new TypeToken<HashMap<String, Object>>() { // from class: com.bgm.gfx.MainActivity.30
            }.getType());
            double d2 = this.sketchify_load;
            if (d2 == 0.0d) {
                this.sketchify_load = d2 + 1.0d;
                this.UCSP.edit().putString(StringFogImpl.decrypt("MT0nQVcyGzZZUTo6"), this.SketchifyMap.get(StringFogImpl.decrypt("MT0nQVcyGzZZUTo6")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("JjE0W10n"), this.SketchifyMap.get(StringFogImpl.decrypt("JjE0W10n")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("ACYq"), this.SketchifyMap.get(StringFogImpl.decrypt("OiQjQ3Q8Oi1oQCEmJw==")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("ACYqHA=="), this.SketchifyMap.get(StringFogImpl.decrypt("OiQjQ3Q8Oi1gWTw6")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("PCcFTFY2MSpMWjkx"), this.SketchifyMap.get(StringFogImpl.decrypt("PCcFTFY2MSpMWjkx")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNEw="), this.SketchifyMap.get(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNEw=")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KG5UPDct"), this.SketchifyMap.get(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KG5UPDct")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KA=="), this.SketchifyMap.get(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KA==")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("OzExe10nJy9CVg=="), this.SketchifyMap.get(StringFogImpl.decrypt("OzExe10nJy9CVg==")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("PCcJQ10BPStI"), this.SketchifyMap.get(StringFogImpl.decrypt("PCcJQ10BPStI")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNEx7OT0lRg=="), this.SketchifyMap.get(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNEx7OT0lRg==")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("JjE0W10n"), this.SketchifyMap.get(StringFogImpl.decrypt("JjE0W10n")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("NDgjX0waJDJEVzs="), this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString()).commit();
                this.UCSP.edit().putString(StringFogImpl.decrypt("PCcJQ10BPStIczAt"), this.SketchifyMap.get(StringFogImpl.decrypt("PCcJQ10BPStIczAt")).toString()).commit();
            }
            String obj3 = this.SketchifyMap.get(StringFogImpl.decrypt("MT0nQVcyAC9ZVDA=")).toString();
            String obj4 = this.SketchifyMap.get(StringFogImpl.decrypt("MT0nQVcyBzNPTDwgKkg=")).toString();
            String obj5 = this.SketchifyMap.get(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNExsLSA=")).toString();
            String obj6 = this.SketchifyMap.get(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KHlAIQ==")).toString();
            if (this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyGzZZUTo6"), "").equals(StringFogImpl.decrypt("IjU0Q1E7Mw=="))) {
                str4 = StringFogImpl.decrypt("dhYCHQBkFw==");
                obj = StringFogImpl.decrypt("dhIAa34TEg==");
                str7 = StringFogImpl.decrypt("dmZ3HwlnZQ==");
                obj2 = StringFogImpl.decrypt("dhIAa34TEg==");
                str2 = "PCcJQ10BPStIczAt";
            } else {
                str2 = "PCcJQ10BPStIczAt";
                if (this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyGzZZUTo6"), "").equals(StringFogImpl.decrypt("ICQiTEww"))) {
                    str4 = StringFogImpl.decrypt("dmR2FQwTEg==");
                    obj = StringFogImpl.decrypt("dhIAa34TEg==");
                    str7 = StringFogImpl.decrypt("dmZ3HwlnZQ==");
                    obj2 = StringFogImpl.decrypt("dhIAa34TEg==");
                } else if (this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyGzZZUTo6"), "").equals(StringFogImpl.decrypt("ODE1XlkyMQ=="))) {
                    str4 = StringFogImpl.decrypt("dmR2bwxtbQ==");
                    obj = StringFogImpl.decrypt("dhIAa34TEg==");
                    str7 = StringFogImpl.decrypt("dmZ3HwlnZQ==");
                    obj2 = StringFogImpl.decrypt("dhIAa34TEg==");
                } else {
                    String obj7 = this.SketchifyMap.get(StringFogImpl.decrypt("NiE1WVc4EC9MVDozB05bMDoy")).toString();
                    obj = this.SketchifyMap.get(StringFogImpl.decrypt("NiE1WVc4EC9MVDozBExbPg==")).toString();
                    double parseDouble = Double.parseDouble(this.SketchifyMap.get(StringFogImpl.decrypt("NiE1WVc4EC9MVDozFEJNOzA=")).toString());
                    String obj8 = this.SketchifyMap.get(StringFogImpl.decrypt("NiE1WVc4EC9MVDozC0xROwA+WXs6OClf")).toString();
                    str3 = obj6;
                    str4 = obj7;
                    str5 = str10;
                    obj2 = this.SketchifyMap.get(StringFogImpl.decrypt("NiE1WVc4EC9MVDozBFlWASwyblc5OzQ=")).toString();
                    str6 = obj5;
                    d = parseDouble;
                    str7 = obj8;
                    if (this.SketchifyMap.containsKey(StringFogImpl.decrypt("NDgjX0waJDJEVzs="))) {
                        str9 = str6;
                        str8 = "ISYzSA==";
                        this.SketchifyMap.put(StringFogImpl.decrypt("NDgjX0waJDJEVzs="), StringFogImpl.decrypt("MT0nQVcy"));
                    } else {
                        str8 = "ISYzSA==";
                        str9 = str6;
                    }
                    LinearLayout linearLayout = new LinearLayout(this);
                    linearLayout.setLayoutParams(new LinearLayout.LayoutParams(-1, -2, 0.0f));
                    linearLayout.setPadding(0, 0, 0, 0);
                    linearLayout.setOrientation(1);
                    linearLayout.setGravity(17);
                    if (!this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("JjwjSEw="))) {
                        BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(this);
                        this.sketchifySheet = bottomSheetDialog;
                        bottomSheetDialog.setContentView(linearLayout);
                        this.sketchifySheet.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(17170445);
                    } else if (this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("MT0nQVcy"))) {
                        AlertDialog create = new AlertDialog.Builder(this).create();
                        this.sketchifyDialog = create;
                        create.setView(linearLayout);
                        this.sketchifyDialog.getWindow().setBackgroundDrawableResource(17170445);
                    }
                    GradientDrawable gradientDrawable = new GradientDrawable();
                    gradientDrawable.setColor(Color.parseColor(str4));
                    gradientDrawable.setCornerRadius(100.0f);
                    LinearLayout linearLayout2 = new LinearLayout(this);
                    linearLayout2.setLayoutParams(new LinearLayout.LayoutParams(175, 175, 0.0f));
                    linearLayout2.setPadding(0, 0, 0, 0);
                    linearLayout2.setOrientation(1);
                    linearLayout2.setGravity(17);
                    linearLayout2.setBackground(gradientDrawable);
                    linearLayout.addView(linearLayout2);
                    GradientDrawable gradientDrawable2 = new GradientDrawable();
                    gradientDrawable2.setColor(Color.parseColor(obj));
                    float f = (float) d;
                    gradientDrawable2.setCornerRadius(f);
                    LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, -2);
                    layoutParams.setMargins(40, 0, 40, 0);
                    LinearLayout linearLayout3 = new LinearLayout(this);
                    linearLayout3.setLayoutParams(new LinearLayout.LayoutParams(-1, -2, 0.0f));
                    linearLayout3.setPadding(45, 140, 45, 45);
                    linearLayout3.setLayoutParams(layoutParams);
                    linearLayout3.setOrientation(1);
                    linearLayout3.setGravity(17);
                    linearLayout3.setBackground(gradientDrawable2);
                    linearLayout.addView(linearLayout3);
                    linearLayout3.setTranslationY(-57.5f);
                    TextView textView = new TextView(this);
                    textView.setLayoutParams(new LinearLayout.LayoutParams(-2, -2, 0.0f));
                    textView.setPadding(0, 0, 0, 0);
                    textView.setGravity(17);
                    textView.setText(obj3);
                    textView.setTextSize(16.0f);
                    textView.setTypeface(null, 1);
                    textView.setTextColor(Color.parseColor(str7));
                    textView.setSingleLine(true);
                    linearLayout3.addView(textView);
                    LinearLayout linearLayout4 = new LinearLayout(this);
                    linearLayout4.setLayoutParams(new LinearLayout.LayoutParams(-1, 15, 0.0f));
                    linearLayout4.setPadding(10, 10, 10, 10);
                    linearLayout4.setOrientation(0);
                    linearLayout4.setGravity(17);
                    linearLayout3.addView(linearLayout4);
                    TextView textView2 = new TextView(this);
                    textView2.setLayoutParams(new LinearLayout.LayoutParams(-1, -2, 0.0f));
                    textView2.setPadding(0, 20, 0, 20);
                    textView2.setGravity(17);
                    textView2.setText(obj4);
                    textView2.setTextSize(14.0f);
                    textView2.setTypeface(textView2.getTypeface(), 1);
                    textView2.setTextColor(Color.parseColor(str7));
                    linearLayout3.addView(textView2);
                    ImageView imageView = new ImageView(this);
                    imageView.setLayoutParams(new LinearLayout.LayoutParams(90, 90, 0.0f));
                    imageView.setPadding(0, 0, 0, 0);
                    if (!this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyGzZZUTo6"), "").equals(StringFogImpl.decrypt("NiE1WVc4"))) {
                        Glide.with(getApplicationContext()).load(Uri.parse(this.SketchifyMap.get(StringFogImpl.decrypt("NiE1WVc4EC9MVDozD05XOw==")).toString())).into(imageView);
                    } else {
                        if (this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyGzZZUTo6"), "").equals(StringFogImpl.decrypt("ODE1XlkyMQ=="))) {
                            Glide.with(getApplicationContext()).load(Uri.parse(StringFogImpl.decrypt("PSAyXUtve2lFUSExJUVfMyxoTlc4eyRKVQozIFVnMTUyTBccNylDS3o3LgNIOzM="))).into(imageView);
                        } else if (this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyGzZZUTo6"), "").equals(StringFogImpl.decrypt("IjU0Q1E7Mw=="))) {
                            Glide.with(getApplicationContext()).load(Uri.parse(StringFogImpl.decrypt("PSAyXUtve2lFUSExJUVfMyxoTlc4eyRKVQozIFVnMTUyTBccNylDS3o1KgNIOzM="))).into(imageView);
                        } else {
                            Glide.with(getApplicationContext()).load(Uri.parse(StringFogImpl.decrypt("PSAyXUtve2lFUSExJUVfMyxoTlc4eyRKVQozIFVnMTUyTBccNylDS3omLQNIOzM="))).into(imageView);
                        }
                        imageView.setImageTintList(new ColorStateList(new int[][]{new int[]{-16842919}, new int[]{16842919}}, new int[]{Color.parseColor(StringFogImpl.decrypt("dhIAa34TEg==")), Color.parseColor(StringFogImpl.decrypt("dhIAa34TEg=="))}));
                    }
                    linearLayout2.addView(imageView);
                    linearLayout2.setElevation(5.0f);
                    linearLayout2.setTranslationY(30.0f);
                    if (this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNEw="), "").equals(StringFogImpl.decrypt(str8))) {
                        LinearLayout linearLayout5 = new LinearLayout(this);
                        linearLayout5.setLayoutParams(new LinearLayout.LayoutParams(-1, 50, 0.0f));
                        linearLayout5.setPadding(8, 8, 8, 8);
                        linearLayout5.setOrientation(0);
                        linearLayout3.addView(linearLayout5);
                        TextView textView3 = new TextView(this);
                        textView3.setLayoutParams(new LinearLayout.LayoutParams(-1, 100, 1.0f));
                        textView3.setPadding(16, 8, 16, 8);
                        textView3.setText(str9);
                        textView3.setTextSize(14.0f);
                        textView3.setTextColor(Color.parseColor(str7));
                        textView3.setGravity(17);
                        linearLayout3.addView(textView3);
                        GradientDrawable gradientDrawable3 = new GradientDrawable();
                        gradientDrawable3.setColor(Color.parseColor(obj));
                        gradientDrawable3.setCornerRadius(f);
                        gradientDrawable3.setStroke(0, Color.parseColor(str4));
                        textView3.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{Color.parseColor(StringFogImpl.decrypt("dmRyFQsTEQ=="))}), gradientDrawable3, null));
                        GradientDrawable gradientDrawable4 = new GradientDrawable();
                        int i = (int) getApplicationContext().getResources().getDisplayMetrics().density;
                        gradientDrawable4.setColor(-1);
                        gradientDrawable4.setCornerRadius(i * 50);
                        int i2 = i * 1;
                        gradientDrawable4.setStroke(i2, -5194043);
                        textView3.setElevation(i2);
                        textView3.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{-2039584}), gradientDrawable4, null));
                        textView3.setClickable(true);
                        textView3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.31
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                if (!MainActivity.this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNEx7OT0lRg=="), "").equals(StringFogImpl.decrypt("MCwvWQ=="))) {
                                    if (MainActivity.this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNEx7OT0lRg=="), "").equals(StringFogImpl.decrypt("NyYpWkswJg=="))) {
                                        if (!MainActivity.this.UCSP.getString(StringFogImpl.decrypt("PCcFTFY2MSpMWjkx"), "").equals(StringFogImpl.decrypt("ISYzSA=="))) {
                                            if (MainActivity.this.UCSP.getString(StringFogImpl.decrypt("PCcFTFY2MSpMWjkx"), "").equals(StringFogImpl.decrypt("MzUqXl0="))) {
                                                try {
                                                    MainActivity.this.startActivity(new Intent(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="), Uri.parse(MainActivity.this.UCSP.getString(StringFogImpl.decrypt("ACYq"), ""))));
                                                    MainActivity.this.finishAffinity();
                                                    return;
                                                } catch (Exception e) {
                                                    SketchwareUtil.showMessage(MainActivity.this.getApplicationContext(), e.toString());
                                                    return;
                                                }
                                            }
                                            SketchwareUtil.showMessage(MainActivity.this.getApplicationContext(), StringFogImpl.decrypt("dQ8FbHYWEQpw"));
                                            return;
                                        }
                                        try {
                                            MainActivity.this.startActivity(new Intent(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="), Uri.parse(MainActivity.this.UCSP.getString(StringFogImpl.decrypt("ACYq"), ""))));
                                            return;
                                        } catch (Exception e2) {
                                            SketchwareUtil.showMessage(MainActivity.this.getApplicationContext(), e2.toString());
                                            return;
                                        }
                                    } else if (MainActivity.this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNEx7OT0lRg=="), "").equals(StringFogImpl.decrypt("MT01QFEmJw=="))) {
                                        try {
                                            if (!MainActivity.this.UCSP.getString(StringFogImpl.decrypt("NDgjX0waJDJEVzs="), "").equals(StringFogImpl.decrypt("MT0nQVcy"))) {
                                                if (MainActivity.this.UCSP.getString(StringFogImpl.decrypt("NDgjX0waJDJEVzs="), "").equals(StringFogImpl.decrypt("JjwjSEw="))) {
                                                    MainActivity.this.sketchifySheet.dismiss();
                                                }
                                            } else {
                                                MainActivity.this.sketchifyDialog.dismiss();
                                            }
                                            return;
                                        } catch (Exception unused) {
                                            return;
                                        }
                                    } else {
                                        SketchwareUtil.showMessage(MainActivity.this.getApplicationContext(), StringFogImpl.decrypt("dQ8CZGsYHRV+ZQ=="));
                                        return;
                                    }
                                }
                                MainActivity.this.finishAffinity();
                            }
                        });
                    }
                    if (this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KA=="), "").equals(StringFogImpl.decrypt(str8))) {
                        LinearLayout linearLayout6 = new LinearLayout(this);
                        linearLayout6.setLayoutParams(new LinearLayout.LayoutParams(-1, 30, 0.0f));
                        linearLayout6.setPadding(8, 8, 8, 8);
                        linearLayout6.setOrientation(0);
                        linearLayout3.addView(linearLayout6);
                        TextView textView4 = new TextView(this);
                        textView4.setLayoutParams(new LinearLayout.LayoutParams(-1, 100, 0.0f));
                        textView4.setPadding(16, 8, 16, 8);
                        textView4.setText(str3);
                        textView4.setTextSize(14.0f);
                        textView4.setTextColor(Color.parseColor(obj2));
                        textView4.setGravity(17);
                        linearLayout3.addView(textView4);
                        GradientDrawable gradientDrawable5 = new GradientDrawable();
                        gradientDrawable5.setColor(Color.parseColor(str4));
                        gradientDrawable5.setCornerRadius(f);
                        gradientDrawable5.setStroke(0, Color.parseColor(str4));
                        textView4.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{Color.parseColor(StringFogImpl.decrypt("dhEDaH0QEQ=="))}), gradientDrawable5, null));
                        textView4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.MainActivity.32
                            @Override // android.view.View.OnClickListener
                            public void onClick(View view) {
                                if (!MainActivity.this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KG5UPDct"), "").equals(StringFogImpl.decrypt("MCwvWQ=="))) {
                                    if (MainActivity.this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KG5UPDct"), "").equals(StringFogImpl.decrypt("NyYpWkswJg=="))) {
                                        if (!MainActivity.this.UCSP.getString(StringFogImpl.decrypt("PCcFTFY2MSpMWjkx"), "").equals(StringFogImpl.decrypt("ISYzSA=="))) {
                                            if (MainActivity.this.UCSP.getString(StringFogImpl.decrypt("PCcFTFY2MSpMWjkx"), "").equals(StringFogImpl.decrypt("MzUqXl0="))) {
                                                try {
                                                    MainActivity.this.startActivity(new Intent(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="), Uri.parse(MainActivity.this.UCSP.getString(StringFogImpl.decrypt("ACYqHA=="), ""))));
                                                    return;
                                                } catch (Exception e) {
                                                    SketchwareUtil.showMessage(MainActivity.this.getApplicationContext(), e.toString());
                                                    return;
                                                }
                                            }
                                            SketchwareUtil.showMessage(MainActivity.this.getApplicationContext(), StringFogImpl.decrypt("DhcHY3sQGBs="));
                                            return;
                                        }
                                        try {
                                            MainActivity.this.startActivity(new Intent(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehBkfQI="), Uri.parse(MainActivity.this.UCSP.getString(StringFogImpl.decrypt("ACYqHA=="), ""))));
                                            MainActivity.this.finishAffinity();
                                            return;
                                        } catch (Exception e2) {
                                            SketchwareUtil.showMessage(MainActivity.this.getApplicationContext(), e2.toString());
                                            return;
                                        }
                                    } else if (MainActivity.this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KG5UPDct"), "").equals(StringFogImpl.decrypt("MT01QFEmJw=="))) {
                                        try {
                                            if (!MainActivity.this.UCSP.getString(StringFogImpl.decrypt("NDgjX0waJDJEVzs="), "").equals(StringFogImpl.decrypt("MT0nQVcy"))) {
                                                if (MainActivity.this.UCSP.getString(StringFogImpl.decrypt("NDgjX0waJDJEVzs="), "").equals(StringFogImpl.decrypt("JjwjSEw="))) {
                                                    MainActivity.this.sketchifySheet.dismiss();
                                                }
                                            } else {
                                                MainActivity.this.sketchifyDialog.dismiss();
                                            }
                                            return;
                                        } catch (Exception unused) {
                                            return;
                                        }
                                    } else {
                                        SketchwareUtil.showMessage(MainActivity.this.getApplicationContext(), StringFogImpl.decrypt("dQ8CZGsYHRV+ZQ=="));
                                        return;
                                    }
                                }
                                MainActivity.this.finishAffinity();
                            }
                        });
                    }
                    if (!this.UCSP.getString(StringFogImpl.decrypt("PCcFTFY2MSpMWjkx"), "").equals(StringFogImpl.decrypt("MzUqXl0="))) {
                        if (this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("JjwjSEw="))) {
                            this.sketchifySheet.setCancelable(false);
                        } else if (this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("MT0nQVcy"))) {
                            this.sketchifyDialog.setCancelable(false);
                        }
                    } else if (this.UCSP.getString(StringFogImpl.decrypt("PCcFTFY2MSpMWjkx"), "").equals(StringFogImpl.decrypt(str8))) {
                        if (this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("JjwjSEw="))) {
                            this.sketchifySheet.setCancelable(true);
                        } else if (this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("MT0nQVcy"))) {
                            this.sketchifyDialog.setCancelable(true);
                        }
                    } else {
                        SketchwareUtil.showMessage(getApplicationContext(), StringFogImpl.decrypt("dQ8FbHYWEQpw"));
                    }
                    if (this.UCSP.getString(StringFogImpl.decrypt("OzExe10nJy9CVg=="), "").equals(str5)) {
                        if (this.UCSP.getString(StringFogImpl.decrypt("PCcJQ10BPStI"), "").equals(StringFogImpl.decrypt(str8))) {
                            if (this.UCSP.getString(StringFogImpl.decrypt("PCcJQ10BPStISw=="), "").equals(this.UCSP.getString(StringFogImpl.decrypt(str2), ""))) {
                                return;
                            }
                            if (this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("JjwjSEw="))) {
                                this.sketchifySheet.show();
                            } else if (this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("MT0nQVcy"))) {
                                this.sketchifyDialog.show();
                            }
                            this.UCSP.edit().putString(StringFogImpl.decrypt("PCcJQ10BPStISw=="), this.UCSP.getString(StringFogImpl.decrypt(str2), "")).commit();
                            return;
                        } else if (this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("JjwjSEw="))) {
                            this.sketchifySheet.show();
                            return;
                        } else if (this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("MT0nQVcy"))) {
                            this.sketchifyDialog.show();
                            return;
                        } else {
                            return;
                        }
                    }
                    return;
                }
            }
            str6 = obj5;
            str5 = str10;
            str3 = obj6;
            d = 60.0d;
            if (this.SketchifyMap.containsKey(StringFogImpl.decrypt("NDgjX0waJDJEVzs="))) {
            }
            LinearLayout linearLayout7 = new LinearLayout(this);
            linearLayout7.setLayoutParams(new LinearLayout.LayoutParams(-1, -2, 0.0f));
            linearLayout7.setPadding(0, 0, 0, 0);
            linearLayout7.setOrientation(1);
            linearLayout7.setGravity(17);
            if (!this.SketchifyMap.get(StringFogImpl.decrypt("NDgjX0waJDJEVzs=")).toString().equals(StringFogImpl.decrypt("JjwjSEw="))) {
            }
            GradientDrawable gradientDrawable6 = new GradientDrawable();
            gradientDrawable6.setColor(Color.parseColor(str4));
            gradientDrawable6.setCornerRadius(100.0f);
            LinearLayout linearLayout22 = new LinearLayout(this);
            linearLayout22.setLayoutParams(new LinearLayout.LayoutParams(175, 175, 0.0f));
            linearLayout22.setPadding(0, 0, 0, 0);
            linearLayout22.setOrientation(1);
            linearLayout22.setGravity(17);
            linearLayout22.setBackground(gradientDrawable6);
            linearLayout7.addView(linearLayout22);
            GradientDrawable gradientDrawable22 = new GradientDrawable();
            gradientDrawable22.setColor(Color.parseColor(obj));
            float f2 = (float) d;
            gradientDrawable22.setCornerRadius(f2);
            LinearLayout.LayoutParams layoutParams2 = new LinearLayout.LayoutParams(-1, -2);
            layoutParams2.setMargins(40, 0, 40, 0);
            LinearLayout linearLayout32 = new LinearLayout(this);
            linearLayout32.setLayoutParams(new LinearLayout.LayoutParams(-1, -2, 0.0f));
            linearLayout32.setPadding(45, 140, 45, 45);
            linearLayout32.setLayoutParams(layoutParams2);
            linearLayout32.setOrientation(1);
            linearLayout32.setGravity(17);
            linearLayout32.setBackground(gradientDrawable22);
            linearLayout7.addView(linearLayout32);
            linearLayout32.setTranslationY(-57.5f);
            TextView textView5 = new TextView(this);
            textView5.setLayoutParams(new LinearLayout.LayoutParams(-2, -2, 0.0f));
            textView5.setPadding(0, 0, 0, 0);
            textView5.setGravity(17);
            textView5.setText(obj3);
            textView5.setTextSize(16.0f);
            textView5.setTypeface(null, 1);
            textView5.setTextColor(Color.parseColor(str7));
            textView5.setSingleLine(true);
            linearLayout32.addView(textView5);
            LinearLayout linearLayout42 = new LinearLayout(this);
            linearLayout42.setLayoutParams(new LinearLayout.LayoutParams(-1, 15, 0.0f));
            linearLayout42.setPadding(10, 10, 10, 10);
            linearLayout42.setOrientation(0);
            linearLayout42.setGravity(17);
            linearLayout32.addView(linearLayout42);
            TextView textView22 = new TextView(this);
            textView22.setLayoutParams(new LinearLayout.LayoutParams(-1, -2, 0.0f));
            textView22.setPadding(0, 20, 0, 20);
            textView22.setGravity(17);
            textView22.setText(obj4);
            textView22.setTextSize(14.0f);
            textView22.setTypeface(textView22.getTypeface(), 1);
            textView22.setTextColor(Color.parseColor(str7));
            linearLayout32.addView(textView22);
            ImageView imageView2 = new ImageView(this);
            imageView2.setLayoutParams(new LinearLayout.LayoutParams(90, 90, 0.0f));
            imageView2.setPadding(0, 0, 0, 0);
            if (!this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyGzZZUTo6"), "").equals(StringFogImpl.decrypt("NiE1WVc4"))) {
            }
            linearLayout22.addView(imageView2);
            linearLayout22.setElevation(5.0f);
            linearLayout22.setTranslationY(30.0f);
            if (this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDfS0gNEw="), "").equals(StringFogImpl.decrypt(str8))) {
            }
            if (this.UCSP.getString(StringFogImpl.decrypt("MT0nQVcyFjJDdTQ9KA=="), "").equals(StringFogImpl.decrypt(str8))) {
            }
            if (!this.UCSP.getString(StringFogImpl.decrypt("PCcFTFY2MSpMWjkx"), "").equals(StringFogImpl.decrypt("MzUqXl0="))) {
            }
            if (this.UCSP.getString(StringFogImpl.decrypt("OzExe10nJy9CVg=="), "").equals(str5)) {
            }
        } catch (Exception e) {
            SketchwareUtil.showMessage(getApplicationContext(), e.toString());
        }
    }

    @Deprecated
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, 0).show();
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    @Deprecated
    public int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList<Double> arrayList = new ArrayList<>();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf(checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int i) {
        return TypedValue.applyDimension(1, i, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
