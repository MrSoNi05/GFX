package com.bgm.gfx;

import android.animation.ObjectAnimator;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.os.Build;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.github.megatronking.stringfog.xor.StringFogImpl;
import com.google.firebase.FirebaseApp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

/* loaded from: classes7.dex */
public class ToolbarActivity extends AppCompatActivity {
    private Button B;
    private Button BGMDL;
    private Button G;
    private Button H;
    private Button IG;
    private Button K;
    private Button TG;
    private Button TW;
    private SharedPreferences VER;
    private Button VN;
    private Button YT;
    private Button button1;
    private ImageView imageview1;
    private LinearLayout linear1;
    private LinearLayout linear4;
    private TimerTask t;
    private TextView textview1;
    private ScrollView vscroll2;
    private Timer _timer = new Timer();
    private String fontName = "";
    private String typeace = "";
    private HashMap<String, Object> linkk = new HashMap<>();
    private Intent i = new Intent();
    private ObjectAnimator a = new ObjectAnimator();
    private ObjectAnimator o = new ObjectAnimator();

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.toolbar);
        initialize(bundle);
          //   FirebaseApp.initializeApp(String.valueOf(this));
        initializeLogic();
    }

    private void initialize(Bundle bundle) {
        this.linear1 = (LinearLayout) findViewById(R.id.linear1);
        this.imageview1 = (ImageView) findViewById(R.id.imageview1);
        this.textview1 = (TextView) findViewById(R.id.textview1);
        this.vscroll2 = (ScrollView) findViewById(R.id.vscroll2);
        this.linear4 = (LinearLayout) findViewById(R.id.linear4);
        this.YT = (Button) findViewById(R.id.YT);
        this.TG = (Button) findViewById(R.id.TG);
        this.IG = (Button) findViewById(R.id.IG);
        this.H = (Button) findViewById(R.id.H);
        this.B = (Button) findViewById(R.id.B);
        this.G = (Button) findViewById(R.id.G);
        this.K = (Button) findViewById(R.id.K);
        this.VN = (Button) findViewById(R.id.VN);
        this.TW = (Button) findViewById(R.id.TW);
        this.BGMDL = (Button) findViewById(R.id.BGMDL);
        this.button1 = (Button) findViewById(R.id.button1);
        this.VER = getSharedPreferences(StringFogImpl.decrypt("AxEU"), 0);
        this.TW.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.ToolbarActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
            }
        });
        this.BGMDL.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.ToolbarActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
            }
        });
    }

    private void initializeLogic() {
        _GradientDrawable(this.linear1, 0.0d, 0.0d, 35.0d, StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmIFGwsTEg=="), false, false, 0.0d);
        _NavStatusBarColor(StringFogImpl.decrypt("dmIFGwsTEg=="), StringFogImpl.decrypt("dmIFGwsTEg=="));
        TimerTask timerTask = new TimerTask() { // from class: com.bgm.gfx.ToolbarActivity.3
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                ToolbarActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.ToolbarActivity.3.1
                    @Override // java.lang.Runnable
                    public void run() {
                        ToolbarActivity.this.i.setClass(ToolbarActivity.this.getApplicationContext(), SplashActivity.class);
                        ToolbarActivity.this.startActivity(ToolbarActivity.this.i);
                        ToolbarActivity.this.t.cancel();
                        ToolbarActivity.this.finish();
                    }
                });
            }
        };
        this.t = timerTask;
        this._timer.schedule(timerTask, 3000L);
        this.a.setTarget(this.imageview1);
        this.a.setPropertyName(StringFogImpl.decrypt("NDg2RVk="));
        this.a.setFloatValues(0.0f, 1.0f);
        this.a.setDuration(1600L);
        this.a.start();
        this.o.setTarget(this.textview1);
        this.o.setPropertyName(StringFogImpl.decrypt("NDg2RVk="));
        this.o.setFloatValues(0.3f, 1.0f);
        this.o.setDuration(1500L);
        this.o.start();
        _link();
    }

    public void _NavStatusBarColor(String str, String str2) {
        if (Build.VERSION.SDK_INT > 21) {
            Window window = getWindow();
            window.clearFlags(67108864);
            window.addFlags(Integer.MIN_VALUE);
            window.setStatusBarColor(Color.parseColor(StringFogImpl.decrypt("dg==") + str.replace(StringFogImpl.decrypt("dg=="), "")));
            window.setNavigationBarColor(Color.parseColor(StringFogImpl.decrypt("dg==") + str2.replace(StringFogImpl.decrypt("dg=="), "")));
        }
    }

    public void _GradientDrawable(final View view, double d, double d2, double d3, String str, String str2, boolean z, boolean z2, final double d4) {
        if (z) {
            GradientDrawable gradientDrawable = new GradientDrawable();
            gradientDrawable.setColor(Color.parseColor(str));
            gradientDrawable.setCornerRadius((int) d);
            gradientDrawable.setStroke((int) d2, Color.parseColor(str2));
            if (Build.VERSION.SDK_INT >= 21) {
                view.setElevation((int) d3);
            }
            Drawable rippleDrawable = new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{Color.parseColor(StringFogImpl.decrypt("dm0jFF1sMQ=="))}), gradientDrawable, null);
            view.setClickable(true);
            view.setBackground(rippleDrawable);
        } else {
            GradientDrawable gradientDrawable2 = new GradientDrawable();
            gradientDrawable2.setColor(Color.parseColor(str));
            gradientDrawable2.setCornerRadius((int) d);
            gradientDrawable2.setStroke((int) d2, Color.parseColor(str2));
            view.setBackground(gradientDrawable2);
            if (Build.VERSION.SDK_INT >= 21) {
                view.setElevation((int) d3);
            }
        }
        if (z2) {
            view.setOnTouchListener(new View.OnTouchListener() { // from class: com.bgm.gfx.ToolbarActivity.4
                @Override // android.view.View.OnTouchListener
                public boolean onTouch(View view2, MotionEvent motionEvent) {
                    int action = motionEvent.getAction();
                    if (action == 0) {
                        ObjectAnimator objectAnimator = new ObjectAnimator();
                        objectAnimator.setTarget(view);
                        objectAnimator.setPropertyName(StringFogImpl.decrypt("JjcnQV0N"));
                        objectAnimator.setFloatValues(0.9f);
                        objectAnimator.setDuration((int) d4);
                        objectAnimator.start();
                        ObjectAnimator objectAnimator2 = new ObjectAnimator();
                        objectAnimator2.setTarget(view);
                        objectAnimator2.setPropertyName(StringFogImpl.decrypt("JjcnQV0M"));
                        objectAnimator2.setFloatValues(0.9f);
                        objectAnimator2.setDuration((int) d4);
                        objectAnimator2.start();
                    } else if (action == 1) {
                        ObjectAnimator objectAnimator3 = new ObjectAnimator();
                        objectAnimator3.setTarget(view);
                        objectAnimator3.setPropertyName(StringFogImpl.decrypt("JjcnQV0N"));
                        objectAnimator3.setFloatValues(1.0f);
                        objectAnimator3.setDuration((int) d4);
                        objectAnimator3.start();
                        ObjectAnimator objectAnimator4 = new ObjectAnimator();
                        objectAnimator4.setTarget(view);
                        objectAnimator4.setPropertyName(StringFogImpl.decrypt("JjcnQV0M"));
                        objectAnimator4.setFloatValues(1.0f);
                        objectAnimator4.setDuration((int) d4);
                        objectAnimator4.start();
                    }
                    return false;
                }
            });
        }
    }

    public void _view_shadow(View view, double d, String str) {
        view.setElevation((float) d);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            view.setOutlineAmbientShadowColor(Color.parseColor(str));
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            view.setOutlineSpotShadowColor(Color.parseColor(str));
        }
    }

    public void _link() {
        this.linear4.setVisibility(8);
        this.vscroll2.setVisibility(8);
        this.VER.edit().putString(StringFogImpl.decrypt("AREKaH8HFQs="), this.TG.getText().toString()).commit();
        this.VER.edit().putString(StringFogImpl.decrypt("DBsTeW0XEQ=="), this.YT.getText().toString()).commit();
        this.VER.edit().putString(StringFogImpl.decrypt("HBoVeXk="), this.IG.getText().toString()).commit();
        this.VER.edit().putString(StringFogImpl.decrypt("AAQOYnUQ"), this.H.getText().toString()).commit();
        this.VER.edit().putString(StringFogImpl.decrypt("AAQEanUc"), this.B.getText().toString()).commit();
        this.VER.edit().putString(StringFogImpl.decrypt("AAQBYQ=="), this.G.getText().toString()).commit();
        this.VER.edit().putString(StringFogImpl.decrypt("AAQNfw=="), this.K.getText().toString()).commit();
        this.VER.edit().putString(StringFogImpl.decrypt("AAQSeg=="), this.TW.getText().toString()).commit();
        this.VER.edit().putString(StringFogImpl.decrypt("AAQQYw=="), this.VN.getText().toString()).commit();
        this.VER.edit().putString(StringFogImpl.decrypt("FxMLaXQ="), this.BGMDL.getText().toString()).commit();
        this.VER.edit().putString(StringFogImpl.decrypt("EhgCYQ=="), this.button1.getText().toString()).commit();
    }

    @Deprecated
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, 0).show();
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    @Deprecated
    public int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList<Double> arrayList = new ArrayList<>();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf(checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int i) {
        return TypedValue.applyDimension(1, i, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
