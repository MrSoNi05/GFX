package com.bgm.gfx;

import android.app.AlertDialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.transition.AutoTransition;
import android.transition.TransitionManager;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import com.github.megatronking.stringfog.xor.StringFogImpl;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.firebase.FirebaseApp;
import java.util.ArrayList;
import java.util.Random;

/* loaded from: classes7.dex */
public class DebugNewMainActivity extends AppCompatActivity {
    private AppBarLayout _app_bar;
    private CoordinatorLayout _coordinator;
    private Toolbar _toolbar;
    private AlertDialog.Builder builder;
    private ImageView imageview1;
    private ImageView imageview3;
    private ImageView imageview4;
    private LinearLayout linear1;
    private LinearLayout linear10;
    private LinearLayout linear2;
    private LinearLayout linear3;
    private LinearLayout linear4;
    private LinearLayout linear6;
    private LinearLayout linear9;
    private TextView textview1;
    private TextView textview2;
    private TextView textview3;
    private TextView textview4;
    private TextView textview5;
    private TextView textview6;
    private TextView textview8;
    private ScrollView vscroll1;
    private String fontName = "";
    private Intent intent = new Intent();

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.debug);
        initialize(bundle);
          //   FirebaseApp.initializeApp(String.valueOf(this));
        initializeLogic();
    }

    private void initialize(Bundle bundle) {
        this._app_bar = (AppBarLayout) findViewById(R.id._app_bar);
        this._coordinator = (CoordinatorLayout) findViewById(R.id._coordinator);
        Toolbar toolbar = (Toolbar) findViewById(R.id._toolbar);
        this._toolbar = toolbar;
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);
        this._toolbar.setNavigationOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.DebugActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DebugNewMainActivity.this.onBackPressed();
            }
        });
        this.vscroll1 = (ScrollView) findViewById(R.id.vscroll1);
        this.linear6 = (LinearLayout) findViewById(R.id.linear6);
        this.linear1 = (LinearLayout) findViewById(R.id.linear1);
        this.linear9 = (LinearLayout) findViewById(R.id.linear9);
        this.imageview1 = (ImageView) findViewById(R.id.imageview1);
        this.textview4 = (TextView) findViewById(R.id.textview4);
        this.textview5 = (TextView) findViewById(R.id.textview5);
        this.linear2 = (LinearLayout) findViewById(R.id.linear2);
        this.linear3 = (LinearLayout) findViewById(R.id.linear3);
        this.linear4 = (LinearLayout) findViewById(R.id.linear4);
        this.textview6 = (TextView) findViewById(R.id.textview6);
        this.textview1 = (TextView) findViewById(R.id.textview1);
        this.textview2 = (TextView) findViewById(R.id.textview2);
        this.textview3 = (TextView) findViewById(R.id.textview3);
        this.linear10 = (LinearLayout) findViewById(R.id.linear10);
        this.textview8 = (TextView) findViewById(R.id.textview8);
        this.imageview3 = (ImageView) findViewById(R.id.imageview3);
        this.imageview4 = (ImageView) findViewById(R.id.imageview4);
        this.builder = new AlertDialog.Builder(this);
        this.linear2.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.DebugActivity.2
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DebugNewMainActivity.this.intent.setClass(DebugNewMainActivity.this.getApplicationContext(), ToolbarActivity.class);
                DebugNewMainActivity debugActivity = DebugNewMainActivity.this;
                debugActivity.startActivity(debugActivity.intent);
                DebugNewMainActivity.this.finish();
            }
        });
        this.linear3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.DebugActivity.3
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DebugNewMainActivity debugActivity = DebugNewMainActivity.this;
                debugActivity.getApplicationContext();
                ((ClipboardManager) debugActivity.getSystemService(StringFogImpl.decrypt("NjgvXVo6NTRJ"))).setPrimaryClip(ClipData.newPlainText(StringFogImpl.decrypt("NjgvXVo6NTRJ"), DebugNewMainActivity.this.getIntent().getStringExtra(StringFogImpl.decrypt("MCY0Qko="))));
                SketchwareUtil.showMessage(DebugNewMainActivity.this.getApplicationContext(), StringFogImpl.decrypt("Fjs2RF0x"));
            }
        });
        this.linear4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.DebugActivity.4
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                final BottomSheetDialog bottomSheetDialog = new BottomSheetDialog(DebugNewMainActivity.this);
                View inflate = DebugNewMainActivity.this.getLayoutInflater().inflate(R.layout.acc, (ViewGroup) null);
                bottomSheetDialog.setContentView(inflate);
                LinearLayout linearLayout = (LinearLayout) inflate.findViewById(R.id.linear2);
                ((TextView) inflate.findViewById(R.id.title)).setTypeface(Typeface.createFromAsset(DebugNewMainActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6JDRCXCA3MnJLNDo1clUwMC9YVXsgMks=")), 0);
                ((TextView) inflate.findViewById(R.id.zr)).setTypeface(Typeface.createFromAsset(DebugNewMainActivity.this.getAssets(), StringFogImpl.decrypt("MzsoWUt6JDRCXCA3MnJLNDo1clUwMC9YVXsgMks=")), 0);
                linearLayout.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.DebugActivity.4.1
                    @Override // android.view.View.OnClickListener
                    public void onClick(View view2) {
                        bottomSheetDialog.dismiss();
                        DebugNewMainActivity.this._reportClick();
                    }
                });
                bottomSheetDialog.getWindow().findViewById(R.id.design_bottom_sheet).setBackgroundResource(17170445);
                bottomSheetDialog.show();
                GradientDrawable gradientDrawable = new GradientDrawable();
                gradientDrawable.setCornerRadius(24.0f);
                gradientDrawable.setColor(Color.parseColor(StringFogImpl.decrypt("dhIAa34TEg==")));
                ((LinearLayout) inflate.findViewById(R.id.linear1)).setBackground(gradientDrawable);
                DebugNewMainActivity.this._rippleRoundStroke(linearLayout, StringFogImpl.decrypt("dmwFFH0TEg=="), StringFogImpl.decrypt("djIgS14zMg=="), 12.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
            }
        });
        this.imageview3.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.DebugActivity.5
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DebugNewMainActivity debugActivity = DebugNewMainActivity.this;
                debugActivity._autoScroll(300.0d, debugActivity.linear6);
                DebugNewMainActivity.this.linear1.setVisibility(0);
                DebugNewMainActivity.this.linear9.setVisibility(8);
            }
        });
        this.imageview4.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.DebugActivity.6
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                DebugNewMainActivity debugActivity = DebugNewMainActivity.this;
                debugActivity.getApplicationContext();
                ((ClipboardManager) debugActivity.getSystemService(StringFogImpl.decrypt("NjgvXVo6NTRJ"))).setPrimaryClip(ClipData.newPlainText(StringFogImpl.decrypt("NjgvXVo6NTRJ"), DebugNewMainActivity.this.getIntent().getStringExtra(StringFogImpl.decrypt("MCY0Qko="))));
                SketchwareUtil.showMessage(DebugNewMainActivity.this.getApplicationContext(), StringFogImpl.decrypt("Fjs2RFw="));
            }
        });
    }

    private void initializeLogic() {
        _NavStatusBarColor(StringFogImpl.decrypt("dmwFFH0TEg=="), StringFogImpl.decrypt("dhIAa34TEg=="));
        _rippleRoundStroke(this.linear2, StringFogImpl.decrypt("dmwFFH0TEg=="), StringFogImpl.decrypt("djIgS14zMg=="), 14.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _rippleRoundStroke(this.linear3, StringFogImpl.decrypt("dmwFFH0TEg=="), StringFogImpl.decrypt("djIgS14zMg=="), 14.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        _rippleRoundStroke(this.linear4, StringFogImpl.decrypt("dmwFFH0TEg=="), StringFogImpl.decrypt("djIgS14zMg=="), 14.0d, 0.0d, StringFogImpl.decrypt("djIgS14zMg=="));
        this.textview8.setText(getIntent().getStringExtra(StringFogImpl.decrypt("MCY0Qko=")));
        this.linear9.setVisibility(8);
        this.textview8.setTextIsSelectable(true);
        this.vscroll1.setVerticalScrollBarEnabled(false);
    }

    @Override // android.app.Activity
    public boolean onCreateOptionsMenu(Menu menu) {
        menu.add(StringFogImpl.decrypt("BjwpWhgwJjRCSnU3J1hLMA==")).setShowAsAction(0);
        return true;
    }

    @Override // android.app.Activity
    public boolean onOptionsItemSelected(MenuItem menuItem) {
        String charSequence = menuItem.getTitle().toString();
        if (charSequence.hashCode() == -897422386 && charSequence.equals(StringFogImpl.decrypt("BjwpWhgwJjRCSnU3J1hLMA=="))) {
            _showErrorClicked();
            return true;
        }
        return super.onOptionsItemSelected(menuItem);
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        finish();
    }

    public void _rippleRoundStroke(View view, String str, String str2, double d, double d2, String str3) {
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(Color.parseColor(str));
        gradientDrawable.setCornerRadius((float) d);
        gradientDrawable.setStroke((int) d2, Color.parseColor(StringFogImpl.decrypt("dg==") + str3.replace(StringFogImpl.decrypt("dg=="), "")));
        view.setBackground(new RippleDrawable(new ColorStateList(new int[][]{new int[0]}, new int[]{Color.parseColor(str2)}), gradientDrawable, null));
    }

    public void _showErrorClicked() {
        _autoScroll(300.0d, this.linear6);
        this.linear1.setVisibility(8);
        this.linear9.setVisibility(0);
    }

    public void _autoScroll(double d, View view) {
        AutoTransition autoTransition = new AutoTransition();
        autoTransition.setDuration((long) d);
        TransitionManager.beginDelayedTransition((LinearLayout) view, autoTransition);
    }

    public void _reportClick() {
        getApplicationContext();
        ((ClipboardManager) getSystemService(StringFogImpl.decrypt("NjgvXVo6NTRJ"))).setPrimaryClip(ClipData.newPlainText(StringFogImpl.decrypt("NjgvXVo6NTRJ"), getIntent().getStringExtra(StringFogImpl.decrypt("MCY0Qko="))));
        Intent intent = new Intent(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWNDcyRFc7ehVodhEACQ=="));
        intent.setData(Uri.parse(StringFogImpl.decrypt("ODUvQUw6bg==")));
        intent.putExtra(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWMCwyX1l7EQtscRk="), new String[]{StringFogImpl.decrypt("JSEkSlU6MD4ceDI5J0RUezcpQA==")});
        intent.putExtra(StringFogImpl.decrypt("NDoiX1c8MGhEViExKFkWMCwyX1l7BxNvchAXEg=="), StringFogImpl.decrypt("FyYnQ1x1dHwN").concat(Build.BRAND).concat("\n".concat(StringFogImpl.decrypt("HTU0SU80JiMNGG90").concat(Build.HARDWARE).concat("\n".concat(StringFogImpl.decrypt("GDsiSFR1dHwN").concat(Build.MANUFACTURER.concat(" ".concat(Build.MODEL))).concat("\n".concat(StringFogImpl.decrypt("FDoiX1c8MGZ7XScnL0JWdW5m").concat(Build.VERSION.RELEASE.concat("\n".concat(StringFogImpl.decrypt("ECY0Qkp1bmY=").concat(getIntent().getStringExtra(StringFogImpl.decrypt("MCY0Qko=")))))))))))));
        startActivity(Intent.createChooser(intent, StringFogImpl.decrypt("EDknRFR1Ii9MFnt6")));
    }

    public void _NavStatusBarColor(String str, String str2) {
        if (Build.VERSION.SDK_INT > 21) {
            Window window = getWindow();
            window.clearFlags(67108864);
            window.addFlags(Integer.MIN_VALUE);
            window.setStatusBarColor(Color.parseColor(StringFogImpl.decrypt("dg==") + str.replace(StringFogImpl.decrypt("dg=="), "")));
            window.setNavigationBarColor(Color.parseColor(StringFogImpl.decrypt("dg==") + str2.replace(StringFogImpl.decrypt("dg=="), "")));
        }
    }

    @Deprecated
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, 0).show();
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    @Deprecated
    public int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList<Double> arrayList = new ArrayList<>();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf(checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int i) {
        return TypedValue.applyDimension(1, i, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
