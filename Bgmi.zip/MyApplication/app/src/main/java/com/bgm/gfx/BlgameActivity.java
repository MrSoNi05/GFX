package com.bgm.gfx;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.InputDeviceCompat;
import com.github.megatronking.stringfog.xor.StringFogImpl;
import com.google.firebase.FirebaseApp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;


/* loaded from: classes7.dex */
public class BlgameActivity extends AppCompatActivity {
    private ImageView ic_balloon;
    private ImageView imageview1;
    private ImageView imageview2;
    private LinearLayout linear2;
    private LinearLayout linear3;
    private LinearLayout linear4;
    private int positionX;
    private RelativeLayout rl_game;
    private TimerTask timer;
    private TextView tv_life;
    private TextView tv_score;
    private Timer _timer = new Timer();
    private long create_id = 0;
    private long score = 0;
    private byte life = 5;
    private float move = 5.0f;
    private float moveBalloon = 25.0f;
    private float speed = 0.0f;
    private final Collision collision = new Collision();
    private final History hs = new History();
    private HashMap<String, Object> add = new HashMap<>();
    private boolean setDefaultPosition = false;
    private boolean hit = false;
    private boolean gameOver = false;
    private ArrayList<HashMap<String, Object>> getCreateBalloons = new ArrayList<>();
    private Intent intent = new Intent();

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.blgame);
        initialize(bundle);
          //   FirebaseApp.initializeApp(String.valueOf(this));
        initializeLogic();
    }

    private void initialize(Bundle bundle) {
        this.linear3 = (LinearLayout) findViewById(R.id.linear3);
        this.rl_game = (RelativeLayout) findViewById(R.id.rl_game);
        this.linear2 = (LinearLayout) findViewById(R.id.linear2);
        this.linear4 = (LinearLayout) findViewById(R.id.linear4);
        this.ic_balloon = (ImageView) findViewById(R.id.ic_balloon);
        this.imageview1 = (ImageView) findViewById(R.id.imageview1);
        this.tv_life = (TextView) findViewById(R.id.tv_life);
        this.tv_score = (TextView) findViewById(R.id.tv_score);
        this.imageview2 = (ImageView) findViewById(R.id.imageview2);
        this.rl_game.setOnClickListener(new View.OnClickListener() { // from class: com.bgm.gfx.BlgameActivity.1
            @Override // android.view.View.OnClickListener
            public void onClick(View view) {
                if (BlgameActivity.this.gameOver || !BlgameActivity.this.hit) {
                    return;
                }
                BlgameActivity.this.hit = false;
            }
        });
    }

    private void initializeLogic() {
        _updateLife(0.0d);
        _gameState();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        this.intent.setClass(getApplicationContext(), BmainActivity.class);
        startActivity(this.intent);
        finish();
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onStart() {
        super.onStart();
        overridePendingTransition(0, 0);
        getWindow().getDecorView().setSystemUiVisibility(InputDeviceCompat.SOURCE_TOUCHSCREEN);
    }

    public void _createBalloons() {
        if (this.gameOver) {
            return;
        }
        this.getCreateBalloons.clear();
        HashMap<String, Object> hashMap = new HashMap<>();
        this.add = hashMap;
        hashMap.put(StringFogImpl.decrypt("PDA="), String.valueOf(this.create_id));
        this.add.put(StringFogImpl.decrypt("JTs1"), String.valueOf(this.positionX));
        this.getCreateBalloons.add(this.add);
    }

    public void _viewBalloons() {
        if (this.gameOver) {
            return;
        }
        ImageView imageView = new ImageView(this);
        imageView.setId(Integer.parseInt(this.getCreateBalloons.get(0).get(StringFogImpl.decrypt("PDA=")).toString()));
        imageView.setTag(StringFogImpl.decrypt("ITs2"));
        imageView.setLayoutParams(new RelativeLayout.LayoutParams(100, 100));
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        imageView.setImageDrawable(getResources().getDrawable(R.drawable.balloon));
        imageView.setX(this.positionX);
        imageView.setY(new Random().nextInt(500) + 100);
        this.rl_game.addView(imageView);
    }

    public void _moveBalloons() {
        ImageView imageView = (ImageView) findViewById(Integer.parseInt(this.getCreateBalloons.get(0).get(StringFogImpl.decrypt("PDA=")).toString()));
        if (Integer.parseInt(this.getCreateBalloons.get(0).get(StringFogImpl.decrypt("JTs1")).toString()) == 0) {
            if (this.setDefaultPosition) {
                imageView.setX(imageView.getX() + this.move);
            } else {
                imageView.setX(imageView.getX() - this.move);
            }
            if (imageView.getX() == SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) - 100) {
                this.setDefaultPosition = false;
            } else if (imageView.getX() <= 0.0f) {
                this.setDefaultPosition = true;
            }
        } else {
            if (this.setDefaultPosition) {
                imageView.setX(imageView.getX() - this.move);
            } else {
                imageView.setX(imageView.getX() + this.move);
            }
            if (imageView.getX() == SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) - 100) {
                this.setDefaultPosition = true;
            } else if (imageView.getX() <= 0.0f) {
                this.setDefaultPosition = false;
            }
        }
        if (0 - SketchwareUtil.getLocationY(this.ic_balloon) > this.rl_game.getHeight() + 100) {
            _updateLife(1.0d);
            this.hit = true;
            this.ic_balloon.setTranslationX(SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 2);
            this.ic_balloon.setTranslationY((SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / 2) + SketchwareUtil.getDip(getApplicationContext(), 200));
        }
        if (this.collision.getCollision(this.ic_balloon, imageView, this.rl_game)) {
            _removeBalloon();
            this.score++;
            _updateScore();
        }
    }

    public void _timerCheck() {
        if (this.gameOver) {
            return;
        }
        TimerTask timerTask = new TimerTask() { // from class: com.bgm.gfx.BlgameActivity.2
            @Override // java.util.TimerTask, java.lang.Runnable
            public void run() {
                BlgameActivity.this.runOnUiThread(new Runnable() { // from class: com.bgm.gfx.BlgameActivity.2.1
                    @Override // java.lang.Runnable
                    public void run() {
                        if (!BlgameActivity.this.hit) {
                            BlgameActivity.this.ic_balloon.setY(BlgameActivity.this.ic_balloon.getY() - BlgameActivity.this.moveBalloon);
                        }
                        BlgameActivity.this._moveBalloons();
                    }
                });
            }
        };
        this.timer = timerTask;
        this._timer.scheduleAtFixedRate(timerTask, 0L, 20L);
    }

    public void _posX(double d) {
        if (d == 1.0d) {
            this.positionX = SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) - 100;
        }
        if (d == 2.0d) {
            this.positionX = 0;
        }
    }

    public void _gameState() {
        this.create_id++;
        this.ic_balloon.setTranslationX(SketchwareUtil.getDisplayWidthPixels(getApplicationContext()) / 2);
        this.ic_balloon.setTranslationY((SketchwareUtil.getDisplayHeightPixels(getApplicationContext()) / 2) + SketchwareUtil.getDip(getApplicationContext(), 200));
        this.gameOver = false;
        this.setDefaultPosition = true;
        this.hit = true;
        _posX(new Random().nextInt(2) + 1);
        _createBalloons();
        _viewBalloons();
        _timerCheck();
    }

    public void _updateScore() {
        this.tv_score.setText(String.valueOf(this.score));
    }

    public void _removeBalloon() {
        this.gameOver = true;
        this.hit = false;
        TimerTask timerTask = this.timer;
        if (timerTask != null) {
            timerTask.cancel();
        }
        if (this.getCreateBalloons.get(0).containsKey(StringFogImpl.decrypt("PDA="))) {
            final ImageView imageView = (ImageView) findViewById(Integer.parseInt(this.getCreateBalloons.get(0).get(StringFogImpl.decrypt("PDA=")).toString()));
            new Handler().postDelayed(new Runnable() { // from class: com.bgm.gfx.BlgameActivity.3
                @Override // java.lang.Runnable
                public void run() {
                    BlgameActivity.this.rl_game.removeView(imageView);
                    BlgameActivity.this.getCreateBalloons.remove(0);
                    BlgameActivity.this._gameState();
                }
            }, 100L);
        }
    }

    public void _updateLife(double d) {
        if (d == 1.0d) {
            byte b = this.life;
            if (b - 1 < 1) {
                if (this.score > this.hs.getScore(this, StringFogImpl.decrypt("JjcpX10="))) {
                    this.hs.setScore(this, StringFogImpl.decrypt("JjcpX10="), this.score);
                }
                this.intent.setClass(getApplicationContext(), BmainActivity.class);
                startActivity(this.intent);
                finishAffinity();
            } else {
                this.life = (byte) (b - 1);
            }
            this.tv_life.setText(String.valueOf((int) this.life));
            return;
        }
        this.life = (byte) 5;
        this.tv_life.setText(String.valueOf(5));
    }

    @Deprecated
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, Toast.LENGTH_SHORT).show();
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    @Deprecated
    public int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList<Double> arrayList = new ArrayList<>();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf(checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int i) {
        return TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, i, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
