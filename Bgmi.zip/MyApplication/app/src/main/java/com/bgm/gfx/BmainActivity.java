package com.bgm.gfx;

import android.content.Intent;
import android.os.Bundle;
import android.util.SparseBooleanArray;
import android.util.TypedValue;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.github.megatronking.stringfog.xor.StringFogImpl;
import com.google.firebase.FirebaseApp;
import java.util.ArrayList;
import java.util.Random;

/* loaded from: classes7.dex */
public class BmainActivity extends AppCompatActivity {
    private Button button1;
    private final History hs = new History();
    private Intent intent = new Intent();
    private RelativeLayout linear1;
    private TextView tv_info_score;
    private TextView tv_score;
    private TextView tv_title;

    /* JADX INFO: Access modifiers changed from: protected */
    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, androidx.activity.ComponentActivity, androidx.core.app.ComponentActivity, android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.bmain);
        initialize(bundle);
          //   FirebaseApp.initializeApp(String.valueOf(this));
        initializeLogic();
    }

    private void initialize(Bundle bundle) {
        this.linear1 = (RelativeLayout) findViewById(R.id.linear1);
        this.tv_title = (TextView) findViewById(R.id.tv_title);
        this.tv_info_score = (TextView) findViewById(R.id.tv_info_score);
        this.tv_score = (TextView) findViewById(R.id.tv_score);
        this.button1 = (Button) findViewById(R.id.button1);
    }

    private void initializeLogic() {
        this.tv_score.setText(String.valueOf(this.hs.getScore(this, StringFogImpl.decrypt("JjcpX10="))));
    }

    @Override // androidx.appcompat.app.AppCompatActivity, androidx.fragment.app.FragmentActivity, android.app.Activity
    public void onStart() {
        super.onStart();
    }

    @Override // androidx.activity.ComponentActivity, android.app.Activity
    public void onBackPressed() {
        this.intent.setClass(getApplicationContext(), SelectGameActivity.class);
        startActivity(this.intent);
        finish();
    }

    public void _goGame(View view) {
        this.intent.setClass(getApplicationContext(), BlgameActivity.class);
        startActivity(this.intent);
        finishAffinity();
    }

    @Deprecated
    public void showMessage(String str) {
        Toast.makeText(getApplicationContext(), str, 0).show();
    }

    @Deprecated
    public int getLocationX(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[0];
    }

    @Deprecated
    public int getLocationY(View view) {
        int[] iArr = new int[2];
        view.getLocationInWindow(iArr);
        return iArr[1];
    }

    @Deprecated
    public int getRandom(int i, int i2) {
        return new Random().nextInt((i2 - i) + 1) + i;
    }

    @Deprecated
    public ArrayList<Double> getCheckedItemPositionsToArray(ListView listView) {
        ArrayList<Double> arrayList = new ArrayList<>();
        SparseBooleanArray checkedItemPositions = listView.getCheckedItemPositions();
        for (int i = 0; i < checkedItemPositions.size(); i++) {
            if (checkedItemPositions.valueAt(i)) {
                arrayList.add(Double.valueOf(checkedItemPositions.keyAt(i)));
            }
        }
        return arrayList;
    }

    @Deprecated
    public float getDip(int i) {
        return TypedValue.applyDimension(1, i, getResources().getDisplayMetrics());
    }

    @Deprecated
    public int getDisplayWidthPixels() {
        return getResources().getDisplayMetrics().widthPixels;
    }

    @Deprecated
    public int getDisplayHeightPixels() {
        return getResources().getDisplayMetrics().heightPixels;
    }
}
