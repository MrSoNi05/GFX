package com.example.iosprogressbarforandroid;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.widget.ImageView;

import com.bgm.gfx.R;

/* loaded from: classes2.dex */
@SuppressLint("AppCompatCustomView")
class SpinView extends ImageView implements Indeterminate {
    private int mFrameTime;
    private boolean mNeedToUpdateView;
    private float mRotateDegrees;
    private Runnable mUpdateViewRunnable;

    public SpinView(Context context) {
        super(context);
        init();
    }

    public SpinView(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        init();
    }

    private void init() {
        setImageResource(R.drawable.kprogresshud_spinner);
        this.mFrameTime = 83;
        this.mUpdateViewRunnable = new Runnable() { // from class: com.example.iosprogressbarforandroid.SpinView.1
            @Override // java.lang.Runnable
            public void run() {
                SpinView spinView = null;
                SpinView.this.mRotateDegrees += 30.0f;
                SpinView spinView2 = SpinView.this;
                spinView2.mRotateDegrees = spinView2.mRotateDegrees < 360.0f ? SpinView.this.mRotateDegrees : SpinView.this.mRotateDegrees - 360.0f;
                SpinView.this.invalidate();
                if (SpinView.this.mNeedToUpdateView) {
                    SpinView.this.postDelayed(this, spinView.mFrameTime);
                }
            }
        };
    }

    @Override // com.example.iosprogressbarforandroid.Indeterminate
    public void setAnimationSpeed(float f) {
        this.mFrameTime = (int) (83.0f / f);
    }

    @Override // android.widget.ImageView, android.view.View
    protected void onDraw(Canvas canvas) {
        canvas.rotate(this.mRotateDegrees, getWidth() / 2, getHeight() / 2);
        super.onDraw(canvas);
    }

    @Override // android.widget.ImageView, android.view.View
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        this.mNeedToUpdateView = true;
        post(this.mUpdateViewRunnable);
    }

    @Override // android.widget.ImageView, android.view.View
    protected void onDetachedFromWindow() {
        this.mNeedToUpdateView = false;
        super.onDetachedFromWindow();
    }
}
