package com.example.iosprogressbarforandroid;

/* loaded from: classes2.dex */
public interface Determinate {
    void setMax(int i);

    void setProgress(int i);
}
