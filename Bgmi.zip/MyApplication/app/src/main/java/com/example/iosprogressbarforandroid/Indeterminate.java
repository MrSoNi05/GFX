package com.example.iosprogressbarforandroid;

/* loaded from: classes2.dex */
public interface Indeterminate {
    void setAnimationSpeed(float f);
}
